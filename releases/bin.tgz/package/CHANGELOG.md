## CHANGELOG of binary-collections


### 2.0.14

- [ _2026-06-01 10:41:07_ ] [8f5fc75](<https://github.com/dimaslanjaka/bin/commit/8f5fc75>) fix(action): update cache key to exclude yarn.lock for improved cache efficiency
- [ _2026-06-01 10:46:01_ ] [7170f55](<https://github.com/dimaslanjaka/bin/commit/7170f55>)
    
    ci(test): improve test file discovery with directory guards and matrix output
    
    - add name to discover step for clarity in workflow logs
    - guard find calls with directory existence checks to avoid errors
    - wrap test file list into proper GitHub Actions matrix format
    - read matrix from matrix output instead of raw test list
- [ _2026-06-01 10:53:06_ ] [7218a8a](<https://github.com/dimaslanjaka/bin/commit/7218a8a>)
    
    ci(test): pin Node.js version, add job outputs, and clean up commented code
    
    - pin CI_NODE_VERSION from floating 24.x to specific 24.16.0
    - declare explicit matrix output on discover job for proper GHA consumption
    - remove leftover commented if: always() line from cleanup step
- [ _2026-06-01 10:55:47_ ] [3944959](<https://github.com/dimaslanjaka/bin/commit/3944959>)
    
    ci(dependabot): switch to daily updates, remove dependency ignores, and normalize config
    
    - change update schedule from monthly to daily for all ecosystems
    - remove ignore block to allow Dependabot PRs for all npm dependencies
    - add target-branch to github-actions and gitsubmodule for consistency
    - reformat YAML for cleaner structure
- [ _2026-06-01 10:57:11_ ] [cee6ec6](<https://github.com/dimaslanjaka/bin/commit/cee6ec6>) ci(test): add logging for discovered test files and generated matrix
- [ _2026-06-01 10:58:11_ ] [e210a02](<https://github.com/dimaslanjaka/bin/commit/e210a02>) fix(test): handle empty matrix output in test job strategy
- [ _2026-06-01 11:03:53_ ] [0224b7e](<https://github.com/dimaslanjaka/bin/commit/0224b7e>)
    
    style(test): quote all workflow step names for consistent YAML formatting
    
    - wrap unquoted step name values in double quotes across test workflow
    - no functional changes to CI behavior
- [ _2026-06-01 11:05:56_ ] [645d34b](<https://github.com/dimaslanjaka/bin/commit/645d34b>)
    
    ci(test): route test execution by file extension for CJS and ESM support
    
    - replace simple npm test with an extension-aware bash runner
    - add ACCESS_TOKEN and GH_TOKEN env vars to test step
    - run .cjs files through bin/test-cjs and .mjs through bin/test-esm
    - fall back to npm test for other file types
    - strip surrounding quotes from matrix file path defensively
- [ _2026-06-01 11:07:52_ ] [11df3c0](<https://github.com/dimaslanjaka/bin/commit/11df3c0>)
    
    ci(test): narrow test file discovery to explicit extensions and quote step name
    
    - replace wildcard *.test.* / *.spec.* with explicit .js, .cjs, .mjs, .ts extensions
    - quote discover step name for consistent YAML formatting
- [ _2026-06-01 11:11:10_ ] [b903269](<https://github.com/dimaslanjaka/bin/commit/b903269>) ci(test): simplify concurrency group name in workflow
- [ _2026-06-01 11:43:05_ ] [971f529](<https://github.com/dimaslanjaka/bin/commit/971f529>)
    
    feat(ci): replace dynamic test matrix with generated composite action
    
    - add scripts/generate-test-ci-step.mjs to discover test files and generate a composite GitHub Action
    - create .github/actions/run-tests/action.yml with per-file test steps routed by extension (cjs→test-cjs, mjs→test-esm, else→npm test)
    - refactor test.yml to use the composite action instead of dynamic discover+matrix jobs
    - rename build job to ci, consolidate build+test into a single job
    - update pre-commit hook to auto-generate and stage the run-tests action
    - add if: always() guard to cleanup step
    - remove upload/download build artifact steps and stale commented-out code
- [ _2026-06-01 11:45:44_ ] [674fc22](<https://github.com/dimaslanjaka/bin/commit/674fc22>)
    
    ci(test): hoist token env vars from individual test steps to action level
    
    - add ACCESS_TOKEN and GH_TOKEN at the composite action call site in test.yml
    - remove duplicated env block from generate-test-ci-step.mjs step output
    - avoid redundant secret passing across all 32 generated test steps
- [ _2026-06-01 04:46:48_ ] [14bccd8](<https://github.com/dimaslanjaka/bin/commit/14bccd8>)
    
    chore: update build from https://github.com/dimaslanjaka/bin/commit/971f5291fc996ad6cd6f8775f4a3a4b5e4508306
    
    commit hash: 15d5ce
    
    commit url: https://github.com/dimaslanjaka/bin/commit/971f5291fc996ad6cd6f8775f4a3a4b5e4508306
    
    runner: https://github.com/dimaslanjaka/bin/commit/971f5291fc996ad6cd6f8775f4a3a4b5e4508306/checks/26735622555
- [ _2026-06-01 11:49:04_ ] [25484a0](<https://github.com/dimaslanjaka/bin/commit/25484a0>)
    
    fix(hooks): skip git add of generated action in CI environments
    
    - guard git add .github/actions/run-tests/action.yml behind GITHUB_ACTIONS/CI check
    - prevent file corruption when pre-commit hook runs inside CI runner
- [ _2026-06-01 11:51:39_ ] [e3dddfa](<https://github.com/dimaslanjaka/bin/commit/e3dddfa>)
    
    fix(test-ci): skip untracked test files in generated composite action
    
    - add git ls-files tracking check before including test files
    - skip files not tracked by git with a warning message
    - prevent broken steps for test files that don't exist in the repository
- [ _2026-06-01 11:58:50_ ] [bc2420d](<https://github.com/dimaslanjaka/bin/commit/bc2420d>)
    
    fix(test-ci): replace sbg-utility sanitizeFilename with pure regex sanitization
    
    - remove sbg-utility dependency for step ID sanitization
    - implement custom safeId generation with regex replacement
    - ensure step ID starts with letter/underscore, truncate to 90 chars
    - strip redundant -test/-spec suffix from generated IDs
- [ _2026-06-01 12:03:21_ ] [42d8fa8](<https://github.com/dimaslanjaka/bin/commit/42d8fa8>)
    
    fix(test-ci): use full file path for step ID generation and simplify sanitization
    
    - use relative file path instead of basename for step IDs to avoid collisions
    - consolidate suffix stripping into a single regex replace
    - keep truncation and fallback random ID for edge cases
- [ _2026-06-01 12:09:31_ ] [94bf47f](<https://github.com/dimaslanjaka/bin/commit/94bf47f>) fix(tsconfig): update module target to esnext for improved compatibility
- [ _2026-06-01 12:12:33_ ] [0be7fe2](<https://github.com/dimaslanjaka/bin/commit/0be7fe2>)
    
    feat(scripts): add TypeScript test support to CI step generator
    
    - add dedicated jest runner for .ts test files in generate-test-ci-step.mjs
    - handle .ts extension before the generic npm test fallback
    - use --runInBand --forceExit flags for reliable TypeScript test execution
- [ _2026-06-01 12:21:34_ ] [2d21552](<https://github.com/dimaslanjaka/bin/commit/2d21552>)
    
    refactor(scripts): inline test steps directly into workflow instead of composite action
    
    - extract workflow template data to scripts/workflow-test-data.cjs
    - change generate-test-ci-step.mjs output target to .github/workflows/test.yml
    - delete now-unused .github/actions/run-tests/action.yml
    - update .husky/pre-commit to stage test.yml instead of action.yml
    - add 🧪 icon prefix to generated test step names
    - inline individual test steps with dedicated runner commands per test file
- [ _2026-06-01 12:25:27_ ] [0b95c2f](<https://github.com/dimaslanjaka/bin/commit/0b95c2f>)
    
    ci(test): normalize token resolution with cascading fallbacks in workflow
    
    - add ACCESS_TOKEN and GH_TOKEN at workflow env level with triple fallback chain
    - update setup-environments token input to include GITHUB_TOKEN fallback
    - update inline GH_TOKEN env in test step with cascading secret resolution
    - sync commented-out composite action block with same fallback pattern
- [ _2026-06-01 12:26:27_ ] [d5fb635](<https://github.com/dimaslanjaka/bin/commit/d5fb635>) chore(dependabot): comment out gitsubmodule updates in configuration
- [ _2026-06-01 12:26:56_ ] [2aa4201](<https://github.com/dimaslanjaka/bin/commit/2aa4201>) chore(dependabot): change update schedule from daily to weekly for npm and GitHub Actions
- [ _2026-06-01 12:45:44_ ] [702b053](<https://github.com/dimaslanjaka/bin/commit/702b053>)
    
    refactor(github-workflows): relocate test CI generator to src/ with CLI arg support
    
    - move generate-test-ci-step and workflow-test-data from scripts/ to src/github-workflows/
    - replace fast-glob dynamic import with static glob import
    - add minimist CLI argument parsing with --pattern/-p, --ignore/--ex, --output/-o, --help/-h
    - register generate-test-ci binary in build.config.cjs
    - update pre-commit hook to use new file path
    - add CLI documentation under docs-src/generate-test-ci.md
- [ _2026-06-01 12:47:55_ ] [3d32078](<https://github.com/dimaslanjaka/bin/commit/3d32078>)
    
    chore(github-workflows): format generated YAML with prettier
    
    - run prettier on output action file after writing YAML
    - prettier failure is non-fatal (optional formatting)
- [ _2026-06-01 12:53:38_ ] [391195e](<https://github.com/dimaslanjaka/bin/commit/391195e>)
    
    docs(readme): add new command reference entries and feature descriptions
    
    - add Conditional Execution, AI & IDE Tooling, and CI/CD Automation feature sections
    - expand Build & Package and Development Helpers feature descriptions
    - add Conditional Execution, Build & Package, AI & IDE Tooling, and CI/GitHub Actions rows to command reference table
    - expand Git (undo commands), File System (downloader, print-tarball-tree), and CI/GitHub Actions (generate-test-ci) listings
    - update all table descriptions to be more informative
    - link all 38 docs-src documentation files from the reference table
- [ _2026-06-01 12:57:20_ ] [fabd1fa](<https://github.com/dimaslanjaka/bin/commit/fabd1fa>) fix(github-workflows): update concurrency group to include event name
- [ _2026-06-01 13:17:51_ ] [9b88326](<https://github.com/dimaslanjaka/bin/commit/9b88326>)
    
    refactor(config): centralize GITHUB_ACCESS_TOKEN in config module
    
    - add GITHUB_ACCESS_TOKEN to src/binary-collections/config.cjs after dotenv loading
    - remove local process.env.ACCESS_TOKEN / GITHUB_TOKEN resolution from 3 consumers
    - update imports in clean-github-actions-caches.cjs, submodule-install.cjs, and package-resolutions-updater.mjs
    - remove GITHUB_ACCESS_TOKEN export from src/utils/index.cjs
- [ _2026-06-01 21:46:23_ ] [50b192b](<https://github.com/dimaslanjaka/bin/commit/50b192b>)
    
    chore(package): bump eslint-base-config and register generate-test-ci binary
    
    - bump @dimaslanjaka/eslint-base-config from ^1.0.1 to ^1.0.2
    - update cross-spawn resolution pinned artifact hash
    - register generate-test-ci CLI binary (aliases: N/A, entry: src/github-workflows/generate-test-ci-step-cli.mjs)
- [ _2026-06-01 21:47:15_ ] [a429760](<https://github.com/dimaslanjaka/bin/commit/a429760>)
    
    docs(git-commit-from-diff): add fallback method for missing git-diff
    
    - document native git commands as fallback when git-diff is not installed
    - add git diff --staged and git diff --staged --name-only examples
    - insert fallback instructions before the load-and-analyze section
- [ _2026-06-01 22:05:42_ ] [1ee950c](<https://github.com/dimaslanjaka/bin/commit/1ee950c>) chore: update .gitignore and .npmignore to include tmp and release directories
- [ _2026-06-02 11:03:52_ ] [6de8733](<https://github.com/dimaslanjaka/bin/commit/6de8733>) chore(package): update file patterns and dependency URLs in package.json
- [ _2026-06-02 11:09:02_ ] [5834f13](<https://github.com/dimaslanjaka/bin/commit/5834f13>)
    
    feat(github-workflows): add utility to inspect latest GitHub Actions run status
    
    - add script to fetch latest workflow run from GitHub Actions API
    - retrieve workflow jobs and step-level execution results
    - display success, failure, skipped, and pending step statuses
    - support automatic repository owner and name detection from git remote
    - add git command helpers using cross-spawn
    - use GitHub access token authentication via shared configuration
    - provide formatted console report for workflow, jobs, and steps
    - support GH_OWNER and GH_REPO environment variable overrides
    - improve API error handling and reporting
- [ _2026-06-02 11:22:06_ ] [55a970b](<https://github.com/dimaslanjaka/bin/commit/55a970b>)
    
    chore: rename source files from .js to .cjs extension
    
    - rename src/del-gradle.js to src/del-gradle.cjs
    - rename src/del-node-modules.js to src/del-node-modules.cjs
    - rename src/find-node-modules-cli.js to src/find-node-modules-cli.cjs
- [ _2026-06-02 11:39:20_ ] [adddfea](<https://github.com/dimaslanjaka/bin/commit/adddfea>)
    
    feat(cli): add workflow status CLI and SVG badge generator
    
    - add get-latest-workflow-status CLI for viewing latest GitHub Actions workflow run with job/step breakdown
    - add workflow-badge CLI for generating detailed card-style SVG badges of workflow status
    - refactor get-latest-workflow-status library module: remove main(), export all public functions
    - move get-latest-workflow-status CLI from src/github-workflows/ to src/
    - register 4 binary aliases for get-latest-workflow-status and 4 for workflow-badge
    - add documentation for both tools in docs-src/
    - update package.json bin mappings via build pipeline
- [ _2026-06-02 12:01:46_ ] [d3bab1d](<https://github.com/dimaslanjaka/bin/commit/d3bab1d>)
    
    feat(backend): add PHP badge server and SFTP upload workflow
    
    - add workflow-badge.php PHP backend that spawns Node CLI with npx fallback
    - add upload-backend.mjs script for deploying backend files via SFTP
    - add sftp-boilerplate.jsonc template for .vscode/sftp.json setup
    - add docs-src/upload-backend.md documenting the upload script
    - update workflow-badge.md with PHP backend usage and examples
    - add ssh2-sftp-client dev dependency and serve script for PHP dev server
    - protect .vscode/sftp.json from accidental commits via .gitignore
- [ _2026-06-02 14:29:40_ ] [a07edbb](<https://github.com/dimaslanjaka/bin/commit/a07edbb>)
    
    refactor(backend): remove npx tarball dependency and harden CLI discovery
    
    - remove npx remote tarball fallback ($NPX_TARBALL_URL) from workflow-badge.php
    - add NVM PATH extension so node is found on servers with non-standard PATH
    - add multiple fallback paths for CLI script discovery (src/, lib/, node_modules/)
    - suppress proc_open warning with @, improve error message on failure
    - echo clear error when CLI script is missing entirely
    - clean up upload-backend.mjs import ordering
- [ _2026-06-02 14:33:42_ ] [53a7ad6](<https://github.com/dimaslanjaka/bin/commit/53a7ad6>)
    
    chore(tooling): add composer installer script for PHP dependency management
    
    - add scripts/composer-installer.js to download and install Composer
    - add bin/composer* to .gitignore to avoid committing the phar binary
    - installer validates local vs remote file size before re-downloading
    - creates platform-specific shortcut (composer.cmd on Windows, composer on Unix)
    - supports the php-cs-fixer lint-staged step that requires composer
- [ _2026-06-02 14:34:01_ ] [c325863](<https://github.com/dimaslanjaka/bin/commit/c325863>) chore(deps): update lint-staged to version 17.0.7
- [ _2026-06-02 14:35:47_ ] [43399e1](<https://github.com/dimaslanjaka/bin/commit/43399e1>)
    
    docs(workflow-badge): update example URLs from localhost to production server
    
    - replace localhost badge URLs with actual production server in examples
- [ _2026-06-02 14:48:06_ ] [d2d875b](<https://github.com/dimaslanjaka/bin/commit/d2d875b>)
    
    feat(cli): add --token CLI argument to override GitHub access token
    
    - centralize --token parsing in src/binary-collections/config.cjs via minimist
    - add --token to workflow-badge-cli.mjs and get-latest-workflow-status-cli.mjs help
    - accept token GET/POST parameter in backend/workflow-badge.php and pass to Node CLI
    - update docs-src/workflow-badge.md and docs-src/get-latest-workflow-status.md
    - add "upload" script to package.json for deploying backend PHP files
- [ _2026-06-02 14:56:37_ ] [ab54dc5](<https://github.com/dimaslanjaka/bin/commit/ab54dc5>)
    
    refactor(agent): make commit splitting stage-aware with unstaging-first workflow
    
    - add "Additional Rule" to Section 4 instructing agent to unstage all
      files first when multiple commit contexts are detected
    - restructure Section 8 Execution Phase with Commit Grouping Strategy,
      Unstage Everything step, and per-group staging workflow
    - add Partial File Changes guidance for git add -p hunks
    - add Validation and Final Verification steps
    - update Section 7 preamble to reference the unstaging requirement
    - agent must never assume current staged set matches commit boundaries
- [ _2026-06-02 15:09:00_ ] [c925155](<https://github.com/dimaslanjaka/bin/commit/c925155>)
    
    chore(php): add PHP tooling configuration and update gitignore patterns
    
    - add composer.json with phpdotenv and php-cs-fixer dependencies
    - broaden gitignore lock/node_modules patterns to recursive (**/)
    - add vendor/ directory to gitignore for PHP Composer dependencies
    - fix missing trailing newline at end of gitignore
- [ _2026-06-02 15:36:38_ ] [ec01589](<https://github.com/dimaslanjaka/bin/commit/ec01589>)
    
    docs(mkdocs): add documentation site with MkDocs and GitHub Pages deployment
    
    - add MkDocs configuration with Material theme, syntax highlighting, and structured nav
    - add GitHub Actions workflow for building and deploying docs to GitHub Pages
    - add MkDocs pre-build hook to copy docs-src files and rewrite relative source links
    - add docs/index.md that includes README.md via snippet for auto-synced content
    - update gitignore to track docs/index.md while ignoring generated docs-src and site
- [ _2026-06-02 15:40:06_ ] [00af8aa](<https://github.com/dimaslanjaka/bin/commit/00af8aa>) feat(mkdocs): add Google Analytics configuration for site tracking
- [ _2026-06-02 16:04:44_ ] [bc65497](<https://github.com/dimaslanjaka/bin/commit/bc65497>)
    
    fix(mkdocs): make pre-build hook idempotent to stop infinite rebuild loop
    
    - use binary writes (write_bytes) instead of text mode to avoid CRLF/LF mismatch on Windows
    - add content comparison before copying docs-src/ -> docs/docs-src/
    - add content comparison before expanding README.md -> docs/index.md
    - gitignore and untrack docs/index.md (auto-generated by hook)
- [ _2026-06-02 16:13:24_ ] [57ca35a](<https://github.com/dimaslanjaka/bin/commit/57ca35a>)
    
    Create 'docs' directory for site generation
    
    Add step to create 'docs' directory before building site
- [ _2026-06-02 16:43:47_ ] [6921cce](<https://github.com/dimaslanjaka/bin/commit/6921cce>)
    
    refactor(src): reorganize source files into subdirectories
    
    - move git-* files from src/ to src/git/
    - move github-workflow files from src/ to src/github-workflows/
    - update relative imports in moved files
    - update build.config.cjs defaultBin paths
    - update package.json bin entries
    - update docs-src source links for moved files
    - update test import paths
- [ _2026-06-02 16:53:43_ ] [b7e1d11](<https://github.com/dimaslanjaka/bin/commit/b7e1d11>)
    
    feat: add --workflow flag to filter status/badge by specific workflow YAML
    
    - add optional workflowId parameter to getLatestRun()
    - add --workflow CLI flag to get-latest-workflow-status-cli
    - add --workflow CLI flag to workflow-badge-cli
    - add workflow query parameter support to backend/workflow-badge.php
    - update docs-src for both CLIs and PHP backend
    - fix stale CLI script paths in backend/workflow-badge.php after file reorganization
- [ _2026-06-02 17:07:25_ ] [025ced2](<https://github.com/dimaslanjaka/bin/commit/025ced2>)
    
    feat(scripts): add pre-upload SSH setup commands to upload-backend
    
    - add `execRemoteCommands()` function for running shell commands on remote server via ssh2
    - extend PATH with common Node.js install locations (NVM, etc.) before execution
    - run setup commands (pkg-res-updater, yarn install, git restore) before SFTP upload
    - each command runs independently — failure of one does not block the next
    - mirror PATH extension pattern from backend/workflow-badge.php
- [ _2026-06-02 17:11:42_ ] [46b7151](<https://github.com/dimaslanjaka/bin/commit/46b7151>)
    
    chore(tooling): add PHP-CS-Fixer configuration with custom fixers
    
    - add .php-cs-fixer.dist.php with PSR-12 rules, parallel config, and caching
    - add CustomNoMultipleStatementsPerLineFixer as fallback for no_multiple_statements_per_line
    - add GlobalOneLineFixer to collapse multi-line global statements into one-liners
    - add autoloader for custom fixer discovery
    - add direct-test.cjs for testing fixers against sample PHP input
    - add php-cs-fixer/.gitignore for test artifacts
- [ _2026-06-02 17:12:00_ ] [aab727d](<https://github.com/dimaslanjaka/bin/commit/aab727d>)
    
    style(backend): apply PHP-CS-Fixer formatting to workflow-badge.php
    
    - normalize indentation from 4-space to 2-space
    - normalize alignment spacing in variable assignments
    - prefer single quotes for simple strings
    - add blank line after <?php opening tag
    - add trailing comma in multiline array
- [ _2026-06-02 17:12:21_ ] [a769ef5](<https://github.com/dimaslanjaka/bin/commit/a769ef5>) chore(gitignore): add **/*.cache pattern
- [ _2026-06-02 17:20:53_ ] [c37a3d7](<https://github.com/dimaslanjaka/bin/commit/c37a3d7>)
    
    fix(test): correct module paths for git-fix test files
    
    - update require paths from ../src/git-fix.cjs to ../src/git/git-fix.cjs
    - fix gitFixPath resolution in help, options, and summary test files
    - resolves CI failure caused by missing module reference
- [ _2026-06-02 17:42:35_ ] [fc770b4](<https://github.com/dimaslanjaka/bin/commit/fc770b4>)
    
    feat(opencode-cli): group sessions by directory in list command with Date column
    
    - group session listing output by session directory
    - add Date column with RFC 3339 timezone-aware formatting via moment
    - add directory headings and visual separators for each group
    - update help text to reflect grouping behavior
    - show total session and directory counts in header
- [ _2026-06-03 00:13:26_ ] [1709acd](<https://github.com/dimaslanjaka/bin/commit/1709acd>)
    
    fix: pre-generate docs before mkdocs validation to avoid index.md warning
    
    - Rename hooks/copy-docs-src.py to hooks/copy_docs_src.py for Python import compatibility
    - Create hooks/pre-generate-docs.py to pre-generate docs/index.md and docs/docs-src/ before mkdocs build
    - Update mkdocs.yml to reference renamed hook file
    - Update .github/workflows/pages.yml to run pre-generate-docs.py before mkdocs build
    
    This fixes the CI warning: 'A reference to index.md is included in the nav configuration, which is not found in the documentation files.'
    
    Root cause: mkdocs validates nav references before running pre-build hooks, so docs/index.md didn't exist when validation occurred. Solution: pre-generate the docs manually in CI before mkdocs validates.
    
    Co-authored-by: Copilot <223556219+Copilot@users.noreply.github.com>
- [ _2026-06-03 07:52:07_ ] [d77a1d1](<https://github.com/dimaslanjaka/bin/commit/d77a1d1>)
    
    docs(docs-src): simplify Source sections and add auth rotate docs
    
    - simplify all docs Source sections to reference only CLI entrypoint files
    - remove references to supporting library modules from Source sections
    - add auth rotate command documentation with usage example and requirements
    - add .opencode.keys.jsonc file format documentation
    - fix minor punctuation and formatting inconsistencies
    - update del-ps.md source reference to del-ps-cli.mjs
- [ _2026-06-03 08:16:38_ ] [8ec2ec9](<https://github.com/dimaslanjaka/bin/commit/8ec2ec9>)
    
    feat(opencode): add auth rotate command with key validation and modularize CLI
    
    - add auth rotate command that iterates through candidate keys and tests each via checkOpenCodeApi
    - extract list-sessions, list-projects, and auth-rotate handlers into separate modules under src/opencode/cli/
    - add OpenCodeAuthData type definition in src/opencode/types.ts
    - add getOpenCodeAuth() and saveOpenCodeAuth() to storage.ts for auth.json management
    - add checkOpenCodeApi() utility for validating API keys against OpenCode Zen endpoint
    - add getSessionFileById() to storage.ts for session file path resolution
    - switch storage.ts readJson to use jsonc-parser for JSONC file support
    - add database runner debug functions: session listing and table dump
    - add experimental opencode-zen.runner.mjs for Zen API testing
    - add openai dependency for Zen API client
    - add .opencode.keys.json* to gitignore
- [ _2026-06-03 08:17:17_ ] [cc48f44](<https://github.com/dimaslanjaka/bin/commit/cc48f44>)
    
    docs(opencode): clarify delete project scope and document project ID arg
    
    - clarify that delete project only affects the OpenCode database, not the real project folder
    - document that <project-id> is the project UUID shown by opc list project
    - update example description to reference obtaining the ID from list project
- [ _2026-06-03 10:03:50_ ] [a28bf4c](<https://github.com/dimaslanjaka/bin/commit/a28bf4c>)
    
    fix(opencode): commit modularized CLI with auth rotate and updated help text
    
    - add imports for handleAuthRotate, handleListProjects, handleListSessions
    - add auth rotate subcommand routing
    - remove inline list session and list project logic (delegated to modules)
    - update delete project help text and runtime message
- [ _2026-06-03 10:30:24_ ] [5161e8d](<https://github.com/dimaslanjaka/bin/commit/5161e8d>)
    
    chore(agents): add VSCode Copilot shim instructions alongside OpenCode agents
    
    - rename create-cli-docs.md to create-cli-docs.agent.md for consistency
    - replace modify-js-ts.md with enhanced modify-js-ts.agent.md
    - remove deprecated git-commit-from-diff.md agent
    - add project-analyzer.agent.md and staged-file-commiter.agent.md agents
    - add .github/instructions/ shim files for VSCode GitHub Copilot compatibility
- [ _2026-06-03 10:37:01_ ] [2f3e873](<https://github.com/dimaslanjaka/bin/commit/2f3e873>) feat(opencode): add debugging response logging for OpenCode API checks
- [ _2026-06-03 11:13:31_ ] [ec81958](<https://github.com/dimaslanjaka/bin/commit/ec81958>)
    
    build(build): replace fs.copySync with rollup bundling for bin wrappers
    
    Replace simple file copy of binary-executor.cjs with proper rollup
    bundling via spawnSync to avoid async race conditions. Switch from
    npx to direct rollup binary path to fix Windows ENOENT issues.
    
    Add missing dependencies and rollup.executor.js config for bundle
    generation.
- [ _2026-06-03 11:16:59_ ] [fd734df](<https://github.com/dimaslanjaka/bin/commit/fd734df>) feat(agent): add name field to Create CLI Documentation agent
- [ _2026-06-03 11:38:08_ ] [3113711](<https://github.com/dimaslanjaka/bin/commit/3113711>)
    
    refactor(github-workflows): extract shared workflow utilities into utils.cjs
    
    Create src/github-workflows/utils.cjs with all duplicated GitHub API
    and git helper functions. Remove re-exports from
    get-latest-workflow-status.mjs and import directly from utils.cjs
    in both CLI consumers.
- [ _2026-06-03 11:39:20_ ] [584bcbd](<https://github.com/dimaslanjaka/bin/commit/584bcbd>)
    
    docs(readme): add command reference entries and workflow badges
    
    Add live workflow status badges (build-release, pages, test) after
    the title. Update CI/CD Automation feature description to cover
    workflow status querying and badge generation. Add
    get-latest-workflow-status and workflow-badge commands (with all
    aliases) to the CI/GitHub Actions table row with doc links.
- [ _2026-06-03 11:40:53_ ] [ae413b9](<https://github.com/dimaslanjaka/bin/commit/ae413b9>)
    
    docs(readme): add workflow badges and CI command entries
    
    Add build-release, pages, and test workflow SVGs after title.
    Expand CI/CD Automation feature description.
    Add get-latest-workflow-status and workflow-badge entries to table.
- [ _2026-06-03 11:50:17_ ] [6d0f13d](<https://github.com/dimaslanjaka/bin/commit/6d0f13d>) fix: update findEnvWithToken parameter type to include regex support
- [ _2026-06-03 11:57:32_ ] [7f06714](<https://github.com/dimaslanjaka/bin/commit/7f06714>)
    
    feat(binary-collections): add loadDotenv with tokenKey param, migrate callers
    
    Add centralized loadDotenv() function to replace inline dotenv.config()
    calls across the codebase. Accepts optional tokenKey parameter
    (default /ACCESS_TOKEN|GITHUB_TOKEN/) to control which token to search
    for in .env files.
    
    Migrated files: git-fix, user-config, clean-github-actions-caches,
    package-resolutions-updater, print-directory-tree, rmpath,
    submodule-install, submodule-remove.
- [ _2026-06-03 11:58:05_ ] [e8fee37](<https://github.com/dimaslanjaka/bin/commit/e8fee37>) fix(agent): correct name formatting for Project Analyzer Agent
- [ _2026-06-03 12:07:09_ ] [87cd948](<https://github.com/dimaslanjaka/bin/commit/87cd948>)
    
    fix(package-resolutions-updater): skip non-URL version entries without calling parseGitHubUrl
    
    Semver strings like ^1.0.0, ~2.3.0, or 0.0.1 in resolutions were being
    passed to parseGitHubUrl, which could throw or produce unexpected results.
    Added an early URL check to skip entries that are not http/https URLs.
- [ _2026-06-03 12:14:07_ ] [ad7abc4](<https://github.com/dimaslanjaka/bin/commit/ad7abc4>) docs(readme): wrap workflow badges in collapsible ci details
- [ _2026-06-03 12:20:08_ ] [f3bad8f](<https://github.com/dimaslanjaka/bin/commit/f3bad8f>)
    
    feat(upload-backend): pin binary-collections install to remote origin commit hash
    
    Replace the generic `yarn install` with a pinned install from the exact
    remote origin HEAD commit. Resolve the commit hash via `git ls-remote`
    before executing setup commands on the target server to ensure
    deployment consistency.
- [ _2026-06-03 12:23:32_ ] [9706a03](<https://github.com/dimaslanjaka/bin/commit/9706a03>) ci(pages): add node setup and caching for docs and site
- [ _2026-06-03 12:26:21_ ] [4c2aba1](<https://github.com/dimaslanjaka/bin/commit/4c2aba1>)
    
    fix(docs): resolve case-sensitive readme lookup in hook and cache key
    
    - Add lowercase readme.md fallback in _expand_readme_to_index()
    - Match both cases in cache hashFiles glob pattern
- [ _2026-06-03 12:27:47_ ] [05cc2ed](<https://github.com/dimaslanjaka/bin/commit/05cc2ed>) ci(pages): ignore tgz and release paths for docs deploy
- [ _2026-06-03 12:31:06_ ] [ba01102](<https://github.com/dimaslanjaka/bin/commit/ba01102>) ci(pages): split generate step into install, pre-process, build
- [ _2026-06-03 12:45:37_ ] [0675e48](<https://github.com/dimaslanjaka/bin/commit/0675e48>) fix(docs): convert html details blocks to mkdocs collapsible syntax
- [ _2026-06-03 12:56:50_ ] [33f1cb5](<https://github.com/dimaslanjaka/bin/commit/33f1cb5>) ci(setup-environments): add binaries, databases, coverage to cache
- [ _2026-06-03 12:57:51_ ] [53c93ed](<https://github.com/dimaslanjaka/bin/commit/53c93ed>) fix(pages): correct pre-process-docs script name to pre-generate-docs
- [ _2026-06-03 13:13:13_ ] [bbff778](<https://github.com/dimaslanjaka/bin/commit/bbff778>) docs(agents): rewrite AGENTS.md with comprehensive project guidance
- [ _2026-06-03 13:15:45_ ] [7f41aae](<https://github.com/dimaslanjaka/bin/commit/7f41aae>)
    
    ci: remove workflow_run trigger and Build Release conditional from test CI
    
    Remove the workflow_run trigger for Build Release completed events,
    the if-conditional checking its conclusion, and the dead SHA logic
    in the cache cleanup step that was specific to that event path.
- [ _2026-06-03 13:38:06_ ] [7d0ce6d](<https://github.com/dimaslanjaka/bin/commit/7d0ce6d>)
    
    style(build): refine comments and remove dead code in build.mjs
    
    Clean up inline comments for clarity and consistency:
    - Fix misleading "Polyfill" → "Derive", "Build" → "Generate"
    - Remove redundant comments obvious from code
    - Remove dead commented-out console.log lines
    - Shorten verbose comments
- [ _2026-06-03 13:46:18_ ] [5ce5f41](<https://github.com/dimaslanjaka/bin/commit/5ce5f41>) docs(run-by-checksum): add jsdoc descriptions and @private tag to hash module functions
- [ _2026-06-03 13:54:14_ ] [68c431a](<https://github.com/dimaslanjaka/bin/commit/68c431a>)
    
    build: add checksum caching for rollup bundle and colorize build logs
    
    - build.mjs: Add SHA-256 checksum-based caching for binary-executor
      rollup bundle; only rebuild when source/deps/config changes or output
      is missing; move rollup before bin copy loop; add [rollup] log prefix
    - build.config.cjs: Colorize fnName in generateMapping log messages
- [ _2026-06-03 13:57:56_ ] [be4831d](<https://github.com/dimaslanjaka/bin/commit/be4831d>)
    
    feat(hash): detect binary files and normalize content before hashing
    
    Add isBinaryFile() to scan for null bytes; hashFile() now normalizes
    whitespace for text files and hashes path+size for binary files.
- [ _2026-06-03 14:02:44_ ] [b71e07c](<https://github.com/dimaslanjaka/bin/commit/b71e07c>)
    
    ci(github-workflows): condense multi-line commands to single-line format
    
    - Update cache clean step in build-release.yml to use full npx invocation
    - Condense multi-line template literals in workflow-test-data.cjs
- [ _2026-06-03 14:04:03_ ] [fa4471c](<https://github.com/dimaslanjaka/bin/commit/fa4471c>) feat(auth-rotate): shuffle candidate keys to enhance key rotation randomness
- [ _2026-06-03 14:27:42_ ] [5138b14](<https://github.com/dimaslanjaka/bin/commit/5138b14>)
    
    feat(opencode): add install-opencode-plugins CLI with docs and plugin registration
    
    - New CLI tool that automates installing recommended OpenCode plugins
    - Runs 7 sequential steps: git clone request-logger, register it locally,
      then install 5 plugins (opencode-agent-memory, smart-title,
      oh-my-opencode-slim, opencode-dcp, envsitter-guard)
    - Uses cross-spawn with shell:true for proper PATH resolution
    - skipIfExists logic makes git clone idempotent
    - Added 3 new plugins to opencode.jsonc plugin list
    - Added cosmiconfig dependency to package.json
    - Documented the CLI in docs-src/install-opencode-plugins.md
- [ _2026-06-03 15:00:08_ ] [709a32d](<https://github.com/dimaslanjaka/bin/commit/709a32d>)
    
    feat(config): add cosmiconfig-powered configuration system
    
    Introduce async getConfig() with cosmiconfig search, TypeScript
    config types, and a boilerplate config example file.
    
    - config.cjs: add getConfig(), inline getTempDir into getTempPath,
      remove unused TEMP_BASE_DIR export
    - config-types.ts: define BinaryCollectionsConfig interface
    - auth-rotate.ts: load keys from project config instead of
      .opencode.keys.jsonc
    - check-api.ts: use getTempPath() instead of hardcoded tmp/ path
    - changelog.cjs: use getTempPath() instead of __dirname-based tmp/
    - readme.md: add Configuration section with boilerplate instructions
    - docs-src: update auth rotate docs to reference project config
    - .gitignore: prevent committing local .binary-collections.config.js
- [ _2026-06-03 15:08:23_ ] [6a948f8](<https://github.com/dimaslanjaka/bin/commit/6a948f8>)
    
    docs(config): standardize config filename to binary-collections.config
    
    Remove all references to .binary-collectionsrc, .rc, JSON, and YAML
    config variants. Only binary-collections.config.{js,cjs,mjs} is supported.
    
    - readme.md: rewrite Configuration section with supported extensions
      table, CJS/ESM examples, simplified boilerplate instructions
    - config.cjs: update JSDoc to reflect single config file naming
    - auth-rotate.ts: update comment and error message
    - docs-src: replace .binary-collectionsrc.js references
    - .gitignore: remove leading dot from config entry
    - binary-collections.config-example.js: rename (remove leading dot)
      and update rename comment
- [ _2026-06-03 15:34:37_ ] [5abbf31](<https://github.com/dimaslanjaka/bin/commit/5abbf31>)
    
    feat(docs): add google adsense injection and docs serve script
    
    - Create overrides/main.html with AdSense head script, after-content
      matched ad, and sidebar display ad below table of contents
    - Register custom_dir in mkdocs.yml theme config for template overrides
    - Add bin/docs-serve.cmd for local mkdocs dev server on port 5173
- [ _2026-06-03 18:20:03_ ] [5c9821a](<https://github.com/dimaslanjaka/bin/commit/5c9821a>) test: enhance node-executor CLI tests for src and dist consistency
- [ _2026-06-03 18:24:28_ ] [1c6015b](<https://github.com/dimaslanjaka/bin/commit/1c6015b>) test(validate-tarball-utils): add binary validation checks for node-executor, py, and pkg-res-updater
- [ _2026-06-03 18:33:44_ ] [35549e4](<https://github.com/dimaslanjaka/bin/commit/35549e4>)
    
    refactor(run-by-checksum): convert hash.js to CJS and adopt in test utilities
    
    - convert hash.js from ESM to CJS (require/module.exports)
    - update run.js and build.mjs imports to reference hash.cjs
    - replace crypto-js-based computeBuildChecksum in validate-tarball-utils.cjs
      with shared getAllFiles/buildChecksum from hash.cjs
    - remove now-unused crypto-js and glob dependency usage from tests
- [ _2026-06-03 18:34:16_ ] [2dc09a8](<https://github.com/dimaslanjaka/bin/commit/2dc09a8>)
    
    chore(scripts): add oh-my-posh PowerShell launcher and clean cmd-here
    
    - add cmd-oh-my-posh-here.bat — opens pwsh with Oh My Posh prompt
    - add cmd-oh-my-posh.json — Oh My Posh theme configuration
    - remove extraneous LANG/PYTHONUTF8 env vars from cmd-here.bat
- [ _2026-06-03 18:34:50_ ] [95404d7](<https://github.com/dimaslanjaka/bin/commit/95404d7>)
    
    docs: replace standalone docs-serve.cmd with mkdocs-serve npm script
    
    - add mkdocs-serve script to package.json scripts
    - remove bin/docs-serve.cmd (obsoleted by npm script)
- [ _2026-06-03 18:44:26_ ] [fb3aef6](<https://github.com/dimaslanjaka/bin/commit/fb3aef6>)
    
    feat(opencode): rewrite staged-file-commiter with context-aware batching
    
    Transform the staged-file-commiter agent from a simple staged-diff
    committer into a context-aware multi-commit batcher. Adds staged file
    detection, context group analysis, multi-shell syntax for all steps,
    and batch committing by context group.
- [ _2026-06-03 18:46:45_ ] [ad9ae34](<https://github.com/dimaslanjaka/bin/commit/ad9ae34>)
    
    refactor(run-by-checksum): replace crypto with crypto-js for SHA-256 hashing
    
    Swap Node.js built-in crypto module for the crypto-js library to
    provide consistent hashing across environments. Update hashFile and
    buildChecksum to use CryptoJS SHA-256 API with incremental and
    one-shot patterns where appropriate.
- [ _2026-06-03 18:47:28_ ] [782470b](<https://github.com/dimaslanjaka/bin/commit/782470b>) test(validate-tarball-utils): add git-diff binary validation check
- [ _2026-06-03 18:50:54_ ] [6783d47](<https://github.com/dimaslanjaka/bin/commit/6783d47>)
    
    fix(bin): update git-diff wrapper paths after src/git reorganization
    
    The bin/git-diff and bin/git-diff.cmd wrappers still referenced the old
    lib/git-diff-cli.cjs and lib/git-diff.cjs paths. After the source files
    moved to src/git/, build output moved to lib/git/git-diff-cli.cjs.
- [ _2026-06-03 18:51:39_ ] [af98c28](<https://github.com/dimaslanjaka/bin/commit/af98c28>)
    
    build(validate-tarball-utils): use corepack yarn for build and pack commands
    
    Wrap yarn invocations with corepack to ensure the correct package
    manager version is used during tarball validation builds.
- [ _2026-06-04 01:10:28_ ] [2e1597d](<https://github.com/dimaslanjaka/bin/commit/2e1597d>)
    
    fix(test): handle EACCES when removing node_modules/binary-collections on CI
    
    Yarn Berry's node-modules linker may create files with read-only
    permissions inside node_modules/.  fs.removeSync() then fails with
    EACCES on Linux because it cannot unlink read-only files.
    
    Added forceRemoveSync() that uses rm -rf on Linux/Mac (handles
    read-only files natively) and falls back to recursive chmod +
    remove on Windows.  Replaced all fs.removeSync() calls in the
    tarball validation test setup with this helper.
- [ _2026-06-04 01:11:30_ ] [34b537c](<https://github.com/dimaslanjaka/bin/commit/34b537c>) chore(lint-staged): consolidate patterns and use npx commands
- [ _2026-06-04 01:13:22_ ] [e7fedc7](<https://github.com/dimaslanjaka/bin/commit/e7fedc7>) chore(lint-staged): migrate config to JavaScript runner
- [ _2026-06-04 01:26:36_ ] [2e849e3](<https://github.com/dimaslanjaka/bin/commit/2e849e3>)
    
    fix(opencode): handle API check failures gracefully
    
    Wrap OpenCode API validation in error handling and return false on failed
    requests instead of throwing. Add timeout and validateStatus to inspect non-2xx
    responses, including FreeUsageLimitError rate limits.
    
    Only write response dumps and diagnostic logs when debug mode is enabled, and
    use a hashed API key value for stable debug log filenames.
- [ _2026-06-04 01:40:13_ ] [925bad2](<https://github.com/dimaslanjaka/bin/commit/925bad2>)
    
    feat(opencode): add proxy support for API checks
    
    Add optional proxy configuration to OpenCode API validation and auth rotation,
    supporting direct proxy arguments and environment-based proxy resolution.
    
    Use ProxyAgent for HTTP, HTTPS, SOCKS4, and SOCKS5 proxy URLs, disable Axios
    default proxy handling when a custom agent is used, and mask proxy credentials
    in debug output.
    
    Add an auth rotation runner example that enables debug mode and runs rotation
    through a SOCKS5 proxy.
- [ _2026-06-05 04:50:37_ ] [bc097cd](<https://github.com/dimaslanjaka/bin/commit/bc097cd>)
    
    refactor(tarball): split tree printer CLI and use native zlib
    
    Separate the tarball tree printer logic from the CLI entrypoint so the core
    helpers can be imported and tested independently.
    
    Changes:
    - move CLI argument handling into src/print-tarball-tree-cli.mjs
    - keep src/print-tarball-tree.mjs focused on reusable tree/tgz utilities
    - export addToTree, formatTree, printTree, and printTgzTree
    - replace the deprecated npm zlib dependency with Node.js built-in node:zlib
    - use stream/promises pipeline for safer tgz extraction flow
    - add Jest unit tests for tree building, formatting, printing, tgz parsing, and error cases
    - add proxy-agent dependency
    - update @dimaslanjaka/eslint-base-config tarball reference
    
    This avoids the legacy node-waf build failure from the old zlib package and
    makes the tarball tree printer easier to validate through unit tests.
- [ _2026-06-05 05:06:05_ ] [7c738e3](<https://github.com/dimaslanjaka/bin/commit/7c738e3>)
    
    refactor(checksum): optimize file hashing utilities
    
    Improve checksum generation helpers for safer file matching, binary detection,
    and reusable SHA-256 hashing.
    
    Changes:
    - remove duplicate upath import and use a single path helper
    - add globSync compatibility for different glob versions
    - add default options for getAllFiles and buildChecksum
    - resolve cwd to an absolute path before glob matching
    - normalize matched file paths consistently
    - avoid reading full files when detecting binary content
    - scan only the configured byte range with fs.readSync
    - ensure file descriptors are closed with finally
    - simplify text file hashing by using utf8 reads directly
    - keep binary checksum behavior based on file path and size
    - add reusable sha256 helper with optional output trimming
    - export sha256 alongside getAllFiles and buildChecksum
- [ _2026-06-05 05:07:29_ ] [97c03ec](<https://github.com/dimaslanjaka/bin/commit/97c03ec>)
    
    feat(opencode-cli): add --proxy/-p option for API request proxying
    
    The --proxy flag (alias -p) accepts a proxy URL in the format
    protocol://ip:port or protocol://user:pass@ip:port, supporting http,
    https, socks4, and socks5 protocols. It is passed through to
    handleAuthRotate() which forwards it to checkOpenCodeApi() for
    ProxyAgent creation.
    
    docs-src/opencode-cli.md updated with usage docs and examples.
- [ _2026-06-05 05:08:57_ ] [efcce87](<https://github.com/dimaslanjaka/bin/commit/efcce87>) feat(utils): add isDebug utility function
- [ _2026-06-05 05:10:28_ ] [01d8563](<https://github.com/dimaslanjaka/bin/commit/01d8563>) chore(deps): update submodule pointers for cross-spawn and git-command-helper
- [ _2026-06-05 05:10:54_ ] [3c78d11](<https://github.com/dimaslanjaka/bin/commit/3c78d11>) build(tsconfig): add moduleResolution bundler and remove deprecated ignoreDeprecations
- [ _2026-06-05 05:14:07_ ] [8468c0d](<https://github.com/dimaslanjaka/bin/commit/8468c0d>)
    
    fix(bin): update tarball-tree binary paths to CLI variant and bump version
    
    After the tarball tree refactor (commit bc097cd), the print-tarball-tree
    and tarball-tree binary entries still pointed to the module entry point
    instead of the -cli wrapper. Update all three references in
    build.config.cjs and package.json, and bump version to 2.0.15.
- [ _2026-06-05 05:14:59_ ] [8d3ee56](<https://github.com/dimaslanjaka/bin/commit/8d3ee56>) chore(package): remove readme.md from files list in package.json
- [ _2026-06-05 09:25:49_ ] [e068648](<https://github.com/dimaslanjaka/bin/commit/e068648>)
    
    refactor: centralize minimist parsing to getArgs from utils
    
    Replace direct minimist imports in 4 files with centralized getArgs()
    from src/utils/index.cjs, reducing direct dependency on minimist:
    
    - src/binary-collections/config.cjs
    - src/github-workflows/generate-test-ci-step-cli.mjs
    - src/opencode-cli.ts
    - src/vscode-cli.ts
- [ _2026-06-05 09:37:50_ ] [9df49bb](<https://github.com/dimaslanjaka/bin/commit/9df49bb>)
    
    refactor(src): migrate from child_process to cross-spawn for spawn utils
    
    Replace require('child_process') with require('cross-spawn') for all
    spawn/spawnSync calls to use the patched local fork in packages/cross-spawn.
    
    Files using exec/execSync only are left unchanged.
- [ _2026-06-05 09:38:01_ ] [280eb41](<https://github.com/dimaslanjaka/bin/commit/280eb41>)
    
    fix(src): remove unnecessary shell:true to fix DEP0190 deprecation warning
    
    Replace args-array + shell:true with either bare spawn (no shell needed)
    or a quoted command string (when shell is genuinely needed for pipes
    or PATH lookup), resolving Node.js DEP0190 warning.
- [ _2026-06-05 09:38:09_ ] [f74388a](<https://github.com/dimaslanjaka/bin/commit/f74388a>) refactor(src): apply cross-spawn and dep0190 fixes to overlapping files
- [ _2026-06-05 10:14:42_ ] [968dde5](<https://github.com/dimaslanjaka/bin/commit/968dde5>)
    
    refactor(opencode): move SQLite class to utils/sqlite/index.ts
    
    Move src/opencode/sqlite.ts to src/utils/sqlite/index.ts and update
    all import references in database.ts and database.runner.ts to point
    to the new location.
- [ _2026-06-05 10:46:36_ ] [fadabf9](<https://github.com/dimaslanjaka/bin/commit/fadabf9>)
    
    refactor(opencode): add overloads for loadMessages and loadPartsForMessages
    
    - Export MessageRow and PartRow interfaces for shared use
    - Replace async loadMessages(sessionID) with sync overloads
    - Add loadPartsForMessages function with overloads (SQLite instance or direct)
    - Fix empty-array guard in single-arg loadPartsForMessages call
- [ _2026-06-05 10:55:53_ ] [f9f9426](<https://github.com/dimaslanjaka/bin/commit/f9f9426>) feat: add ai-toolkit submodule for enhanced functionality
- [ _2026-06-05 11:48:22_ ] [5cbfff7](<https://github.com/dimaslanjaka/bin/commit/5cbfff7>)
    
    feat(opencode): add OpenAI-compatible client builder
    
    - build LLM client from OpenCode auth credentials
    - support opencode.ai Zen and Google Gemini OpenAI-compatible endpoints
    - fall back to OPENAI_API_KEY for standard OpenAI usage
    - throw a clear error when no API key is configured
- [ _2026-06-05 12:21:32_ ] [546e4e9](<https://github.com/dimaslanjaka/bin/commit/546e4e9>) feat(opencode): add proxy support to buildOpenAIClient
- [ _2026-06-05 12:48:23_ ] [344b94c](<https://github.com/dimaslanjaka/bin/commit/344b94c>) chore: update submodule references for cross-spawn and git-command-helper
- [ _2026-06-05 13:19:46_ ] [390caa7](<https://github.com/dimaslanjaka/bin/commit/390caa7>) feat: export OpencodeKey interface for external usage
- [ _2026-06-05 13:21:23_ ] [273898d](<https://github.com/dimaslanjaka/bin/commit/273898d>)
    
    feat(opencode): add apiKeys option to buildOpenAIClient
    
    - add apiKeys option accepting OpenCodeAuthData or BinaryCollectionsConfig
    - add extractApiKey helper with duck-typing for both shapes
    - add TSDoc to buildProxyOptions, extractApiKey, buildOpenAIClient
    - apiKeys skips getOpenCodeAuth() when provided
- [ _2026-06-05 13:26:25_ ] [5f6636f](<https://github.com/dimaslanjaka/bin/commit/5f6636f>)
    
    refactor(opencode): extract working key selection
    
    - add reusable findWorkingKey helper for shuffled key validation
    - type OpenCode key entries with OpencodeKey
    - reuse helper in auth rotation flow
    - keep failed candidate keys skipped during API checks
- [ _2026-06-05 13:41:14_ ] [3945d2c](<https://github.com/dimaslanjaka/bin/commit/3945d2c>)
    
    feat(opencode): select working key when building OpenAI client
    
    - use auth rotation to pick a working binary-collections OpenCode key
    - pass proxy URL into key extraction for proxied key validation
    - return proxy metadata alongside dispatcher
    - refactor OpenAI client creation to remove duplicated provider setup
    - update TSDoc for credential resolution and provider priority
- [ _2026-06-05 14:00:27_ ] [3ffc318](<https://github.com/dimaslanjaka/bin/commit/3ffc318>)
    
    feat(opencode): cache working key and refactor findWorkingKey signature
    
    Add a 5-minute TTL cache for working API keys, keyed by proxy setting,
    to avoid redundant API checks on every rotation. Refactor findWorkingKey
    to accept an options object (proxy, noCache) instead of a positional
    proxy string. Update handleAuthRotate with noCache support and fix the
    caller in buildOpenAIClient to pass the options object with a null guard.
- [ _2026-06-05 14:02:59_ ] [91a0910](<https://github.com/dimaslanjaka/bin/commit/91a0910>)
    
    feat(opencode): add Python tools for OpenCode session inspection and export
    
    Add debug.py — export OpenCode SQLite sessions to markdown/JSON.
    Add opencode_context_explorer.py — CLI tool to inspect, list, and
    export sessions with schema auto-detection (inspect|list|export
    subcommands).
    Add opencode.md — usage note for the context explorer.
    Update .gitignore to exclude opencode_exports/ output directory.
- [ _2026-06-05 14:08:55_ ] [371e89c](<https://github.com/dimaslanjaka/bin/commit/371e89c>) feat(package): add ai-toolkit dependency and update resolutions for cross-spawn and git-command-helper
- [ _2026-06-05 14:11:38_ ] [66236e4](<https://github.com/dimaslanjaka/bin/commit/66236e4>) fix(build): update ignore patterns for checksum file collection
- [ _2026-06-05 07:15:38_ ] [bb48792](<https://github.com/dimaslanjaka/bin/commit/bb48792>)
    
    chore: update build from https://github.com/dimaslanjaka/bin/commit/66236e4fc04c3545cea0a0cc9875002115bf0df9
    
    commit hash: 98bb49
    
    commit url: https://github.com/dimaslanjaka/bin/commit/66236e4fc04c3545cea0a0cc9875002115bf0df9
    
    runner: https://github.com/dimaslanjaka/bin/commit/66236e4fc04c3545cea0a0cc9875002115bf0df9/checks/27001076549
- [ _2026-06-05 14:35:05_ ] [68017c9](<https://github.com/dimaslanjaka/bin/commit/68017c9>)
    
    fix(build-tarball): use crossSpawn.sync to fix ENOENT on Windows
    
    crossSpawn.spawn does not resolve .cmd files on Windows async.
    Use crossSpawn.sync which correctly handles .cmd binaries.
    Also fix --yarn flag detection by checking args.yarn.
- [ _2026-06-05 14:52:40_ ] [0ff2dca](<https://github.com/dimaslanjaka/bin/commit/0ff2dca>)
    
    refactor(src): split print-directory-tree into library and CLI modules
    
    - Extract CLI code (arg parsing, help text, main execution) into
      src/print-directory-tree-cli.cjs
    - Convert src/print-directory-tree.cjs to a library module exporting
      mainPrintDirectoryTree() and getFileTreeString()
    - Rename main() to mainPrintDirectoryTree() to avoid name collisions
    - Update build.config.cjs bin mappings to CLI file
    - Update docs-src/print-directory-tree.md source link
- [ _2026-06-05 15:14:52_ ] [ab31e89](<https://github.com/dimaslanjaka/bin/commit/ab31e89>)
    
    feat(opencode): add NVIDIA API key support as LLM provider fallback
    
    - Add nvidia keys section to config example
    - Rename OpencodeKey to KeyData for reuse across providers
    - Add nvidia config type to BinaryCollectionsConfig
    - Update auth-rotate findWorkingKey to use generic KeyData type
    - Add NVIDIA fallback to buildOpenAIClient (auth data + env var)
- [ _2026-06-05 15:16:53_ ] [14bdcd9](<https://github.com/dimaslanjaka/bin/commit/14bdcd9>) docs(readme): inline link to config example file
- [ _2026-06-05 15:39:43_ ] [f9ff10b](<https://github.com/dimaslanjaka/bin/commit/f9ff10b>)
    
    feat(print-directory-tree): make project dir configurable via --cwd flag
    
    - projectDir now reads from argv.cwd with process.cwd() as fallback
    - Replaced CryptoJS.SHA256 with shared sha256() from run-by-checksum/hash.cjs
    - Updated binary mappings: dir-tree, print-tree, print-directory-tree now point to CLI file
    - Added --cwd option to CLI help text and docs
- [ _2026-06-05 15:42:20_ ] [fb9666c](<https://github.com/dimaslanjaka/bin/commit/fb9666c>)
    
    refactor(print-tarball-tree): rename exported functions to avoid naming collisions
    
    - printTree → printTgzTree (descriptive name matching module)
    - printTgzTree (async) → mainPrintTgzTree (follows main* convention)
    - Updated CLI import and test imports accordingly
- [ _2026-06-05 15:45:58_ ] [55aed56](<https://github.com/dimaslanjaka/bin/commit/55aed56>) feat(hash): export isBinaryFile function for external use
- [ _2026-06-05 16:04:58_ ] [f26ca91](<https://github.com/dimaslanjaka/bin/commit/f26ca91>) feat(test): add NVIDIA AI test script for chat completions
- [ _2026-06-05 16:06:50_ ] [8978c59](<https://github.com/dimaslanjaka/bin/commit/8978c59>) feat(print-tarball-tree): add detailed JSDoc comments for tree manipulation functions
- [ _2026-06-05 16:21:16_ ] [207ac9c](<https://github.com/dimaslanjaka/bin/commit/207ac9c>) refactor(opencode): simplify buildOpenAIClient with guard clause and merged NVIDIA blocks
- [ _2026-06-05 16:55:15_ ] [4c627c6](<https://github.com/dimaslanjaka/bin/commit/4c627c6>)
    
    refactor(print-tree): split into library and CLI entry points
    
    - Create src/print-tree.mjs as library module exporting printTree()
    - Create src/print-tree-cli.mjs as CLI entry point using getArgs
    - Update build.config.cjs and package.json bin to point to new CLI file
    - Create docs-src/print-tree.md; remove print-tree alias from print-directory-tree docs
- [ _2026-06-05 17:18:00_ ] [72237e1](<https://github.com/dimaslanjaka/bin/commit/72237e1>) refactor(opencode-cli): remove outdated package.json configuration example
- [ _2026-06-05 21:30:58_ ] [14fecad](<https://github.com/dimaslanjaka/bin/commit/14fecad>) fix(config): update return type in loadDotenv JSDoc comment
- [ _2026-06-05 21:56:16_ ] [7f1b028](<https://github.com/dimaslanjaka/bin/commit/7f1b028>)
    
    fix(config): restrict config lookup and surface load errors
    
    Limit cosmiconfig search places to supported binary-collections
    config files only, excluding package.json, rc, JSON, and YAML configs.
    
    Resolve the search path before lookup and rethrow config loading failures
    with contextual error messages instead of silently returning null.
- [ _2026-06-05 22:02:41_ ] [5f90efd](<https://github.com/dimaslanjaka/bin/commit/5f90efd>) feat(opencode): load dotenv on startup
- [ _2026-06-06 18:40:00_ ] [aefa8cc](<https://github.com/dimaslanjaka/bin/commit/aefa8cc>)
    
    refactor(test): move git-related test files into test/git/ directory
    
    Reorganize test file structure by moving all git-related test files
    from test/ into test/git/ subdirectory. Update relative import paths
    to reflect the new directory structure (../env.cjs → ../env.cjs,
    ../../src/git/ instead of ../src/git/).
    
    Affected test suites:
    - git-diff, git-fix (help, options, summary, focused)
    - git-user-config, git-utils, git-purge
- [ _2026-06-06 18:43:07_ ] [4cade1c](<https://github.com/dimaslanjaka/bin/commit/4cade1c>)
    
    build(build): update esbuild target from node14 to node18
    
    Target the lowest compatible version (node18) in the range 18-24
    for broader syntax compatibility across modern Node.js versions.
- [ _2026-06-06 21:18:43_ ] [89895f8](<https://github.com/dimaslanjaka/bin/commit/89895f8>)
    
    ci(workflows): add test-compiled workflow for syntax checking built artifacts
    
    Add a workflow_run trigger that downloads compiled artifacts from the
    Build Release workflow and runs node -c syntax checks across Node 18-24.
    
    - build-release.yml: upload lib/, binaries/, dist, lock files after build
    - test-compiled.yml: workflow_run trigger, artifact download, syntax check
    - test/test-compiled.cjs: syntax check runner with deferred empty-dir throw
- [ _2026-06-06 21:20:26_ ] [f30b23a](<https://github.com/dimaslanjaka/bin/commit/f30b23a>)
    
    fix(workflows): use explicit node/python versions in setup-environments
    
    Replace CI_NODE_VERSION and CI_PYTHON_VERSION env vars with hardcoded
    values to avoid potential issues when env vars are not defined.
- [ _2026-06-06 21:21:21_ ] [a35b559](<https://github.com/dimaslanjaka/bin/commit/a35b559>) refactor: improve formatting of async spawn calls in git-purge and build-readme
- [ _2026-06-06 21:30:22_ ] [b54f7e8](<https://github.com/dimaslanjaka/bin/commit/b54f7e8>)
    
    fix(test): test-compiled only validate .cjs in binaries/
    
    binaries/ only ever contains .cjs files (build.mjs doesn't produce
    .mjs or .js output there). Per-directory extension lists avoid
    false failures from missing .mjs/.js in binaries/.
- [ _2026-06-06 21:39:53_ ] [f61aee3](<https://github.com/dimaslanjaka/bin/commit/f61aee3>) fix(ci): checkout with submodules in test-compiled workflow
- [ _2026-06-06 21:41:35_ ] [4679d5e](<https://github.com/dimaslanjaka/bin/commit/4679d5e>) chore(hooks): auto-stage submodule pointer changes in pre-commit
- [ _2026-06-06 21:44:18_ ] [ac66ab0](<https://github.com/dimaslanjaka/bin/commit/ac66ab0>) fix(ci): use corepack yarn in test-compiled install step
- [ _2026-06-06 21:45:41_ ] [164da54](<https://github.com/dimaslanjaka/bin/commit/164da54>) docs(agents): note to keep commit.txt after commit
- [ _2026-06-06 22:01:33_ ] [1c41bf4](<https://github.com/dimaslanjaka/bin/commit/1c41bf4>)
    
    ci: bump actions versions and add caching to test-compiled
    
    - bump actions/checkout to v6, actions/cache to v5, actions/configure-pages
      to v6, actions/setup-python to v6, actions/deploy-pages to v5
    - add cache step with hash-files to test-compiled workflow
- [ _2026-06-06 22:08:45_ ] [3af1935](<https://github.com/dimaslanjaka/bin/commit/3af1935>) refactor(package): remove doc header and print tarball tree after pack
- [ _2026-06-06 22:37:57_ ] [74ee7a5](<https://github.com/dimaslanjaka/bin/commit/74ee7a5>)
    
    feat(node-package-packer): add workspace protocol transform and export helpers for testability
    
    Add resolveWorkspaceVersions() and transformWorkspaceProtocols() to resolve yarn workspace:^/*/~ references before packing. Export slugifyPkgName, resolveWorkspaceVersions, transformWorkspaceProtocols, resolveNewestTarball for unit testing. Integrate transform into bundle() with try/finally restore.
    
    Add 22 unit tests for all exported helpers in test/node-package-packer/build-tarball.test.mjs.
- [ _2026-06-06 22:43:42_ ] [118322d](<https://github.com/dimaslanjaka/bin/commit/118322d>) chore: add workflow_dispatch trigger to test-compiled workflow
- [ _2026-06-06 22:44:20_ ] [d4ed6d6](<https://github.com/dimaslanjaka/bin/commit/d4ed6d6>) chore: set cancel-in-progress to false in test-compiled workflow
- [ _2026-06-06 23:40:39_ ] [e8a55db](<https://github.com/dimaslanjaka/bin/commit/e8a55db>) fix: update ai-toolkit dependency to use direct URL instead of workspace protocol
- [ _2026-06-07 06:44:30_ ] [fe80562](<https://github.com/dimaslanjaka/bin/commit/fe80562>)
    
    feat(node-package-packer): add workspace protocol transform and get-workspaces cache module
    
    - Add get-workspaces.cjs: workspace info resolver with two-tier cache
      (in-memory + disk) keyed by checksum of package.json, .gitmodules, lock file
    - Add get-workspaces-types.d.ts: TypeScript type definitions
    - Refactor transformWorkspaceProtocols to async, use getWorkspacesInfo
      and resolve tarballs to raw GitHub URLs via getGithubRawUrl
    - Update build-tarball.test.mjs: static imports, async test handlers
- [ _2026-06-07 06:50:49_ ] [f4fd69a](<https://github.com/dimaslanjaka/bin/commit/f4fd69a>)
    
    build(deps): use workspace protocol for local package dependencies
    
    Switch ai-toolkit, cross-spawn, and git-command-helper from
    pinned tarball URLs to workspace:^ protocol. The build-tarball.mjs
    transformWorkspaceProtocols will resolve these to raw GitHub tarball
    URLs during release packaging.
- [ _2026-06-07 07:17:48_ ] [cfa4827](<https://github.com/dimaslanjaka/bin/commit/cfa4827>)
    
    feat(proxy-switcher-test): add CLI to test Proxy Switcher local ports
    
    Tests HTTP (127.0.0.1:3128) and SOCKS5 (127.0.0.1:1080) proxy ports
    configured by Proxy Switcher software. Supports --http-port, --socks-port,
    --host, and --help CLI options via getArgs().
- [ _2026-06-07 07:21:04_ ] [09c941e](<https://github.com/dimaslanjaka/bin/commit/09c941e>)
    
    test(node-package-packer): add test for workspace protocol to tarball transformation
    
    Verify that transformWorkspaceProtocols converts workspace:^ deps
    (cross-spawn, git-command-helper, ai-toolkit) into remote tarball URLs.
- [ _2026-06-07 20:43:15_ ] [30616cb](<https://github.com/dimaslanjaka/bin/commit/30616cb>)
    
    feat(git): add git-diff-staged-ai command with puter AI provider
    
    Add new CLI command that shows staged git diff and generates
    conventional commit messages via Puter AI. Supports model selection
    (--model), file filtering, and optional auto-commit (--commit).
    
    Includes core library module (free of process.exit for testability),
    CLI entry point, Jest tests, documentation, build config, and readme
    table update.
- [ _2026-06-07 20:44:28_ ] [368d289](<https://github.com/dimaslanjaka/bin/commit/368d289>)
    
    fix(cli): handle --no- prefix for false boolean flags
    
    When a boolean flag is false, pass --no-<flag> to the subcommand
    instead of silently dropping it. Ensures flags like --no-headless
    are correctly forwarded.
- [ _2026-06-07 20:45:04_ ] [f68f308](<https://github.com/dimaslanjaka/bin/commit/f68f308>)
    
    chore: update AGENTS.md submodule docs and fix formatting
    
    Document workspace packages as git submodules with remote and branch
    info. Format install-opencode-plugins-cli.ts spawn options.
- [ _2026-06-07 20:58:31_ ] [40cc08a](<https://github.com/dimaslanjaka/bin/commit/40cc08a>)
    
    build(deps): update pinned dependency resolutions
    
    Update cross-spawn and git-command-helper resolution SHAs
    to their latest pinned versions.
- [ _2026-06-07 14:02:15_ ] [781c5ca](<https://github.com/dimaslanjaka/bin/commit/781c5ca>)
    
    chore: update build from https://github.com/dimaslanjaka/bin/commit/40cc08a421c1b09e6260a59278ef8e1ed6401ad0
    
    commit hash: d5959f
    
    commit url: https://github.com/dimaslanjaka/bin/commit/40cc08a421c1b09e6260a59278ef8e1ed6401ad0
    
    runner: https://github.com/dimaslanjaka/bin/commit/40cc08a421c1b09e6260a59278ef8e1ed6401ad0/checks/27094661821
- [ _2026-06-07 21:45:39_ ] [2ca2248](<https://github.com/dimaslanjaka/bin/commit/2ca2248>) fix(ci): remove redundant main repo checkout from composite action
- [ _2026-06-08 13:59:57_ ] [4d6ebc0](<https://github.com/dimaslanjaka/bin/commit/4d6ebc0>) feat(config): add optionName override to getConfig and export it
- [ _2026-06-08 14:13:20_ ] [6540c1e](<https://github.com/dimaslanjaka/bin/commit/6540c1e>) refactor(binary-collections): replace module-level GITHUB_ACCESS_TOKEN with lazy getGithubToken()
- [ _2026-06-08 14:14:48_ ] [fe8f249](<https://github.com/dimaslanjaka/bin/commit/fe8f249>) "chore(build): clarify comment about binary file copies
- [ _2026-06-08 14:16:52_ ] [512ce3c](<https://github.com/dimaslanjaka/bin/commit/512ce3c>) "build(deps): update git-command-helper and eslint-base-config resolutions
- [ _2026-06-08 14:22:37_ ] [9007a74](<https://github.com/dimaslanjaka/bin/commit/9007a74>)
    
    refactor(config): convert getGithubToken to async
    
    getGithubToken now awaits getConfig to check config.githubToken
    before falling back to env vars. All callers updated:
    
    - utils.cjs: lazy async getToken()/getHeaders() with memoization
    - clean-github-actions-caches.cjs: async/await throughout
    - package-resolutions-updater.mjs: await token in fetchJson
    - submodule-install.cjs: wrap main in async IIFE
- [ _2026-06-08 14:25:26_ ] [0fb3356](<https://github.com/dimaslanjaka/bin/commit/0fb3356>)
    
    feat(bin): add exec command as generic runner wrapper for scripts
    
    Introduce `exec.py` — a Python-based generic runner that auto-detects
    runtime (Node.js, PHP, Python) by file extension and dispatches the
    target script accordingly. Includes platform launchers:
    - `bin/exec` (POSIX sh)
    - `bin/exec.cmd` (Windows CMD)
    - `bin/exec.ps1` (PowerShell)
    
    Supports `--runtime`, `--keep-open`, `--same-terminal`, `--cwd`,
    `--dry-run`, and custom binary paths.
- [ _2026-06-08 14:50:37_ ] [3e308d0](<https://github.com/dimaslanjaka/bin/commit/3e308d0>)
    
    feat(exec): add 6 new runtimes and simplify CLI to single --lang flag
    
    - add Ruby, Go, Deno, Lua, Shell, and Perl runtime support
    - merge --runtime/-r and individual --node/--php/--python flags into --lang/-l
    - --lang <name> selects runtime, --lang <name>=<path> also overrides binary
    - add runtime aliases (rb→ruby, ts→deno, bash→sh, pl→perl, etc.)
    - add environment variable overrides (RUBY_BIN, GO_BIN, DENO_BIN, LUA_BIN, SH_BIN, PERL_BIN)
    - deduplicate binary flag parsing with _RUNTIME_BIN_ATTR map
    - update help text with examples for all runtimes
- [ _2026-06-08 07:55:28_ ] [a2b2681](<https://github.com/dimaslanjaka/bin/commit/a2b2681>)
    
    chore: update build from https://github.com/dimaslanjaka/bin/commit/3e308d00ecfccabe4d873a6bc5d0c96e0d56ac3e
    
    commit hash: 915341
    
    commit url: https://github.com/dimaslanjaka/bin/commit/3e308d00ecfccabe4d873a6bc5d0c96e0d56ac3e
    
    runner: https://github.com/dimaslanjaka/bin/commit/3e308d00ecfccabe4d873a6bc5d0c96e0d56ac3e/checks/27123594335
- [ _2026-06-09 02:53:33_ ] [a6c3828](<https://github.com/dimaslanjaka/bin/commit/a6c3828>)
    
    feat(backend): add full CORS support to workflow-badge.php
    
    Replace commented-out CORS stubs with a proper allowCors() function
    that handles CLI detection, dynamic origin reflection, credentials,
    preflight OPTIONS (200), and optional browser cache disabling.
- [ _2026-06-09 02:57:53_ ] [7230d57](<https://github.com/dimaslanjaka/bin/commit/7230d57>)
    
    refactor(backend): rename backend/ directory to php_backend/
    
    Rename the PHP backend directory and update all references in
    scripts/upload-backend.mjs, docs-src/upload-backend.md,
    docs-src/workflow-badge.md, and memory files to point to the
    new php_backend/ path.
- [ _2026-06-08 20:02:19_ ] [28c1073](<https://github.com/dimaslanjaka/bin/commit/28c1073>)
    
    chore: update build from https://github.com/dimaslanjaka/bin/commit/7230d57123440e57c9a8668b069070a29b59b8ae
    
    commit hash: 48fcf6
    
    commit url: https://github.com/dimaslanjaka/bin/commit/7230d57123440e57c9a8668b069070a29b59b8ae
    
    runner: https://github.com/dimaslanjaka/bin/commit/7230d57123440e57c9a8668b069070a29b59b8ae/checks/27163425900
- [ _2026-06-09 03:07:34_ ] [5a38041](<https://github.com/dimaslanjaka/bin/commit/5a38041>)
    
    fix(scripts): use commit-pinned npx URL and skip-build mode on yarn add
    
    - Replace hardcoded master branch URL in npx command with LATEST_REMOTE_COMMIT_HASH for deterministic deployments
    - Add --mode skip-build to yarn add (Yarn Berry syntax) to skip lifecycle scripts on remote
- [ _2026-06-09 03:12:25_ ] [65edd97](<https://github.com/dimaslanjaka/bin/commit/65edd97>) chore(deps): add ai-toolkit resolution pinned artifact
- [ _2026-06-08 20:16:17_ ] [a5f05fc](<https://github.com/dimaslanjaka/bin/commit/a5f05fc>)
    
    chore: update build from https://github.com/dimaslanjaka/bin/commit/4da2373fe2c83d4a604cf5abc2d51d498b7f9cb8
    
    commit hash: 4da237
    
    commit url: https://github.com/dimaslanjaka/bin/commit/4da2373fe2c83d4a604cf5abc2d51d498b7f9cb8
    
    runner: https://github.com/dimaslanjaka/bin/commit/4da2373fe2c83d4a604cf5abc2d51d498b7f9cb8/checks/27164194285
- [ _2026-06-09 05:31:20_ ] [6f3cd39](<https://github.com/dimaslanjaka/bin/commit/6f3cd39>)
    
    refactor(ci-yaml-fixtures): restructure YAML generation into JS fixture submodule
    
    - Move workflow-test-data.cjs into ci-yaml-fixtures/ subdirectory
    - Add setup-environments-data.cjs fixture for the composite action
    - Update generator to produce action.yml alongside test.yml
    - Stage generated action.yml in pre-commit hook
    - Update docs to reflect both generated outputs
- [ _2026-06-09 05:36:07_ ] [7725266](<https://github.com/dimaslanjaka/bin/commit/7725266>)
    
    refactor(generate-test-ci): clean up redundant code and dynamic help path
    
    - Remove unused __dirname variable
    - Replace hardcoded script name in help with dynamic path.relative()
    - Replace manual replace(/\\/g, '/') with path.toUnix()
    - Extract duplicate YAML write+prettier pattern into writeYamlFile helper
- [ _2026-06-09 05:39:28_ ] [5bc01b1](<https://github.com/dimaslanjaka/bin/commit/5bc01b1>) refactor(cli-help): replace hardcoded script paths with dynamic relative paths
- [ _2026-06-08 22:45:28_ ] [5bd835d](<https://github.com/dimaslanjaka/bin/commit/5bd835d>)
    
    chore: update build from https://github.com/dimaslanjaka/bin/commit/5bc01b1d49877d4d647ba22031a6182e82b9f3e9
    
    commit hash: 964f13
    
    commit url: https://github.com/dimaslanjaka/bin/commit/5bc01b1d49877d4d647ba22031a6182e82b9f3e9
    
    runner: https://github.com/dimaslanjaka/bin/commit/5bc01b1d49877d4d647ba22031a6182e82b9f3e9/checks/27171665065
- [ _2026-06-09 06:02:38_ ] [d3546ef](<https://github.com/dimaslanjaka/bin/commit/d3546ef>)
    
    refactor(cache-cleaner): migrate node-cache-cleaner modules into cache-cleaner/
    
    Move npm.ts, npx.ts, yarn.ts from src/node-cache-cleaner/ to
    src/cache-cleaner/ and update CLI imports accordingly.
- [ _2026-06-09 06:04:09_ ] [7942827](<https://github.com/dimaslanjaka/bin/commit/7942827>)
    
    feat(del-gradle): add Gradle cache/temp cleaning with --global flag
    
    Extract Gradle cleanup logic into reusable src/cache-cleaner/gradle.cjs
    with findGradleProjects(), cleanGradleBuildDirs(), getGradleCacheDirs(),
    and cleanGradleCacheDirs() functions. Add --help/-h and --global/-g flags
    to the del-gradle CLI for cleaning user-level Gradle cache directories
    (caches/, wrapper/dists/, daemon/, native/, buildOutputCleanup/).
- [ _2026-06-09 06:05:03_ ] [9cf7ea3](<https://github.com/dimaslanjaka/bin/commit/9cf7ea3>)
    
    docs: update del-gradle and node-cache-cleaner documentation
    
    Expand del-gradle doc with --help and --global flag documentation,
    fix stale source link (.js -> .cjs), add cache subdirectory breakdown.
    Update node-cache-cleaner doc to reference src/cache-cleaner/ module location.
- [ _2026-06-09 06:19:56_ ] [b408a74](<https://github.com/dimaslanjaka/bin/commit/b408a74>)
    
    refactor(cache-cleaner): convert del-yarn-caches to TypeScript
    
    Replace manual glob + delStream approach with cleanProjectYarnCaches()
    from src/cache-cleaner/yarn.ts. Register the del-yarn-caches binary in
    build.config.cjs.
- [ _2026-06-09 06:20:42_ ] [66164ea](<https://github.com/dimaslanjaka/bin/commit/66164ea>)
    
    feat(cache-cleaner): add project-level Yarn cache cleaning
    
    Add findProjectYarnCaches() and cleanProjectYarnCaches() to
    src/cache-cleaner/yarn.ts. Update node-cache-cleaner CLI to clean
    project caches by default, with -g/--global for global NPM/Yarn/NPX caches.
- [ _2026-06-09 06:21:27_ ] [1352333](<https://github.com/dimaslanjaka/bin/commit/1352333>) test(del-gradle): fix require path to use .cjs extension
- [ _2026-06-08 23:25:17_ ] [38293a0](<https://github.com/dimaslanjaka/bin/commit/38293a0>)
    
    chore: update build from https://github.com/dimaslanjaka/bin/commit/135233310a1f5bcb8b15bc2a1720681cac481136
    
    commit hash: e2566d
    
    commit url: https://github.com/dimaslanjaka/bin/commit/135233310a1f5bcb8b15bc2a1720681cac481136
    
    runner: https://github.com/dimaslanjaka/bin/commit/135233310a1f5bcb8b15bc2a1720681cac481136/checks/27173336241
- [ _2026-06-09 06:25:32_ ] [1f6a0fb](<https://github.com/dimaslanjaka/bin/commit/1f6a0fb>) fix(settings): update default terminal profile to Short PowerShell 7 and set font family
- [ _2026-06-09 06:25:59_ ] [a0aea3d](<https://github.com/dimaslanjaka/bin/commit/a0aea3d>) feat(dependencies): add new dependencies for OpenCode AI plugin and moment-timezone
- [ _2026-06-08 23:51:13_ ] [3708379](<https://github.com/dimaslanjaka/bin/commit/3708379>)
    
    chore: update build from https://github.com/dimaslanjaka/bin/commit/a0aea3d9d6c25f5849d849603310cd8662564805
    
    commit hash: a0aea3
    
    commit url: https://github.com/dimaslanjaka/bin/commit/a0aea3d9d6c25f5849d849603310cd8662564805
    
    runner: https://github.com/dimaslanjaka/bin/commit/a0aea3d9d6c25f5849d849603310cd8662564805/checks/27174361079
- [ _2026-06-09 08:18:48_ ] [a86617f](<https://github.com/dimaslanjaka/bin/commit/a86617f>)
    
    feat(bin): add local execution fallback mechanism to bcc scripts
    
    bcc now attempts local binary-collections first, then falls back to
    remote tarball if local fails (and vice versa for errors). Both bash
    and cmd versions updated with structured error messaging.
- [ _2026-06-09 08:19:57_ ] [2a129a6](<https://github.com/dimaslanjaka/bin/commit/2a129a6>)
    
    refactor(bin): rename clean-nodemodule to del-nm and add Windows deletion scripts
    
    - Rename clean-nodemodule → del-nm (bash) with improved safety: moves
      node_modules to /tmp before background deletion instead of in-place rm
    - Add del-nm.cmd: Windows equivalent with move + background delete
    - Add delete-packages-node-modules.cmd: parallel node_modules deletion
      for workspaces under packages/ with configurable worker count
    - Remove stale clean-nodemodule/clean-nodemodules entries from package.json
    - Register del-nm binary in package.json
- [ _2026-06-09 02:10:38_ ] [2e47e25](<https://github.com/dimaslanjaka/bin/commit/2e47e25>)
    
    chore: update build from https://github.com/dimaslanjaka/bin/commit/2a129a667901c35b92116cf4382f8b4b6378df5c
    
    commit hash: 2a129a
    
    commit url: https://github.com/dimaslanjaka/bin/commit/2a129a667901c35b92116cf4382f8b4b6378df5c
    
    runner: https://github.com/dimaslanjaka/bin/commit/2a129a667901c35b92116cf4382f8b4b6378df5c/checks/27179346326
- [ _2026-06-09 09:40:31_ ] [b7b356b](<https://github.com/dimaslanjaka/bin/commit/b7b356b>)
    
    chore(opencode): enable snapshot, formatter, LSP, and MCP playwright
    
    - Enable snapshot, formatter, and LSP features
    - Configure MCP Playwright server via npx
    - Add opencode-helicone-session plugin
    - Disable build and plan modes
    - Switch shell to pwsh
- [ _2026-06-09 10:02:51_ ] [fcd0df5](<https://github.com/dimaslanjaka/bin/commit/fcd0df5>) feat(config): add default export for module.exports
- [ _2026-06-09 11:13:46_ ] [6c0dd15](<https://github.com/dimaslanjaka/bin/commit/6c0dd15>)
    
    feat(node-package-packer): add normalize-resolutions module with config wiring and tests
    
    Add normalizeResolutions() and restoreResolutions() to replace pinned
    commit hashes in package.json resolutions with branch/tag names before
    packing. Backups are stored under getTempPath('normalize-resolutions/').
    
    Also add makeTempDir() to config.cjs supporting both project-temp
    and global-temp modes, normalizeResolutions type to config-types.ts,
    and config example in binary-collections.config-example.js.
- [ _2026-06-09 11:16:55_ ] [d626696](<https://github.com/dimaslanjaka/bin/commit/d626696>)
    
    docs(test): add JSDoc documentation to all exported test helper functions
    
    Add comprehensive JSDoc blocks for getCwd(), run(), ensureRepoExists(),
    ensureYarnProject(), and installTarball() in test/env.cjs.
- [ _2026-06-09 11:18:56_ ] [4714f4b](<https://github.com/dimaslanjaka/bin/commit/4714f4b>) chore(deps): update pinned resolution commit hashes for sbg-utility, eslint-base-config, ai-toolkit
- [ _2026-06-09 11:23:59_ ] [c7cfafe](<https://github.com/dimaslanjaka/bin/commit/c7cfafe>)
    
    docs(agents): update staged-file-commiter with AI context workflow
    
    - Add AI-inferred context analysis for commit messages
    - Include cross-shell examples (Bash, PowerShell, CMD)
    - Add Key Principles section
    - Emphasize commit.txt usage and never mixing contexts
- [ _2026-06-09 04:31:05_ ] [4ded256](<https://github.com/dimaslanjaka/bin/commit/4ded256>)
    
    chore: update build from https://github.com/dimaslanjaka/bin/commit/c7cfafe2a1928e4920a0843087fad4e5ca5be184
    
    commit hash: c7cfaf
    
    commit url: https://github.com/dimaslanjaka/bin/commit/c7cfafe2a1928e4920a0843087fad4e5ca5be184
    
    runner: https://github.com/dimaslanjaka/bin/commit/c7cfafe2a1928e4920a0843087fad4e5ca5be184/checks/27183898748
- [ _2026-06-09 11:38:05_ ] [def2e4e](<https://github.com/dimaslanjaka/bin/commit/def2e4e>)
    
    feat(node-package-packer): add --normalize-resolutions flag for pre-pack hash normalization
    
    Before pack, replaces pinned commit hashes in resolutions with branch/tag names.
    After pack, restores the original package.json from backup (tmp/normalize-resolutions/).
    
    Custom mappings are configurable via binary-collections.config.js normalizeResolutions array.
- [ _2026-06-09 04:42:16_ ] [6b90df0](<https://github.com/dimaslanjaka/bin/commit/6b90df0>)
    
    chore: update build from https://github.com/dimaslanjaka/bin/commit/def2e4e0ff2995736f7063d4ce64928cbfcd1c5b
    
    commit hash: def2e4
    
    commit url: https://github.com/dimaslanjaka/bin/commit/def2e4e0ff2995736f7063d4ce64928cbfcd1c5b
    
    runner: https://github.com/dimaslanjaka/bin/commit/def2e4e0ff2995736f7063d4ce64928cbfcd1c5b/checks/27184279200
- [ _2026-06-09 11:59:52_ ] [16377be](<https://github.com/dimaslanjaka/bin/commit/16377be>) chore: remove outdated update:packer script from package.json
- [ _2026-06-09 12:12:37_ ] [f0e784c](<https://github.com/dimaslanjaka/bin/commit/f0e784c>) chore: update file paths in package.json to be relative
- [ _2026-06-09 14:57:12_ ] [63a05cc](<https://github.com/dimaslanjaka/bin/commit/63a05cc>) fix: update ai-toolkit dependency to use scoped package and correct URLs
- [ _2026-06-09 15:56:10_ ] [ecd2d93](<https://github.com/dimaslanjaka/bin/commit/ecd2d93>) test(node-package-packer): correct ai-toolkit package name with scope
- [ _2026-06-09 16:12:22_ ] [b7a5b1c](<https://github.com/dimaslanjaka/bin/commit/b7a5b1c>) chore: exclude packages directory from file inclusion in package.json
- [ _2026-06-09 17:33:01_ ] [b2ff1aa](<https://github.com/dimaslanjaka/bin/commit/b2ff1aa>) chore(yarn): limit task pool concurrency
- [ _2026-06-09 18:01:12_ ] [0b2df77](<https://github.com/dimaslanjaka/bin/commit/0b2df77>) fix: improve node_modules deletion script and error handling
- [ _2026-06-09 21:38:30_ ] [4aab796](<https://github.com/dimaslanjaka/bin/commit/4aab796>)
    
    fix(tooling): resolve eslint resolution in lint-staged config
    
    Change npx eslint to corepack yarn exec eslint to ensure the project-local eslint
    binary is used instead of a globally installed version, avoiding version mismatch errors
    (scopeManager.addGlobals is not a function)
- [ _2026-06-09 21:42:24_ ] [7872a6a](<https://github.com/dimaslanjaka/bin/commit/7872a6a>)
    
    refactor(node-package-packer): centralize utils, add JSDoc, parameterize paths, fix .tgz extension
    
    Move slugifyPkgName to utils.cjs, add comprehensive JSDoc to bundle(),
    make process.cwd() and rootDir configurable parameters,
    fix double .tgz extension in pack-with-yarn.mjs
- [ _2026-06-09 21:46:25_ ] [90185d3](<https://github.com/dimaslanjaka/bin/commit/90185d3>)
    
    test(node-package-packer): update tests for refactored internals
    
    Update test imports after slugifyPkgName move to utils.cjs,
    rename build-tarball.test.mjs to transform-workspace-protocols.test.mjs,
    add dedicated tests for resolve-newest-tarball, resolve-workspace-versions,
    scoped-package, and slugify-pkg-name
- [ _2026-06-09 21:48:32_ ] [681b0fc](<https://github.com/dimaslanjaka/bin/commit/681b0fc>) chore(deps): unpin cross-spawn and git-command-helper, move eslint-base-config to resolutions
- [ _2026-06-09 21:49:52_ ] [f02b1f1](<https://github.com/dimaslanjaka/bin/commit/f02b1f1>) fix(import): update ai-toolkit import path to @dimaslanjaka/ai-toolkit
- [ _2026-06-09 21:51:25_ ] [27d110a](<https://github.com/dimaslanjaka/bin/commit/27d110a>) chore(releases): update build artifacts
- [ _2026-06-09 21:55:47_ ] [e74af15](<https://github.com/dimaslanjaka/bin/commit/e74af15>) fix(build): add missing packages to bundled list and enable cleaning option
- [ _2026-06-09 22:02:59_ ] [ed1ce00](<https://github.com/dimaslanjaka/bin/commit/ed1ce00>)
    
    feat(bin): support monorepo node_modules cleanup
    
    Add recursive scanning to del-nm so it can remove node_modules folders across subdirectories from the current working directory.
    
    Move discovered node_modules folders into a temporary trash directory before deleting them in the background, and skip common generated or dependency folders such as tmp, dist, vendor, venv, .venv, and .cache.
- [ _2026-06-09 22:25:54_ ] [098f0e3](<https://github.com/dimaslanjaka/bin/commit/098f0e3>)
    
    feat(ci): add generate-ci CLI command to run CI workflow generators
    
    Register generate-ci bin alias and implement the command that
    discovers and executes generate-test-ci-step-cli scripts.
- [ _2026-06-09 22:48:16_ ] [46eba68](<https://github.com/dimaslanjaka/bin/commit/46eba68>)
    
    refactor(ci): optimize checkout steps and test CI generation
    
    - Replace repetitive package checkout steps with JS-generated map from data array
    - Add continue-on-error to global install step
    - Add clean install dependencies step (deletes node_modules, venv, vendor, lock files)
    - Refactor test CI generation to detect ESM/CJS from package.json instead of file extension
    - Use relative path patterns and --bail=1 in jest commands
- [ _2026-06-09 22:51:59_ ] [f356861](<https://github.com/dimaslanjaka/bin/commit/f356861>) feat(ci): add static-blog-generator package to CI environment setup
- [ _2026-06-09 23:18:45_ ] [aa171a8](<https://github.com/dimaslanjaka/bin/commit/aa171a8>)
    
    refactor(github-workflows): extract repo verifier into shared module
    
    - Create repo-verifier.cjs with parseRepoSlug, getCurrentRepoIdentifiers,
      getSubmoduleRepos, shouldSkipEntry, and filterRepoInfo
    - Refactor setup-environments-data.cjs to use shared verifier and add
      binary-collections entry
    - Suppress prettier format output noise in generate-test-ci-step-cli.mjs
    - Regenerate .github/actions/setup-environments/action.yml
- [ _2026-06-09 23:31:16_ ] [62edc16](<https://github.com/dimaslanjaka/bin/commit/62edc16>)
    
    fix(build): replace tsc -b with tsc -p in build script
    
    The -b flag uses build mode with project references which isn't the
    intended behavior. -p specifies the project config directly.
    Regenerated release artifacts to match.
- [ _2026-06-10 00:22:34_ ] [876ef86](<https://github.com/dimaslanjaka/bin/commit/876ef86>)
    
    feat(ci): add build-release CI workflow generator CLI
    
    Introduce a CLI to generate the build-release.yml workflow from a JS fixture object, along with a shared writeYamlFile utility in utils.cjs. The generate-test-ci CLI is refactored to use the shared utility, eliminating duplication.
- [ _2026-06-10 00:23:28_ ] [053e645](<https://github.com/dimaslanjaka/bin/commit/053e645>)
    
    refactor(bin): reorganize command aliases alphabetically and remove obsolete pack script
    
    Sort all binary entries alphabetically in build.config.cjs, add several new
    aliases (generate-build-ci, actions-badge, wf-badge, opencode-cli, etc.),
    and update package.json bin field accordingly. Delete the obsolete package.cjs
    wrapper as the pack script now calls the source directly.
- [ _2026-06-10 00:28:48_ ] [d07e4fe](<https://github.com/dimaslanjaka/bin/commit/d07e4fe>)
    
    fix(hooks): stage auto-generated build-release workflow in pre-commit hook
    
    Add build-release.yml to the list of auto-staged generated files so it is
    included when the build-release CI workflow is regenerated locally.
- [ _2026-06-10 00:36:22_ ] [b29b184](<https://github.com/dimaslanjaka/bin/commit/b29b184>)
    
    fix(packer): add debug logging, fix spawn stdio/env, and trim bundled deps
    
    - Change spawn stdio from 'ignore' to 'inherit' and pass full process.env
    - Add diagnostic console.log statements throughout the packer pipeline
    - Comment out sbg-utility, git-command-helper, and cross-spawn from tsup bundled packages
- [ _2026-06-10 06:35:43_ ] [2d6130e](<https://github.com/dimaslanjaka/bin/commit/2d6130e>) chore(opencode): disable formatter/lsp, switch plugin to git url
- [ _2026-06-10 06:36:07_ ] [8d84add](<https://github.com/dimaslanjaka/bin/commit/8d84add>) chore(config): increase yarn taskPoolConcurrency, add bunfig.toml
- [ _2026-06-10 06:36:44_ ] [07534b0](<https://github.com/dimaslanjaka/bin/commit/07534b0>) chore(deps): unpin eslint-base-config to semver ^1.0.2
- [ _2026-06-10 06:37:07_ ] [67073ce](<https://github.com/dimaslanjaka/bin/commit/67073ce>) ci(generate-ci): add build-release ci generator to script list
- [ _2026-06-10 06:39:43_ ] [61dec34](<https://github.com/dimaslanjaka/bin/commit/61dec34>) ci: update binary-collections repo reference to dimaslanjaka/bin
- [ _2026-06-10 06:45:57_ ] [2cc0650](<https://github.com/dimaslanjaka/bin/commit/2cc0650>) chore(build): fix trailing commas in tsup bundled packages list
- [ _2026-06-10 06:47:33_ ] [4b928ff](<https://github.com/dimaslanjaka/bin/commit/4b928ff>)
    
    ci: remove redundant install steps from workflow fixtures
    
    Installation step is already handled by the setup-environments composite action,
    making these standalone install steps redundant in the build-release and test
    workflow fixtures.
- [ _2026-06-10 06:57:13_ ] [867f1ea](<https://github.com/dimaslanjaka/bin/commit/867f1ea>)
    
    feat(ci): add tiered install strategy to setup-environments data
    
    Add a normal install step that runs first with pipefail logging and Yarn error
    diagnostics. The existing clean install step now runs conditionally only when
    the normal install step fails (steps.install.conclusion === 'failure').
- [ _2026-06-10 07:03:01_ ] [e064ccb](<https://github.com/dimaslanjaka/bin/commit/e064ccb>)
    
    fix(ci): use correct GitHub Actions equality operator in setup-environments
    
    GitHub Actions expressions use == for equality comparison, not ===.
- [ _2026-06-10 09:42:56_ ] [3febf1c](<https://github.com/dimaslanjaka/bin/commit/3febf1c>)
    
    fix(del-nm): clean up tmp trash directory when no node_modules found
    
    Start background removal of the %TRASH% directory when the scan completes
    with no node_modules to delete.
- [ _2026-06-10 09:44:11_ ] [3a76b76](<https://github.com/dimaslanjaka/bin/commit/3a76b76>) chore: update yarn v4.13.0
- [ _2026-06-10 09:51:00_ ] [3c32a1c](<https://github.com/dimaslanjaka/bin/commit/3c32a1c>) chore(deps): upgrade yarn from v4.9.2 to v4.13.0 and add dependency resolutions
- [ _2026-06-10 10:08:55_ ] [ae9d30d](<https://github.com/dimaslanjaka/bin/commit/ae9d30d>) fix(ci): correct quote nesting in setup-environments step condition
- [ _2026-06-10 10:16:17_ ] [401f7b3](<https://github.com/dimaslanjaka/bin/commit/401f7b3>) refactor(hooks): switch pre-commit to unified CI generation script
- [ _2026-06-10 14:14:33_ ] [7995457](<https://github.com/dimaslanjaka/bin/commit/7995457>) build(tsup): add axios, proxy-agent, https-proxy-agent, socks-proxy-agent to bundled packages
- [ _2026-06-10 14:15:35_ ] [f8c398f](<https://github.com/dimaslanjaka/bin/commit/f8c398f>) ci(pre-commit): add tarball size check for releases
- [ _2026-06-10 14:16:01_ ] [bb7cd1f](<https://github.com/dimaslanjaka/bin/commit/bb7cd1f>) ci(setup-environments): add prepare script step to CI setup action
- [ _2026-06-10 14:24:02_ ] [c5d2432](<https://github.com/dimaslanjaka/bin/commit/c5d2432>)
    
    build(build-tsup): drop esm output, bundle cjs only
    
    Remove ESM format from tsup build configuration and update
    package.json exports accordingly. Only CJS (.cjs) output is
    now produced.
    
    - Restrict format to 'cjs' only
    - Remove ESM-specific banner (createRequire shim)
    - Simplify outExtension to fixed CJS mapping
    - Update package.json main to lib/index.cjs
    - Remove import condition from exports field
- [ _2026-06-10 14:38:04_ ] [3567dd6](<https://github.com/dimaslanjaka/bin/commit/3567dd6>)
    
    chore(config): clean up gitignore patterns and package files field
    
    - Ignore .opencode/ directory and virtual environment folders
    - Simplify files field by removing unnecessary ./ prefixes and exclusions
- [ _2026-06-10 14:48:45_ ] [8efb49b](<https://github.com/dimaslanjaka/bin/commit/8efb49b>) build(package): simplify files field and drop .github from published files
- [ _2026-06-10 14:50:52_ ] [142f02b](<https://github.com/dimaslanjaka/bin/commit/142f02b>)
    
    refactor(node-package-packer): align bundleWithYarn signature and log tarball size
    
    - Move withFilename derivation into bundleWithYarn so its
      signature matches bundleWithBun and bundleWithNpm (5 params)
    - Log each generated tarball's size in getPackageHashes
- [ _2026-06-11 02:18:30_ ] [6e56f03](<https://github.com/dimaslanjaka/bin/commit/6e56f03>)
    
    fix(node-package-packer): remove workspace artifacts before pack to reduce tarball size
    
    Yarn Berry includes workspace packages in yarn pack output, dragging in
    submodule build artifacts (release tarballs, yarn releases) that bloat the
    root package tarball past GitHub's 30 MB limit.
    
    Remove these large workspace artifacts before packing. They are git-tracked
    in submodules so always recoverable via git checkout.
- [ _2026-06-10 19:24:23_ ] [26ba034](<https://github.com/dimaslanjaka/bin/commit/26ba034>)
    
    chore: update build from https://github.com/dimaslanjaka/bin/commit/6e56f03e032e6fef6cd3dc02c4652353cf5e0665
    
    commit hash: 6e56f0
    
    commit url: https://github.com/dimaslanjaka/bin/commit/6e56f03e032e6fef6cd3dc02c4652353cf5e0665
    
    runner: https://github.com/dimaslanjaka/bin/commit/6e56f03e032e6fef6cd3dc02c4652353cf5e0665/checks/27300416537
- [ _2026-06-11 02:25:37_ ] [940b4f7](<https://github.com/dimaslanjaka/bin/commit/940b4f7>) ci(cache): prefix cache keys with repository name for workflow isolation
- [ _2026-06-10 19:30:04_ ] [0a3788a](<https://github.com/dimaslanjaka/bin/commit/0a3788a>)
    
    chore: update build from https://github.com/dimaslanjaka/bin/commit/940b4f7c38816ddfe23669cfa960e51ea3b23cd2
    
    commit hash: 940b4f
    
    commit url: https://github.com/dimaslanjaka/bin/commit/940b4f7c38816ddfe23669cfa960e51ea3b23cd2
    
    runner: https://github.com/dimaslanjaka/bin/commit/940b4f7c38816ddfe23669cfa960e51ea3b23cd2/checks/27300717335
- [ _2026-06-11 03:47:22_ ] [8c2ac5b](<https://github.com/dimaslanjaka/bin/commit/8c2ac5b>)
    
    refactor(node-package-packer): extract getArgs from bundle and add pm/filename options
    
    Move CLI argument parsing from bundle() into node-package-packer-cli.mjs.
    bundle() now accepts explicit options {cwd, pm, filename, commit} instead
    of calling getArgs() internally. Add lockfile-based pm detection to the CLI
    layer. Replace glob-based workspace artifact removal with tar-based tarball
    cleaning (extract/filter/repack). Suppress console.log during tests.
- [ _2026-06-10 20:56:25_ ] [8f0dc5e](<https://github.com/dimaslanjaka/bin/commit/8f0dc5e>)
    
    chore: update build from https://github.com/dimaslanjaka/bin/commit/8c2ac5bda3c4a114666dd1a5155d901ebc16b4c3
    
    commit hash: 8c2ac5
    
    commit url: https://github.com/dimaslanjaka/bin/commit/8c2ac5bda3c4a114666dd1a5155d901ebc16b4c3
    
    runner: https://github.com/dimaslanjaka/bin/commit/8c2ac5bda3c4a114666dd1a5155d901ebc16b4c3/checks/27305689096
- [ _2026-06-11 04:31:37_ ] [1120b37](<https://github.com/dimaslanjaka/bin/commit/1120b37>) chore(build): bump node target from 14 to 18
- [ _2026-06-11 04:38:54_ ] [a630382](<https://github.com/dimaslanjaka/bin/commit/a630382>)
    
    feat(node-package-packer): extract cleanTarball with config-driven callbacks
    
    - Move inline cleanTarball from build-tarball.mjs to its own module
      (clean-tarball.cjs) with imported tar dependency
    - Add packer.onFilter callback to filter tarball entries via config
    - Add packer.onFinish callback for post-cleanup hooks (sync, async,
      or Node-style (err, result) callbacks via pify)
    - Add packer config type to BinaryCollectionsConfig
    - Document packer config in docs-src and update config example
- [ _2026-06-11 09:18:32_ ] [e82335a](<https://github.com/dimaslanjaka/bin/commit/e82335a>)
    
    feat(utils): add extract-local-files utility for resolving local dependencies
    
    Add two exported functions:
    - resolveLocalFile: resolves relative import paths to absolute file paths with extension fallback
    - extractLocalFiles: recursively collects all local file dependencies from a source file using Babel AST parsing
    
    Supports import declarations, require() calls, export ... from re-exports, and export * from wildcard re-exports.
- [ _2026-06-11 09:24:11_ ] [c2e01db](<https://github.com/dimaslanjaka/bin/commit/c2e01db>)
    
    feat(opencode): add session title reasoner/renamer utility
    
    Add a set of modules that automatically propose and update descriptive
    titles for OpenCode sessions with "New session" titles:
    
    - config.ts: configuration loader (JSONC-based, with defaults)
    - session-title-reasoner.ts: core logic — loads sessions, builds
      transcripts from message/part data, calls LLM to propose titles
    - session-title-reasoner-cli.ts: CLI interface with --write, --limit,
      --dir, --model, --concurrency options
    - session-title-reasoner.runner.ts: standalone debug runner (random pick)
    - session-title-reasoner2.ts: OpenCode plugin that auto-renames sessions
      on chat.message hook
    - session-title-reasoner2.runner.ts: runner for the plugin version
- [ _2026-06-11 09:38:46_ ] [4cf5ee8](<https://github.com/dimaslanjaka/bin/commit/4cf5ee8>)
    
    build: update build pipeline with rollup main entry and declaration generation
    
    - package.json: add module/types fields, restructure exports with import
      priority, add build-ts/build-dts/build-mainEntry scripts, add babel
      parser/traverse devDependencies
    - rollup.mainEntry.js: rollup config using extractLocalFiles utility to
      bundle all local dependencies into CJS and ESM outputs
    - tsconfig.dts.json: dedicated tsconfig for emitting declaration files
      only
- [ _2026-06-11 09:42:50_ ] [1c2bd24](<https://github.com/dimaslanjaka/bin/commit/1c2bd24>)
    
    chore: update gitignore and add smart-title plugin config
    
    - .gitignore: widen negation pattern to cover all opencode.json variants
      and allow smart-title.json* to be tracked
    - .opencode/smart-title.jsonc: add configuration for the smart title
      plugin (enabled, debug, model, updateThreshold)
- [ _2026-06-11 02:46:15_ ] [a9bcec9](<https://github.com/dimaslanjaka/bin/commit/a9bcec9>)
    
    chore: update build from https://github.com/dimaslanjaka/bin/commit/1c2bd241ccbf0360d835b5be879b6c8611ce7b83
    
    commit hash: 1c2bd2
    
    commit url: https://github.com/dimaslanjaka/bin/commit/1c2bd241ccbf0360d835b5be879b6c8611ce7b83
    
    runner: https://github.com/dimaslanjaka/bin/commit/1c2bd241ccbf0360d835b5be879b6c8611ce7b83/checks/27320305805
- [ _2026-06-11 10:26:38_ ] [10e21b1](<https://github.com/dimaslanjaka/bin/commit/10e21b1>)
    
    chore(deps): update multiple dependencies to latest versions
    
    - @opencode-ai/plugin ^1.16.2 → ^1.17.3
    - @yarnpkg/core ^4.7.0 → ^4.8.0
    - axios ^1.16.1 → ^1.17.0
    - cosmiconfig ^9.0.1 → ^9.0.2
    - openai ^6.41.0 → ^6.42.0
    - proxy-agent ^8.0.1 → ^8.0.2
    - puppeteer ^25.0.4 → ^25.1.0
    - @babel/core ^7.29.0 → ^7.29.7
    - @babel/plugin-syntax-import-assertions ^7.28.6 → ^7.29.7
    - @babel/preset-env ^7.29.2 → ^7.29.7
    - @babel/preset-typescript ^7.28.5 → ^7.29.7
    - @rollup/plugin-babel ^7.0.0 → ^7.1.0
    - @types/node ^25.9.1 → ^25.9.3
    - marked ^18.0.4 → ^18.0.5
    - rollup ^4.0.0 → ^4.61.1
    - ts-jest ^29.4.9 → ^29.4.11
- [ _2026-06-11 10:27:42_ ] [76b6101](<https://github.com/dimaslanjaka/bin/commit/76b6101>)
    
    build: exclude builder and runner files from declaration generation
    
    Add **/*.builder.* and **/*.runner.* to tsconfig.dts.json exclude list
    to prevent declaration emit for non-module entry files.
- [ _2026-06-11 11:20:21_ ] [3b7bfb5](<https://github.com/dimaslanjaka/bin/commit/3b7bfb5>)
    
    refactor(opencode): simplify sessionRenamerPlugin exports
    
    Export sessionRenamerPlugin directly instead of via const alias and
    default export aliases. Comment out the redundant export lines.
- [ _2026-06-11 11:46:10_ ] [95d23e4](<https://github.com/dimaslanjaka/bin/commit/95d23e4>) chore: add module.exports.default for ESM interop
- [ _2026-06-11 11:50:57_ ] [0912dc8](<https://github.com/dimaslanjaka/bin/commit/0912dc8>) chore: add module.exports.default for ESM interop
- [ _2026-06-11 11:53:35_ ] [2bc3c81](<https://github.com/dimaslanjaka/bin/commit/2bc3c81>) refactor(utils): extract getFileTreeString to standalone module
- [ _2026-06-11 11:54:19_ ] [d5c131a](<https://github.com/dimaslanjaka/bin/commit/d5c131a>) test(remove-module): import describe/expect/test from @jest/globals
- [ _2026-06-11 11:54:52_ ] [27ba817](<https://github.com/dimaslanjaka/bin/commit/27ba817>) chore(tsconfig): add scripts directory to include
- [ _2026-06-11 12:17:16_ ] [072efe6](<https://github.com/dimaslanjaka/bin/commit/072efe6>)
    
    refactor(ci): remove redundant default export aliases from CJS fixtures
    
    Remove module.exports.default = module.exports lines from four
    ci-yaml-fixture CJS files — these ESM compatibility aliases are
    no longer needed.
- [ _2026-06-11 13:00:19_ ] [7a23ea0](<https://github.com/dimaslanjaka/bin/commit/7a23ea0>)
    
    feat(utils): add shared eslint-helper utility
    
    Extract eslintFix function into a reusable CJS module that runs
    ESLint --fix with flat config on a given file path.
- [ _2026-06-11 13:01:02_ ] [57dddc7](<https://github.com/dimaslanjaka/bin/commit/57dddc7>)
    
    feat(export-scanner): add CLI tool to scan and manage re-exports
    
    Add a new export scanner utility that:
    - Scans src/ for exported symbols using Babel AST (ESM) and regex (CJS)
    - Compares against index.ts re-exports
    - Reports missing and stale exports
    - Auto-generates or updates the exports file with --write
    - Handles default exports, named exports, and re-exports
    - Supports --ignore patterns and custom output paths
    
    Modules: export-scanner-cli.mjs, filters.mjs, getExportsFromFile.mjs,
    parseCjsExports.mjs, parseEsmExports.mjs, parseIndexExports.mjs,
    resolver.mjs, types.d.ts
- [ _2026-06-11 13:10:11_ ] [f0cac0a](<https://github.com/dimaslanjaka/bin/commit/f0cac0a>) feat(export-scanner): alias duplicate symbols with path prefix when writing index.ts
- [ _2026-06-11 13:27:57_ ] [a9bdb73](<https://github.com/dimaslanjaka/bin/commit/a9bdb73>)
    
    docs(memory): add Letta-compatible memory block documentation
    
    - Create .github/instructions/memory.instructions.md with full memory block guide
    - Update .opencode/agents/modify-js-ts.agent.md: switch memory format to YAML frontmatter, use _ separator
    - Un-ignore .opencode/agents/ in .gitignore to track agent configurations
    - Fix missing trailing newline in all.instructions.md
- [ _2026-06-11 06:31:33_ ] [f673215](<https://github.com/dimaslanjaka/bin/commit/f673215>)
    
    chore: update build from https://github.com/dimaslanjaka/bin/commit/a9bdb73ab2941b5ee87ab7270a0f89fed34f6955
    
    commit hash: a9bdb7
    
    commit url: https://github.com/dimaslanjaka/bin/commit/a9bdb73ab2941b5ee87ab7270a0f89fed34f6955
    
    runner: https://github.com/dimaslanjaka/bin/commit/a9bdb73ab2941b5ee87ab7270a0f89fed34f6955/checks/27328397973
- [ _2026-06-11 13:36:26_ ] [f35e46e](<https://github.com/dimaslanjaka/bin/commit/f35e46e>) build(rollup): replace typescript plugin with babel for transpilation
- [ _2026-06-11 17:45:22_ ] [8fdb4ff](<https://github.com/dimaslanjaka/bin/commit/8fdb4ff>)
    
    chore(deps): update pinned dependency resolutions
    
    - Update @dimaslanjaka/ai-toolkit artifact URL to use new package name
    - Bump cross-spawn resolution to dd0273f
    - Bump git-command-helper resolution to 849f10f
    - Bump @dimaslanjaka/eslint-base-config resolution to 84028e4
    - Bump binary-collections self-resolution to f35e46e
- [ _2026-06-11 17:53:47_ ] [e8c21d3](<https://github.com/dimaslanjaka/bin/commit/e8c21d3>)
    
    ci(build-release): add submodule detachment step to prevent lint-staged errors
    
    When build artifacts are detected, detached submodule .git files can
    cause lint-staged to fail. This step removes them before the commit
    is made, ensuring a clean commit of generated build files.
- [ _2026-06-11 18:03:06_ ] [09b72a7](<https://github.com/dimaslanjaka/bin/commit/09b72a7>) ci(pages): scope docs deployment to doc source changes
- [ _2026-06-11 18:06:52_ ] [403a9f6](<https://github.com/dimaslanjaka/bin/commit/403a9f6>)
    
    chore(release): configure merge driver for release metadata files
    
    - Replace src/_auto_gen/checksum.cjs references with release/metadata.json and release/readme.md in .gitattributes
    - Add idempotent resolve_hash merge driver registration to pre-commit hook
- [ _2026-06-11 18:17:33_ ] [f0a0c37](<https://github.com/dimaslanjaka/bin/commit/f0a0c37>)
    
    chore(gitattributes): clean up filters, add hooks and missing extensions
    
    - Remove unused filter= attributes (covered by formatters) except Java/Kotlin
    - Add *.mjs entry
    - Spread wildcard script glob into individual entries under Windows section
    - Remove *.sh from Windows section
    - Add all common git hook entries
    - Remove duplicate * text=auto line
    - Move .husky/hash.txt to release section
- [ _2026-06-11 18:26:17_ ] [a99af57](<https://github.com/dimaslanjaka/bin/commit/a99af57>) build(pack): add --normalize-resolutions flag
- [ _2026-06-11 18:29:33_ ] [2c5a61c](<https://github.com/dimaslanjaka/bin/commit/2c5a61c>) ci(hooks): skip submodule staging in CI and handle uninitialized submodules
- [ _2026-06-11 11:38:32_ ] [c694e21](<https://github.com/dimaslanjaka/bin/commit/c694e21>)
    
    chore: update build from https://github.com/dimaslanjaka/bin/commit/2c5a61ca72e51f8bf4be4aac89f682f69615be61
    
    commit hash: 2c5a61
    
    commit url: https://github.com/dimaslanjaka/bin/commit/2c5a61ca72e51f8bf4be4aac89f682f69615be61
    
    runner: https://github.com/dimaslanjaka/bin/commit/2c5a61ca72e51f8bf4be4aac89f682f69615be61/checks/27343836782
- [ _2026-06-11 19:02:57_ ] [2e1becd](<https://github.com/dimaslanjaka/bin/commit/2e1becd>) feat(config): cascade config search to parent dirs and workspace root
- [ _2026-06-11 19:15:37_ ] [4aa2944](<https://github.com/dimaslanjaka/bin/commit/4aa2944>) chore(deps): add @formatjs/fast-memoize dependency
- [ _2026-06-11 19:21:01_ ] [f356051](<https://github.com/dimaslanjaka/bin/commit/f356051>) build(config): add clear-github-caches alias
- [ _2026-06-11 19:27:50_ ] [0257ea4](<https://github.com/dimaslanjaka/bin/commit/0257ea4>) refactor(workflows): simplify git add step in build-release CI fixture
- [ _2026-06-11 19:38:44_ ] [c50682c](<https://github.com/dimaslanjaka/bin/commit/c50682c>) ci(build-release): stop tracking dist and lib dirs in release workflow
- [ _2026-06-13 01:52:35_ ] [44985ee](<https://github.com/dimaslanjaka/bin/commit/44985ee>)
    
    feat: remove ai-toolkit submodule from repository
    
    The ai-toolkit submodule has been removed from .gitmodules. This cleanup eliminates an unused or deprecated dependency from the project configuration.
- [ _2026-06-13 02:03:21_ ] [97746c6](<https://github.com/dimaslanjaka/bin/commit/97746c6>) perf: skip tarball size checks for directories without staged changes
- [ _2026-06-13 02:22:11_ ] [292fd2f](<https://github.com/dimaslanjaka/bin/commit/292fd2f>)
    
    chore(ci): simplify git add command for release directories
    
    Consolidate `release/` and `releases/` patterns into single glob `release*/` in the CI workflow's git add step, removing redundant error redirection.
- [ _2026-06-13 02:23:23_ ] [f90d9cb](<https://github.com/dimaslanjaka/bin/commit/f90d9cb>) chore: disable multi-repository checkout in CI environment setup
- [ _2026-06-13 02:34:12_ ] [f91657f](<https://github.com/dimaslanjaka/bin/commit/f91657f>)
    
    fix(deps): update dependencies and add eslint devDependency
    
    - Switch cross-spawn to use private fork release
    - Add eslint ^9 as devDependency
    - Update binary-collections to latest release
    - Add clear-github-caches CLI alias
- [ _2026-06-13 02:38:56_ ] [3ad1c63](<https://github.com/dimaslanjaka/bin/commit/3ad1c63>) ci: add git untracked cache configuration to CI workflow
- [ _2026-06-13 16:46:09_ ] [9362874](<https://github.com/dimaslanjaka/bin/commit/9362874>)
    
    refactor(build): export rollup config utilities and simplify mainEntry
    
    - export bundledPackages, externalPackages, and helper functions from rollup.config.js
    - import and reuse utilities in rollup.mainEntry.js instead of duplicating logic
    - apply entryFileNames and chunkFileNames with proper extensions
    - replace inline external packages logic with externalPackagesFilter
    - remove unused fs-extra import from rollup.mainEntry.js
- [ _2026-06-14 01:10:01_ ] [b8503cf](<https://github.com/dimaslanjaka/bin/commit/b8503cf>)
    
    chore(vscode): add file watcher exclusions
    
    Ignore common build/cache directories in VS Code file watcher
    to improve performance and reduce noise.
- [ _2026-06-14 01:12:56_ ] [b88118f](<https://github.com/dimaslanjaka/bin/commit/b88118f>)
    
    fix(build): correct test-ci script extension and clean script prefix
    
    - Use .cjs extension for generate-test-ci script alias in build.config.cjs
    - Use npx for rimraf in clean script in package.json to ensure execution
- [ _2026-06-14 01:13:58_ ] [da2517a](<https://github.com/dimaslanjaka/bin/commit/da2517a>)
    
    chore(test-project): update yarn to 4.13.0 and remove yarnPath
    
    - Remove explicit yarnPath from .yarnrc.yml (use default)
    - Bump packageManager version to yarn@4.13.0 in package.json
- [ _2026-06-14 01:18:34_ ] [929a020](<https://github.com/dimaslanjaka/bin/commit/929a020>)
    
    feat(ci): enable recursive submodule checkout in build-release workflow
    
    Add `submodule: 'recursive'` to the `actions/checkout` step in the build‑release workflow to ensure that repository submodules are fetched during CI runs. This improves build reliability when the project relies on submodule content.
- [ _2026-06-14 02:49:14_ ] [fa80720](<https://github.com/dimaslanjaka/bin/commit/fa80720>)
    
    fix(build): correct generate-test-ci binary path from src to lib
    
    The build.config.cjs was referencing src/ instead of lib/ for the
    generate-test-ci binary. Since tsup outputs to lib/, this caused
    the binary mapping to point to a non-existent file.
    
    - updated build.config.cjs defaultBin mapping
    - regenerated package.json bin field via build pipeline
- [ _2026-06-13 19:53:44_ ] [0f6557f](<https://github.com/dimaslanjaka/bin/commit/0f6557f>)
    
    chore: update build from https://github.com/dimaslanjaka/bin/commit/fa8072013218cae5407c688f81105e6ae3029973
    
    commit hash: fa8072
    
    commit url: https://github.com/dimaslanjaka/bin/commit/fa8072013218cae5407c688f81105e6ae3029973
    
    runner: https://github.com/dimaslanjaka/bin/commit/fa8072013218cae5407c688f81105e6ae3029973/checks/27477310566
- [ _2026-06-14 11:12:25_ ] [9a7ae61](<https://github.com/dimaslanjaka/bin/commit/9a7ae61>)
    
    fix(build): replace entryChunkFileNames with chunkFileNames in rollup config
    
    Rollup does not recognize entryChunkFileNames as a valid output option.
    Changed to chunkFileNames in both CJS and ES output configurations
    to eliminate the "Unknown output options: entryChunkFileNames" warning.
- [ _2026-06-14 11:42:36_ ] [ea8a58a](<https://github.com/dimaslanjaka/bin/commit/ea8a58a>)
    
    refactor(glob): standardize glob imports to namespace pattern
    
    Changed from named/destructured imports to namespace imports across 5 modules:
    - src/cache-cleaner/yarn.ts: import * as glob from 'glob'
    - src/export-scanner/export-scanner-cli.mjs: import * as glob from 'glob'
    - src/github-workflows/generate-test-ci-step-cli.mjs: import * as glob from 'glob'
    - src/node-package-packer/get-workspaces.cjs: const glob = require('glob')
    - src/node-package-packer/transform-workspace-protocols.mjs: import * as glob from 'glob'
    
    All call sites updated to use glob.glob() / glob.globSync() instead of direct destructured imports.
- [ _2026-06-14 11:43:13_ ] [51ce1d6](<https://github.com/dimaslanjaka/bin/commit/51ce1d6>)
    
    chore(opencode): update mcp plugins and instructions
    
    - Commented out several MCP servers (filesystem, git, github, fetch, puppeteer, playwright) in .opencode/opencode.jsonc
    - Added new plugin "opencode-helicone-session"
    - Kept "oh-my-opencode-slim@latest" as active plugin
    - Updated instructions array to include AGENTS.md, .github/instructions/*.md, .github/*.md, packages/*/AGENTS.md
- [ _2026-06-14 13:18:35_ ] [4e15953](<https://github.com/dimaslanjaka/bin/commit/4e15953>)
    
    chore(deps): downgrade lint-staged and update dependency resolutions
    
    - Downgrade lint-staged from 17.0.7 to 16.2.7
    - Update cross-spawn resolution to commit e48db32
    - Update git-command-helper resolution to commit 4e7f847
    - Update @dimaslanjaka/eslint-base-config resolution to commit d646d36
    - Update binary-collections resolution to commit 9688287
- [ _2026-06-14 13:36:04_ ] [5abb940](<https://github.com/dimaslanjaka/bin/commit/5abb940>)
    
    feat(opencode): expose auth rotate alias and add custom key option
    
    Export `handleAuthRotate` under the name `opencodeAuthRotator` for CLI usage and extend its signature to accept a `keys` array in the options. Added detailed JSDoc explaining the rotation process, parameters, and error handling. This enables users to provide custom key sets directly, improving flexibility when rotating Open
- [ _2026-06-14 13:54:13_ ] [3a5ceea](<https://github.com/dimaslanjaka/bin/commit/3a5ceea>)
    
    feat(build): add TypeScript plugin to Rollup configuration
    
    - Add @rollup/plugin-typescript to plugin chain with tsconfig.json reference
    - Remove .ts extension from commonjs plugin extensions (handled by typescript plugin)
    - Position typescript plugin before babel to ensure proper compilation order
- [ _2026-06-14 21:59:38_ ] [29e1f96](<https://github.com/dimaslanjaka/bin/commit/29e1f96>)
    
    refactor(opencode/session-title-reasoner2): remove @opencode-ai/plugin dependency and extract types
    
    Extracted the `Plugin` type and its related interfaces directly into the module. This removes the dependency on the external `@opencode-ai/plugin` package and makes the module self-contained.
    
    - Created `PluginContext`, `OpenCodeClient`, `SessionClient`, `ConfigClient`, `PluginHooks`, and `Message` interfaces
    - Replaced instances of `Parameters<Plugin>[0]` and `ReturnType<Plugin>` with explicit local types
    - Integrated `SessionClientWithGet` into the main `SessionClient` interface
- [ _2026-06-14 22:04:59_ ] [87ff14b](<https://github.com/dimaslanjaka/bin/commit/87ff14b>)
    
    build(rollup): bundle glob and fast-memoize, fix chunk configuration
    
    - Add 'glob' and '@formatjs/fast-memoize' to the `bundledPackages` list to ensure they are bundled.
    - Rename the incorrect `entryChunkFileNames` option to the correct `chunkFileNames` in the ESM and CJS output configurations.
- [ _2026-06-15 08:20:02_ ] [f5dbd0e](<https://github.com/dimaslanjaka/bin/commit/f5dbd0e>)
    
    ci(husky): skip lint-staged execution in CI environments
    
    The pre-commit hook now detects CI environments (GitHub Actions or generic CI) and skips running lint-staged to avoid redundant linting that already runs in CI pipelines. This reduces CI execution time and prevents duplicate checks.
- [ _2026-06-15 08:56:56_ ] [5164736](<https://github.com/dimaslanjaka/bin/commit/5164736>) chore: remove unused dependency @opencode-ai/plugin
- [ _2026-06-15 02:00:15_ ] [3cf1660](<https://github.com/dimaslanjaka/bin/commit/3cf1660>)
    
    chore: update build from https://github.com/dimaslanjaka/bin/commit/51647368d05d361bbe0d5b6baefb8f4ccb6467e8
    
    commit hash: 516473
    
    commit url: https://github.com/dimaslanjaka/bin/commit/51647368d05d361bbe0d5b6baefb8f4ccb6467e8
    
    runner: https://github.com/dimaslanjaka/bin/commit/51647368d05d361bbe0d5b6baefb8f4ccb6467e8/checks/27519572442
- [ _2026-06-16 22:53:53_ ] [6fecc0a](<https://github.com/dimaslanjaka/bin/commit/6fecc0a>)
    
    fix: correct GitHub Actions checkout configuration parameters
    
    - Fix typo: rename `submodule` to `submodules` in build-release-data workflow
    - Add missing checkout parameters (`fetch-depth` and `submodules`) to workflow-test-data for consistency
- [ _2026-06-16 15:58:41_ ] [8da4e46](<https://github.com/dimaslanjaka/bin/commit/8da4e46>)
    
    chore: update build from https://github.com/dimaslanjaka/bin/commit/6fecc0a3a376411825e66381c51d1f4b9a2b85a3
    
    commit hash: 6fecc0
    
    commit url: https://github.com/dimaslanjaka/bin/commit/6fecc0a3a376411825e66381c51d1f4b9a2b85a3
    
    runner: https://github.com/dimaslanjaka/bin/commit/6fecc0a3a376411825e66381c51d1f4b9a2b85a3/checks/27630544387
- [ _2026-06-17 03:07:21_ ] [6f958b2](<https://github.com/dimaslanjaka/bin/commit/6f958b2>)
    
    chore: update build from https://github.com/dimaslanjaka/bin/commit/b1ae02ec66faf1ef6044feecdc508f0e7306ebde
    
    commit hash: b1ae02
    
    commit url: https://github.com/dimaslanjaka/bin/commit/b1ae02ec66faf1ef6044feecdc508f0e7306ebde
    
    runner: https://github.com/dimaslanjaka/bin/commit/b1ae02ec66faf1ef6044feecdc508f0e7306ebde/checks/27663025162
- [ _2026-06-17 00:42:13_ ] [74ff06a](<https://github.com/dimaslanjaka/bin/commit/74ff06a>)
    
    feat: export opencode auth utilities and types
    
    Add findWorkingKey as opencodeFindWorkingKey, getOpenCodeAuth, and all types from opencode modules to public index for external consumption alongside existing handleAuthRotate export.
- [ _2026-06-20 07:41:10_ ] [4955540](<https://github.com/dimaslanjaka/bin/commit/4955540>)
    
    chore: remove CLI execution logic from core modules
    
    - Remove direct execution block from find-node-modules.cjs
    - Remove default export alias and CLI invocation from find-node-modules-cli.cjs
    - Separate CLI concerns from core library functionality
    - Modules now only export functions for programmatic use
- [ _2026-06-20 00:46:14_ ] [09a1a1d](<https://github.com/dimaslanjaka/bin/commit/09a1a1d>)
    
    chore: update build from https://github.com/dimaslanjaka/bin/commit/4955540b260dea416261a7aa6181331ae4a132c6
    
    commit hash: 495554
    
    commit url: https://github.com/dimaslanjaka/bin/commit/4955540b260dea416261a7aa6181331ae4a132c6
    
    runner: https://github.com/dimaslanjaka/bin/commit/4955540b260dea416261a7aa6181331ae4a132c6/checks/27855062348
- [ _2026-06-26 09:42:40_ ] [07f34ed](<https://github.com/dimaslanjaka/bin/commit/07f34ed>) ci(fixtures): centralize release tarball URL
- [ _2026-06-26 10:54:41_ ] [12c7349](<https://github.com/dimaslanjaka/bin/commit/12c7349>)
    
    feat(agents): add Git Committer agent for conventional commits
    
    Introduces a new agent that creates conventional commits from staged changes with automatic context grouping. The agent stages files explicitly, follows conventional commit format, and integrates with VSCode, GitHub, browser automation, and Python tooling.
- [ _2026-06-26 04:17:36_ ] [049ae63](<https://github.com/dimaslanjaka/bin/commit/049ae63>)
    
    chore: update build from https://github.com/dimaslanjaka/bin/commit/12c7349f02fad7023a4ebcfe59fe36c4e2f917f8
    
    commit hash: 12c734
    
    commit url: https://github.com/dimaslanjaka/bin/commit/12c7349f02fad7023a4ebcfe59fe36c4e2f917f8
    
    runner: https://github.com/dimaslanjaka/bin/commit/12c7349f02fad7023a4ebcfe59fe36c4e2f917f8/checks/28216740307
- [ _2026-06-27 15:48:05_ ] [c2b5937](<https://github.com/dimaslanjaka/bin/commit/c2b5937>)
    
    feat(workflows): add GitLab authentication for private repository access
    
    Configure git credentials using OAuth token to enable access to private GitLab repositories during CI workflows. This allows the workflows to fetch dependencies or interact with GitLab resources that require authentication.
    
    Added the credential configuration step to:
    - build-release-data.cjs
    - setup-environments-data.cjs
    - workflow-test-data.cjs
- [ _2026-10-24 03:53:48_ ] [2bcb812](<https://github.com/dimaslanjaka/bin/commit/2bcb812>)
    
    fix(bin): ensure bcc runner uses local binary if present
    
    The bcc runner previously relied on 'npm exec' for local execution, which failed if the package was not installed/linked. Now it checks for the existence of lib/binary-collections.cjs relative to the script and runs it directly with node.
- [ _2026-10-24 04:14:04_ ] [b8f4d01](<https://github.com/dimaslanjaka/bin/commit/b8f4d01>) chore(deps): pin got dependency version in resolutions
- [ _2026-10-24 04:23:50_ ] [a513df1](<https://github.com/dimaslanjaka/bin/commit/a513df1>)
    
    fix(node-package-packer): handle missing workspace config roots
    
    Guard null Yarn workspace roots during config lookup and load normalization mappings from the package being packed.
- [ _2026-10-24 04:43:21_ ] [610f255](<https://github.com/dimaslanjaka/bin/commit/610f255>) refactor(git): remove ai-toolkit and AI features from git-diff
- [ _2026-10-24 04:53:41_ ] [2c61fe8](<https://github.com/dimaslanjaka/bin/commit/2c61fe8>)
    
    fix(ci): pass GitLab token as input to setup-environments action
    
    GitHub composite actions cannot access the `secrets` context directly.
    Moved GitLab credential configuration into the `setup-environments`
    action and added `gitlab_token` as an input to resolve the
    'Unrecognized named-value: secrets' error.
- [ _2026-10-24 04:55:36_ ] [08db1a7](<https://github.com/dimaslanjaka/bin/commit/08db1a7>) chore: ignore .omo and .codebase-memory directories
- [ _2026-10-24 04:43:21_ ] [b227d1f](<https://github.com/dimaslanjaka/bin/commit/b227d1f>) refactor(git): remove ai-toolkit and AI features from git-diff
- [ _2026-10-23 22:42:38_ ] [df4c213](<https://github.com/dimaslanjaka/bin/commit/df4c213>)
    
    chore: update build from https://github.com/dimaslanjaka/bin/commit/b227d1fdc625ccf60cb1602426256549b69ae742
    
    commit hash: b227d1
    
    commit url: https://github.com/dimaslanjaka/bin/commit/b227d1fdc625ccf60cb1602426256549b69ae742
    
    runner: https://github.com/dimaslanjaka/bin/commit/b227d1fdc625ccf60cb1602426256549b69ae742/checks/40034891413
- [ _2026-10-27 21:08:36_ ] [7dc4bd9](<https://github.com/dimaslanjaka/bin/commit/7dc4bd9>)
    
    feat(cli): add Windows launchers for 9router and omniroute
    
    - Add `bin/9router.cmd` to download and install the latest 9router release from the npm registry
    - Add `bin/omniroute.cmd` to download and install the latest omniroute release from the npm registry
    - Cache downloaded tarballs, installed versions, and package flavors to avoid unnecessary setup
    - Detect version and flavor changes to trigger package reinstallation
    - Resolve CLI entry points dynamically from package metadata with fallback paths
    - Configure Node.js production environment and memory options for both launchers
    - Initialize npm installation directories and handle download, installation, and entry-point errors
    - Approve installation scripts and rebuild `better-sqlite3` for omniroute
    - Register `9router` and `omniroute` executable commands in `package.json`
- [ _2026-10-27 14:11:00_ ] [28dbfc0](<https://github.com/dimaslanjaka/bin/commit/28dbfc0>)
    
    chore: update build from https://github.com/dimaslanjaka/bin/commit/7dc4bd9c5df448fdf9a6a152962f7631b818277a
    
    commit hash: 7dc4bd
    
    commit url: https://github.com/dimaslanjaka/bin/commit/7dc4bd9c5df448fdf9a6a152962f7631b818277a
    
    runner: https://github.com/dimaslanjaka/bin/commit/7dc4bd9c5df448fdf9a6a152962f7631b818277a/checks/40518436053
- [ _2026-10-27 21:11:43_ ] [2391406](<https://github.com/dimaslanjaka/bin/commit/2391406>) docs: add copilot file editing instructions
- [ _2026-10-27 14:14:01_ ] [ab7e2a2](<https://github.com/dimaslanjaka/bin/commit/ab7e2a2>)
    
    chore: update build from https://github.com/dimaslanjaka/bin/commit/23914066f052cc68528e6f09213e0f987294ce61
    
    commit hash: 239140
    
    commit url: https://github.com/dimaslanjaka/bin/commit/23914066f052cc68528e6f09213e0f987294ce61
    
    runner: https://github.com/dimaslanjaka/bin/commit/23914066f052cc68528e6f09213e0f987294ce61/checks/40518918730
- [ _2026-10-28 10:59:34_ ] [7d1383e](<https://github.com/dimaslanjaka/bin/commit/7d1383e>) chore: fix npm EALLOWREMOTE error in v12+
- [ _2026-10-28 04:04:20_ ] [6eec083](<https://github.com/dimaslanjaka/bin/commit/6eec083>)
    
    chore: update build from https://github.com/dimaslanjaka/bin/commit/7d1383e17b739513c58b35eb2a63514a49e47f02
    
    commit hash: 7d1383
    
    commit url: https://github.com/dimaslanjaka/bin/commit/7d1383e17b739513c58b35eb2a63514a49e47f02
    
    runner: https://github.com/dimaslanjaka/bin/commit/7d1383e17b739513c58b35eb2a63514a49e47f02/checks/40630081481
- [ _2026-10-28 11:12:42_ ] [c315294](<https://github.com/dimaslanjaka/bin/commit/c315294>) fix(packer): prevent normalizeResolutions from hanging on CI
- [ _2026-10-28 04:22:09_ ] [6e1d86b](<https://github.com/dimaslanjaka/bin/commit/6e1d86b>)
    
    chore: update build from https://github.com/dimaslanjaka/bin/commit/c3152941bd8b666eeb4e75f75d035815691c7c14
    
    commit hash: c31529
    
    commit url: https://github.com/dimaslanjaka/bin/commit/c3152941bd8b666eeb4e75f75d035815691c7c14
    
    runner: https://github.com/dimaslanjaka/bin/commit/c3152941bd8b666eeb4e75f75d035815691c7c14/checks/40631808916
- [ _2026-10-28 12:19:01_ ] [138e719](<https://github.com/dimaslanjaka/bin/commit/138e719>) ci(fixtures): make npm allow-remote config conditional
- [ _2026-10-28 12:35:28_ ] [42725ff](<https://github.com/dimaslanjaka/bin/commit/42725ff>)
    
    fix(jest): allow @formatjs packages to be transformed from ESM
    
    Allow babel-jest to transpile @formatjs/* packages from ESM to CJS so that
    CJS tests importing modules that depend on @formatjs/fast-memoize (e.g. the
    github-workflows clean-github-actions-caches test) work correctly.
- [ _2026-10-28 12:39:40_ ] [9753966](<https://github.com/dimaslanjaka/bin/commit/9753966>) deps(package): add @dimaslanjaka/eslint-base-config tarball
- [ _2026-10-28 13:03:22_ ] [6d37dd1](<https://github.com/dimaslanjaka/bin/commit/6d37dd1>) fix(test): re-clone test repo on invalid package.json
- [ _2026-10-28 06:17:25_ ] [22927f9](<https://github.com/dimaslanjaka/bin/commit/22927f9>)
    
    chore: update build from https://github.com/dimaslanjaka/bin/commit/6d37dd18496468b33a9e2e6490b9a20e32117489
    
    commit hash: 6d37dd
    
    commit url: https://github.com/dimaslanjaka/bin/commit/6d37dd18496468b33a9e2e6490b9a20e32117489
    
    runner: https://github.com/dimaslanjaka/bin/commit/6d37dd18496468b33a9e2e6490b9a20e32117489/checks/40642821034
- [ _2026-10-28 13:52:22_ ] [dda9f93](<https://github.com/dimaslanjaka/bin/commit/dda9f93>) deps(package): update better-sqlite3 to ^13.0.3
- [ _2026-10-28 14:43:26_ ] [6684791](<https://github.com/dimaslanjaka/bin/commit/6684791>)
    
    test: remove .js from expected compiled formats in test-compiled
    
    The build process (rollup/tsup) only produces .cjs and .mjs files,
    not plain .js files. Remove .js from expected extensions to match
    actual build output.
- [ _2026-10-28 14:47:11_ ] [f2cf9a6](<https://github.com/dimaslanjaka/bin/commit/f2cf9a6>) chore(vscode): update terminal PATH order and add venv env vars
- [ _2026-10-28 07:50:40_ ] [f117a13](<https://github.com/dimaslanjaka/bin/commit/f117a13>)
    
    chore: update build from https://github.com/dimaslanjaka/bin/commit/f2cf9a6f2fe9e8864ac744c029c008d7a7832a3a
    
    commit hash: f2cf9a
    
    commit url: https://github.com/dimaslanjaka/bin/commit/f2cf9a6f2fe9e8864ac744c029c008d7a7832a3a
    
    runner: https://github.com/dimaslanjaka/bin/commit/f2cf9a6f2fe9e8864ac744c029c008d7a7832a3a/checks/40652487613
- [ _2026-10-28 14:53:07_ ] [279e7d5](<https://github.com/dimaslanjaka/bin/commit/279e7d5>) docs: clarify agent instructions and AGENTS.md guidelines
- [ _2026-10-28 15:02:29_ ] [9a5bb01](<https://github.com/dimaslanjaka/bin/commit/9a5bb01>) fix(node-package-packer): clear setTimeout handle on getConfig race to prevent open handle leak
- [ _2026-10-28 08:06:35_ ] [ed93ff1](<https://github.com/dimaslanjaka/bin/commit/ed93ff1>)
    
    chore: update build from https://github.com/dimaslanjaka/bin/commit/9a5bb01a72fcd0ab2623e3b969fefa2bff4a98c3
    
    commit hash: 9a5bb0
    
    commit url: https://github.com/dimaslanjaka/bin/commit/9a5bb01a72fcd0ab2623e3b969fefa2bff4a98c3
    
    runner: https://github.com/dimaslanjaka/bin/commit/9a5bb01a72fcd0ab2623e3b969fefa2bff4a98c3/checks/40654259437
- [ _2026-10-28 15:29:38_ ] [e952eed](<https://github.com/dimaslanjaka/bin/commit/e952eed>) deps: remove @formatjs/fast-memoize dependency
- [ _2026-10-28 08:35:35_ ] [c0c9772](<https://github.com/dimaslanjaka/bin/commit/c0c9772>)
    
    chore: update build from https://github.com/dimaslanjaka/bin/commit/e952eed95937f784a0e156370e44106801e4fa8c
    
    commit hash: e952ee
    
    commit url: https://github.com/dimaslanjaka/bin/commit/e952eed95937f784a0e156370e44106801e4fa8c
    
    runner: https://github.com/dimaslanjaka/bin/commit/e952eed95937f784a0e156370e44106801e4fa8c/checks/40657739340
- [ _2026-10-28 16:16:04_ ] [d9f334d](<https://github.com/dimaslanjaka/bin/commit/d9f334d>) refactor: rename dirname parameter to workspaceDir for clarity
- [ _2026-10-28 16:39:17_ ] [f7d01ff](<https://github.com/dimaslanjaka/bin/commit/f7d01ff>) test(node-package-packer): remove @dimaslanjaka/ai-toolkit from transform-workspace-to-tarball test
- [ _2026-10-28 09:43:06_ ] [28fc269](<https://github.com/dimaslanjaka/bin/commit/28fc269>)
    
    chore: update build from https://github.com/dimaslanjaka/bin/commit/f7d01ff54854552144ec382113f08bae1e0dec1d
    
    commit hash: f7d01f
    
    commit url: https://github.com/dimaslanjaka/bin/commit/f7d01ff54854552144ec382113f08bae1e0dec1d
    
    runner: https://github.com/dimaslanjaka/bin/commit/f7d01ff54854552144ec382113f08bae1e0dec1d/checks/40666275876
- [ _2026-10-28 16:50:59_ ] [569a913](<https://github.com/dimaslanjaka/bin/commit/569a913>) chore(husky): remove auto generation of build-release.yml in pre-commit
- [ _2026-10-28 16:52:13_ ] [925687b](<https://github.com/dimaslanjaka/bin/commit/925687b>)
    
    docs: update and add docs-src for new/changed features
    
    - node-package-packer: add --bun/-b flag, --commit flag, and pm auto-detection section
    - node-cache-cleaner: fix source file paths (.js -> .cjs/.ts)
    - session-title-reasoner: new doc for OpenCode session title LLM CLI
- [ _2026-10-28 17:18:27_ ] [5c96563](<https://github.com/dimaslanjaka/bin/commit/5c96563>)
    
    feat(git): add ensureCloned utility
    
    Add src/git/ensureCloned.cjs with three exports:
    
    - gitQuery(args, cwd): runs any git command in a given directory and
      returns trimmed stdout, or null on failure
    - normalizeRemoteUrl(url): strips .git suffix, lowercases the host, and
      converts SSH git@host:owner/repo form to host/owner/repo so HTTP and
      SSH variants of the same repo compare equal
    - ensureCloned(url, branch, dest): clones url at branch into dest; when
      .git already exists it verifies (1) remote URL, (2) current branch,
      and (3) git rev-parse --show-toplevel against dest before returning;
      re-clones after fs.removeSync if any check fails
    
    Uses cross-spawn for spawnSync (consistent with src/git/utils.cjs),
    fs-extra, and upath. Exports a .default alias for ESM default-import
    consumers.
- [ _2026-10-28 17:21:22_ ] [c5a04e2](<https://github.com/dimaslanjaka/bin/commit/c5a04e2>)
    
    refactor(test): use ensureCloned in env.cjs and tarball test
    
    test/env.cjs:
    - Add top-level require of src/git/ensureCloned.cjs
    - Replace ensureRepoExists implementation: drop manual .git folder check
      and raw git clone spawnSync call; delegate entirely to ensureCloned so
      the repo is also verified (remote URL, branch, git root) on re-runs
    
    test/node-package-packer/transform-workspace-to-tarball.test.mjs:
    - Full rewrite to use repoDir from test/env.cjs as the isolated project
      root instead of the monorepo root, so git rev-parse succeeds in CI
    - Import ensureCloned from src/git/ensureCloned.cjs; remove the local
      gitQuery, normalizeRemoteUrl, and ensureCloned duplicates
    - Import ensureRepoExists from test/env.cjs; add outer beforeAll to
      guarantee repoDir is a valid git clone before any nested setup runs
    - Add outer afterAll that runs git reset --hard in repoDir to discard
      all uncommitted changes after tests complete
    - Clone git-command-helper@pre-release and node-cross-spawn@private into
      repoDir/packages/ (matching .gitmodules) via ensureCloned
    - Write a fresh package.json with workspaces and workspace:^ deps for
      both packages before running transformWorkspaceProtocols
    - Set beforeAll timeout to 120s to accommodate git clones in CI
- [ _2026-10-28 10:25:11_ ] [0f6ba48](<https://github.com/dimaslanjaka/bin/commit/0f6ba48>)
    
    chore: update build from https://github.com/dimaslanjaka/bin/commit/c5a04e20ee11f86517db2d418836a1cf2ead0727
    
    commit hash: c5a04e
    
    commit url: https://github.com/dimaslanjaka/bin/commit/c5a04e20ee11f86517db2d418836a1cf2ead0727
    
    runner: https://github.com/dimaslanjaka/bin/commit/c5a04e20ee11f86517db2d418836a1cf2ead0727/checks/40671823761
- [ _2026-10-30 11:36:14_ ] [ce6e9e9](<https://github.com/dimaslanjaka/bin/commit/ce6e9e9>)
    
    ci: verify compiled output before publishing build artifacts
    
    - Add a compiled-output verification step to the release workflow
    - Gate artifact change detection, staging, and pushing on successful verification
    - Remove the separate compiled-output testing workflow
    - Remove the pull-before-push step from the release workflow
    - Keep artifact publishing conditional on detected changes and successful verification
- [ _2026-10-30 12:22:24_ ] [af1d42c](<https://github.com/dimaslanjaka/bin/commit/af1d42c>)
    
    build: exclude generated bundles from CLI binary mapping
    
    - Add `proxy-switcher-test` to the default binary mappings
    - Introduce `isGeneratedFile()` to identify generated and internal bundle files
    - Exclude CommonJS helpers, numbered indexes, hashed index files, and hash-suffixed bundles from binary mapping
    - Log skipped generated files with colored output
### 2.0.13

- [ _2026-05-31 23:33:03_ ] [b4594f9](<https://github.com/dimaslanjaka/bin/commit/b4594f9>) fix(ci): update cache key format for consistency in CI workflows
- [ _2026-05-31 23:35:30_ ] [26def49](<https://github.com/dimaslanjaka/bin/commit/26def49>)
    
    feat(ci): make setup-environments cache key prefix configurable
    
    - add `prefix-cache-key` input to the setup-environments action
    - use configurable cache key prefix for dependency cache entries
    - update restore keys to respect custom cache prefixes
    - retain existing runner OS–based prefix as the default value
- [ _2026-05-31 23:39:44_ ] [6efe559](<https://github.com/dimaslanjaka/bin/commit/6efe559>) fix(ci): disable unconditional cache cleanup in GitHub Actions
- [ _2026-05-31 23:42:56_ ] [d8fdb8e](<https://github.com/dimaslanjaka/bin/commit/d8fdb8e>) fix(ci): remove unnecessary paths filter from push trigger in workflow
- [ _2026-05-31 23:47:27_ ] [bdf32ab](<https://github.com/dimaslanjaka/bin/commit/bdf32ab>)
    
    feat(checkout-dependencies): add submodule initialization step
    
    - add Update submodules step to composite action
    - initialize and update git submodules recursively
    - clean up .git/modules after checkout
    - install submodule dependencies via binary-collections submodule-install
- [ _2026-05-31 23:53:58_ ] [d87a91b](<https://github.com/dimaslanjaka/bin/commit/d87a91b>)
    
    feat(setup-environments): consolidate environment setup from build-release workflow
    
    - add token input for accessing GitHub resources
    - add git EOL line-ending configuration step
    - add Bun setup with npm registry and GitHub packages registry
    - add Corepack activation and Yarn 4.13.0 preparation
    - add recursive submodule pull, sync, and install step
    - add comprehensive environment variables step (SHA, branch, URLs, cache dirs, package manager detection, architecture, platform)
    - expand cache paths with release artifacts, lock files, dist, lib, tmp, and dynamic Yarn/NPM/pip cache directories
    - add global npm package installation step (typescript, ts-node, gulp-cli, hexo-cli, webpack-cli)
    - update action description to reflect new capabilities
- [ _2026-05-31 23:59:36_ ] [5da2ba1](<https://github.com/dimaslanjaka/bin/commit/5da2ba1>)
    
    ci(test): switch to individual test file execution with jest
    
    - replace test-cjs/test-esm wrapper scripts with direct jest execution
    - run each test file individually via find + npm test for isolation
    - add jest flags: runInBand, forceExit, extended testTimeout, detectOpenHandles
    - update package.json test script to use jest directly
- [ _2026-06-01 00:08:05_ ] [337ce49](<https://github.com/dimaslanjaka/bin/commit/337ce49>)
    
    refactor(ci): replace verify-changed-files action with native git diff
    
    Remove the tj-actions/verify-changed-files dependency and use git diff
    with grep-based filtering to detect changed release tarballs directly
    within the workflow.
    
    - replace verify-changed-files action with shell script
    - collect changed *.tgz files from release directories using git diff
    - export detected files through GITHUB_OUTPUT
    - update logging step to use the new output variable
    - reduce workflow complexity and avoid submodule-related action failures
- [ _2026-06-01 00:19:13_ ] [5c73091](<https://github.com/dimaslanjaka/bin/commit/5c73091>)
    
    ci(actions): consolidate checkout-dependencies into setup-environments
    
    - delete standalone checkout-dependencies composite action
    - absorb all checkout steps (main repo, test-repo, git-command-helper, cross-spawn) into setup-environments
    - add `token` input to setup-environments action
    - move submodule update step earlier in the setup sequence with improved script
    - simplify CI workflow: replace separate checkout-dependencies + setup-environments steps with a single setup-environments call in both build and test jobs
- [ _2026-06-01 00:23:59_ ] [6957a9d](<https://github.com/dimaslanjaka/bin/commit/6957a9d>)
    
    ci(actions): refactor build-release to use shared setup-environments action
    
    - add 12 composite action outputs to setup-environments (cache folders, yarn version, branch, sha, urls, package manager, machine, cache-hit)
    - add GITHUB_OUTPUT export step to setup-environments
    - change default prefix-cache-key from runner.os-test- to runner.os-
    - replace inline setup in build-release.yml (checkout, node, bun, yarn, submodules, env vars, cache) with setup-environments call
    - migrate output references from steps.set-env to steps.setup in build-release.yml
    - migrate cache-hit reference from steps.cache to steps.setup.CACHE_HIT
    - update test.yml step naming and add prefix-cache-key input for consistency
- [ _2026-06-01 00:27:01_ ] [a817bf7](<https://github.com/dimaslanjaka/bin/commit/a817bf7>)
    
    ci(release): handle missing base commit in change detection
    
    - validate base commit exists with git cat-file before using github.event.before
    - fall back to HEAD~1 HEAD when base commit is not available in shallow history
    - prevent empty or broken diff ranges in release change detection
- [ _2026-06-01 00:29:22_ ] [b26078f](<https://github.com/dimaslanjaka/bin/commit/b26078f>)
    
    ci(actions): move packageManager removal into setup-environments
    
    - add "Remove packageManager from package.json" step to setup-environments composite action
    - remove duplicate inline step from build-release.yml
    - use jq when available, fall back to Node.js for cross-platform compatibility
- [ _2026-06-01 00:33:19_ ] [752ccb3](<https://github.com/dimaslanjaka/bin/commit/752ccb3>)
    
    ci(release): simplify change detection diff range
    
    - inline git diff calls directly in each branch instead of using intermediate RANGE variable
    - add diagnostic echo when base commit is found
    - remove redundant RANGE indirection
- [ _2026-06-01 00:34:35_ ] [9ea3038](<https://github.com/dimaslanjaka/bin/commit/9ea3038>)
    
    ci(release): add explicit files_changed output to change detection
    
    - set files_changed=true/false based on whether any release tarball files were found
    - ensure downstream conditional steps have a reliable boolean to evaluate
- [ _2026-06-01 00:35:49_ ] [8f5a870](<https://github.com/dimaslanjaka/bin/commit/8f5a870>) ci(release): update file detection to include lib and dist directories
- [ _2026-06-01 00:36:46_ ] [20af091](<https://github.com/dimaslanjaka/bin/commit/20af091>)
    
    ci(test): restrict push trigger to code and test paths
    
    - add paths filter to push event so tests only run on source, test files, or directories
    - skip CI on pushes that only touch docs, configs, or other non-code files
- [ _2026-06-01 00:38:39_ ] [cc2134c](<https://github.com/dimaslanjaka/bin/commit/cc2134c>)
    
    ci(release): harden change detection with empty base and HEAD~1 validation
    
    - validate BASE is non-empty before running cat-file check
    - append ^{commit} to ensure cat-file resolves to a commit object
    - validate HEAD~1 exists with rev-parse before using it as fallback
    - add lib/ and dist/ paths to diff detection alongside release tarballs
    - handle case where no previous commit exists by returning empty files
- [ _2026-06-01 08:12:52_ ] [987233b](<https://github.com/dimaslanjaka/bin/commit/987233b>) ci(test): update test script to use experimental VM modules for Jest
- [ _2026-06-01 09:33:34_ ] [5e2d8f5](<https://github.com/dimaslanjaka/bin/commit/5e2d8f5>)
    
    ci(tests): split into discover + matrix job for parallel test execution
    
    - refactor test job into two stages: discover and test matrix
    - discover stage finds all test/spec files and outputs them as JSON
    - test stage runs each file in a parallel matrix job
    - add fail-fast: false so all tests run regardless of individual failures
    - fix YAML quotes (single to double) for consistency
- [ _2026-06-01 09:43:37_ ] [ccf3a8f](<https://github.com/dimaslanjaka/bin/commit/ccf3a8f>)
    
    feat(cli): add opencode CLI tool with session and project management
    
    - add opc CLI (aliases: opencode-cli) with list/delete commands
    - add storage constants module (src/opencode/storage.ts) for OpenCode directory paths
    - add SQLite wrapper class (src/opencode/sqlite.ts) with migration and query helpers
    - add database layer (src/opencode/database.ts) with load/delete operations
    - add storage and database runner scripts for inspection
    - add documentation for CLI commands and database layer
    - register opc and opencode-cli binaries in build config
    - add better-sqlite3 dependency and type definitions
- [ _2026-06-01 09:52:44_ ] [74f7975](<https://github.com/dimaslanjaka/bin/commit/74f7975>) fix(tsconfig): add missing types configuration for Node.js
- [ _2026-06-01 10:12:28_ ] [906b5ad](<https://github.com/dimaslanjaka/bin/commit/906b5ad>) fix(opencode): update plugin list and ensure snapshot configuration
- [ _2026-06-01 10:16:26_ ] [efae3f5](<https://github.com/dimaslanjaka/bin/commit/efae3f5>)
    
    feat(cli): add VSCode CLI tool for workspace project inspection
    
    - add vscode-cli with list project and --copilot-memory filter commands
    - add vscode/storage.ts with VS Code path constants, URI-to-path decoder, and workspace scanner
    - add vscode/storage.runner.ts for debugging storage paths and workspace entries
    - add docs-src/vscode-cli.md with commands, options, examples, and programmatic API docs
    - add vscode-cli alias to build config and package.json bin mapping
- [ _2026-06-01 10:21:08_ ] [bbea9f7](<https://github.com/dimaslanjaka/bin/commit/bbea9f7>) fix(workflows): add setup step ID for environment configuration
- [ _2026-06-01 10:23:37_ ] [70e545f](<https://github.com/dimaslanjaka/bin/commit/70e545f>)
    
    ci(release): improve release workflow artifact diffing and checkout depth
    
    - ensure full git history with fetch-depth: 0 for accurate base commit resolution
    - replace grep -E pipelines with native git :(glob) path specs for cross-platform robustness
    - improve FILES detection for release artifacts, lib, and dist changes
- [ _2026-06-01 10:31:43_ ] [4baea7d](<https://github.com/dimaslanjaka/bin/commit/4baea7d>)
    
    ci(release): simplify artifact change detection with HEAD diff and untracked files
    
    - replace BASE commit diff approach with direct HEAD diff for tracked files
    - add git ls-files detection for untracked artifacts matching glob patterns
    - simplify error handling and remove fallback to previous commit logic
    - improve robustness for detecting new and modified release artifacts
### 2.0.10

- [ _2025-07-22 12:53:04_ ] [1ebc72d](<https://github.com/dimaslanjaka/bin/commit/1ebc72d>) fix(env): load .env file using dotenv before access process.env
- [ _2025-07-25 09:15:04_ ] [ad00388](<https://github.com/dimaslanjaka/bin/commit/ad00388>)
    
    test(jest): support ESM test files and improve Jest configuration
    
    - Added `test:esm` script for running ESM test files with Node.js flags
    - Extended `.vscode/settings.json` to run `.test.mjs` files with `test:esm`
    - Enabled `extensionsToTreatAsEsm` and configured `ts-jest` and `babel-jest` to support ESM
    - Refactored `babel.config.js` for cleaner export
    - Included `jest-config.defaults` to maintain default behavior
    - Added support for `.mjs` in test match and module resolution
- [ _2025-07-25 09:15:19_ ] [de0f40e](<https://github.com/dimaslanjaka/bin/commit/de0f40e>) test(rmpath): add comprehensive tests for deleteMainScript functionality
- [ _2025-07-25 09:34:41_ ] [d757ff8](<https://github.com/dimaslanjaka/bin/commit/d757ff8>)
    
    test(jest): fully migrate to inline Babel config and tsconfig for ESM support
    
    - Deleted `babel.config.js` in favor of inline `babelConfig` in `jest.config.js`
    - Enhanced `jest.config.js` with complete support for `.mjs`, `.cjs`, `.tsx`, etc.
    - Configured `ts-jest` to use custom `tsconfig.jest.json` with `ESNext` modules
    - Added `moduleNameMapper` to support relative imports with extensions
    - Expanded transform presets for modern Node.js targets
    - Increased test timeout to 120s and excluded common coverage ignore paths
    - Created `tsconfig.jest.json` specifically tailored for Jest/ESM environment
- [ _2025-07-25 09:36:12_ ] [bf1f297](<https://github.com/dimaslanjaka/bin/commit/bf1f297>)
    
    ci(test): split CJS and ESM test runs in GitHub Actions and refine coverage
    
    - Updated GitHub Actions to run CJS and ESM tests separately for better clarity
    - Adjusted `test` script to ignore `.mjs` files (CJS-only)
    - Adjusted `test:esm` script to ignore `.ts`, `.js`, and `.cjs` files (ESM-only)
    - Ensured both scripts support coverage reporting
- [ _2025-07-25 09:36:48_ ] [5c25743](<https://github.com/dimaslanjaka/bin/commit/5c25743>) test(build): add `--detectOpenHandles` flag to CJS and ESM test runs for improved stability
- [ _2025-07-25 09:40:47_ ] [cf44191](<https://github.com/dimaslanjaka/bin/commit/cf44191>) chore(build): update tarball commit message handling in CI workflow
- [ _2025-07-25 09:53:07_ ] [fdc6259](<https://github.com/dimaslanjaka/bin/commit/fdc6259>)
    
    feat: update .gitignore to include coverage and temporary files
    
    fix: update VSCode settings for test scripts and adjust dist folder visibility
    
    feat: add bash and Windows command scripts for binary collections
    
    refactor: simplify git-diff and rmpath scripts to use common node module
    
    feat: implement rmpath functionality in ES module format
    
    chore: enhance build scripts to manage external dependencies and improve packaging
    
    test: add comprehensive tests for rmpath functionality and submodule installation
    
    chore: update package.json to include new scripts and dependencies
    
    fix: improve jest configuration for better compatibility with ESM
    
    docs: update packer.js with detailed usage instructions and requirements
    
    chore: add tsconfig.jest.json for Jest testing environment
    
    test: validate tarball installation and binary command execution
- [ _2025-07-25 09:59:33_ ] [edcec73](<https://github.com/dimaslanjaka/bin/commit/edcec73>) feat: add @babel/preset-typescript to devDependencies
- [ _2025-07-25 10:40:37_ ] [391eddf](<https://github.com/dimaslanjaka/bin/commit/391eddf>)
    
    chore(vscode): improve editor formatting and cleanup VSCode settings
    
    - Expanded settings.json with better JSON formatting and consistency
    - Enabled default Prettier formatter and formatting for multiple languages
    - Disabled some ESLint overrides and enabled formatting via Prettier
    - Removed unused `bin` directory from package files
    - Promoted `ansi-colors` to regular dependency
    - Updated @types/node version
    - Added ts-node override for non-strict mode in tsconfig.json
- [ _2025-07-25 10:43:38_ ] [3509f17](<https://github.com/dimaslanjaka/bin/commit/3509f17>) fix: update @types/fs-extra version to a more flexible range
- [ _2025-07-25 11:29:45_ ] [1658de8](<https://github.com/dimaslanjaka/bin/commit/1658de8>)
    
    build(tsup): refine entry globs to explicitly target source extensions
    
    - Updated `entry` field to include only .ts, .js, .cjs, and .mjs files
    - Prevents unnecessary files from being processed by tsup
- [ _2025-07-25 12:09:17_ ] [9db2ba9](<https://github.com/dimaslanjaka/bin/commit/9db2ba9>)
    
    refactor(build): migrate build script to ESM and restructure binaries
    
    - Replace legacy CommonJS `build.js` with modern `build.mjs` using ES modules
    - Create `binaries/` directory to centralize executable wrappers
    - Add `binary-executor.cjs` for dynamic shell execution on various platforms
    - Automatically copy unmatched bin/* files to `binaries/` during build
    - Update `.gitignore` to exclude `/binaries`
    - Adjust `package.json`:
      - Use `binaries/` instead of `bin/` for custom scripts
      - Correct `bin` paths to point to built CJS files
      - Update `postbuild` to run `build.mjs`
      - Refine `files` array
    - Update `readme.md` to reflect `build.mjs`
    - Update `tsconfig.json` output and declaration options
- [ _2025-07-25 12:11:27_ ] [cba859c](<https://github.com/dimaslanjaka/bin/commit/cba859c>) feat: add logging for final binary mapping in build process
- [ _2025-07-26 19:59:47_ ] [052ec03](<https://github.com/dimaslanjaka/bin/commit/052ec03>) fix: add check for git repository before creating README
- [ _2025-07-26 20:03:24_ ] [1b29407](<https://github.com/dimaslanjaka/bin/commit/1b29407>)
    
    chore(scripts): reorder npm scripts for better readability
    
    - Moved `build:packages` above `build` for logical grouping
    - Relocated `update:packer` below `pack` to group update-related scripts
- [ _2025-07-26 20:12:19_ ] [ebcdb99](<https://github.com/dimaslanjaka/bin/commit/ebcdb99>) fix: find script for development
- [ _2025-07-27 12:36:29_ ] [19f911d](<https://github.com/dimaslanjaka/bin/commit/19f911d>)
    
    refactor(utils): rename utils.js to utils.cjs and update all imports
    
    Renamed `src/utils.js` to `src/utils.cjs` to match CommonJS module naming conventions.
    Updated all corresponding import/require paths across source and test files to use the new filename.
- [ _2025-07-27 12:58:56_ ] [19d62ec](<https://github.com/dimaslanjaka/bin/commit/19d62ec>)
    
    feat(chatgpt): add automated ChatGPT interaction script using Puppeteer
    
    - Added `src/free-chatgpt.js` to automate browser interaction with ChatGPT
    - Supports submitting questions via CLI args or file
    - Saves responses and manages session cookies
    - Added dependencies: puppeteer, puppeteer-extra, puppeteer-extra-plugin-stealth
- [ _2025-07-27 13:34:45_ ] [70cbc5d](<https://github.com/dimaslanjaka/bin/commit/70cbc5d>)
    
    refactor(utils): move utils module to utils/index.js and update all imports
    
    Moved `utils.cjs` to `utils/index.js` for better modular structure and convention.
    Updated all corresponding import paths across the codebase to reflect the new location.
- [ _2025-07-27 13:46:53_ ] [335aa44](<https://github.com/dimaslanjaka/bin/commit/335aa44>)
    
    feat(build): add Rollup configuration for bundling and support JS builds
    
    - Introduced `rollup.config.cjs` to build JS/TS sources with customizable bundling
    - Added new CLI binaries (e.g. `binary-collections2`, `changelog2`, `free-chatgpt`, etc.) to `package.json`
    - Added `@rollup` plugins and `rollup` as dev dependencies
    - Updated build scripts to support Rollup (`build:rollup`) and separate tsup step (`build:tsup`)
    - Enabled `allowJs` in `tsconfig.build.json` for JS transpilation
- [ _2025-07-27 13:48:15_ ] [20f71d2](<https://github.com/dimaslanjaka/bin/commit/20f71d2>)
    
    feat(git-diff): improve UX with emoji, rename output constants, and generate GPT prompt
    
    - Renamed `OUTPUT` to `DIFF_OUTPUT` and added `GPT_DIFF_OUTPUT` for ChatGPT prompt generation
    - Replaced plain console messages with emojis for better visual feedback
    - Added generation of a prompt file (`gpt-question.txt`) containing a ChatGPT request to generate a commit message
    - Updated imports to reflect moved `utils` module
- [ _2025-07-27 13:49:36_ ] [f3985f7](<https://github.com/dimaslanjaka/bin/commit/f3985f7>) feat(build): add chatgpt binary mapping to defaultBin
- [ _2025-07-27 14:14:44_ ] [25b29f1](<https://github.com/dimaslanjaka/bin/commit/25b29f1>)
    
    docs: add usage guides for ChatGPT and GitHub Actions cache cleaner
    
    - Added `docs/clean-github-actions-caches.md` with usage, features, and setup instructions
    - Added `docs/free-chatgpt.md` with CLI options and behavior for automated ChatGPT interaction
    - Updated `readme.md`:
      - Linked to new documentation files
      - Refined binary categories and descriptions
      - Improved table formatting and markdown consistency
      - Streamlined GitHub Actions and ChatGPT sections
    - Included `docs/**/*.md` in `package.json` files list
- [ _2025-07-27 14:20:31_ ] [215c560](<https://github.com/dimaslanjaka/bin/commit/215c560>)
    
    feat(log): add console output to confirm GPT diff prompt save location
    
    Added a new log message indicating where the GPT diff prompt was saved.
    This improves feedback and traceability when running the git diff script.
- [ _2025-07-27 14:21:17_ ] [0543545](<https://github.com/dimaslanjaka/bin/commit/0543545>) fix(git-diff): correct formatting in GPT diff prompt message
- [ _2025-07-27 14:22:30_ ] [49beb96](<https://github.com/dimaslanjaka/bin/commit/49beb96>) fix(config): update getTempDir to return absolute path for temporary directory
- [ _2025-07-27 14:42:27_ ] [e7deda8](<https://github.com/dimaslanjaka/bin/commit/e7deda8>) fix(settings): change organizeImports action to never
- [ _2025-07-27 14:51:18_ ] [b6e8483](<https://github.com/dimaslanjaka/bin/commit/b6e8483>) feat(docs): add documentation for GitHub Actions Cache Cleaner and free-chatgpt.js
- [ _2025-07-27 14:55:24_ ] [4315b36](<https://github.com/dimaslanjaka/bin/commit/4315b36>) fix(docs): update links for GitHub Actions Cache Cleaner and Free ChatGPT automation tool documentation
- [ _2025-07-27 14:56:58_ ] [5910627](<https://github.com/dimaslanjaka/bin/commit/5910627>) feat: add TypeDoc configuration and runner scripts for documentation generation
- [ _2025-07-27 15:24:00_ ] [7659322](<https://github.com/dimaslanjaka/bin/commit/7659322>)
    
    feat(typedoc): extract and copy local links from readme for doc generation
    
    - Added `marked` as a dev dependency for markdown parsing
    - Updated `typedoc.config.js` to parse readme content and extract all local links
    - Implemented logic to copy linked local files (e.g., images or docs) into the temp directory
    - Renamed hardcoded readme output path for clarity
    - Minor markdown formatting fix in `readme.md`
- [ _2025-07-27 15:41:49_ ] [444e6df](<https://github.com/dimaslanjaka/bin/commit/444e6df>) feat(typedoc): add typedoc-plugin-ga for Google Analytics tracking
- [ _2025-07-27 15:43:11_ ] [d5ccb7d](<https://github.com/dimaslanjaka/bin/commit/d5ccb7d>) fix(typedoc): comment out htmlLang option in TypeDoc configuration
- [ _2025-07-27 15:48:15_ ] [682c385](<https://github.com/dimaslanjaka/bin/commit/682c385>) feat(typedoc): add highlightLanguages option for syntax highlighting in documentation
- [ _2025-07-27 15:50:12_ ] [d47dec2](<https://github.com/dimaslanjaka/bin/commit/d47dec2>)
    
    refactor(typedoc): remove support for loading external typedoc options file
    
    - Deleted logic for reading and merging external `options.json` file
    - Removed `readfile` helper function previously used for file validation
    - Exported default typedoc options directly
- [ _2025-07-27 15:51:59_ ] [7fc66d8](<https://github.com/dimaslanjaka/bin/commit/7fc66d8>) refactor(typedoc): reorganize execution flow for main module
- [ _2025-07-27 15:54:02_ ] [7762826](<https://github.com/dimaslanjaka/bin/commit/7762826>) refactor(typedoc): update documentation comments in runner and config scripts
- [ _2025-07-27 16:26:54_ ] [4ab7ad7](<https://github.com/dimaslanjaka/bin/commit/4ab7ad7>)
    
    feat(typedoc): replace local links in README with GitHub URLs when available
    
    Added logic to resolve and replace local file links in the README with corresponding GitHub URLs using Axios and Git metadata. Falls back to copying local files if the GitHub URL cannot be resolved. Introduced utility function `getGitHubFileUrl` to construct GitHub blob links based on the current branch and repository configuration.
- [ _2025-07-27 16:48:05_ ] [12fe332](<https://github.com/dimaslanjaka/bin/commit/12fe332>) refactor(typedoc): replace path module with upath for cross-platform compatibility
- [ _2025-07-27 16:55:15_ ] [608fcaf](<https://github.com/dimaslanjaka/bin/commit/608fcaf>)
    
    refactor(typedoc): extract README build logic into separate module
    
    Moved README and changelog processing logic from `typedoc.config.js` into a new dedicated module `typedoc.readme.js` to improve code modularity and maintainability. Updated `typedoc-runner.js` to use the new `buildReadme` function before documentation compilation.
- [ _2025-07-29 20:46:20_ ] [2c4f8f1](<https://github.com/dimaslanjaka/bin/commit/2c4f8f1>)
    
    feat(scripts): add Windows batch scripts to clean node_modules directories
    
    - Added `clean-nodemodule.cmd` to recursively delete `node_modules` using DEL and RMDIR
    - Added `clean-nodemodules.cmd` for improved recursive deletion using a FOR loop
    - Updated submodule `git-command-helper` to latest commit
    - Updated `releases/bin.tgz` archive with new script additions
- [ _2025-07-29 21:06:48_ ] [8ca1246](<https://github.com/dimaslanjaka/bin/commit/8ca1246>)
    
    test(jest): ignore test/package.json in module path resolution
    
    - Updated Jest config to add `modulePathIgnorePatterns` for `<rootDir>/test/package.json`
    - Renamed test package to `binary-collections-test` and marked it as private
- [ _2025-07-29 21:11:33_ ] [72df5d9](<https://github.com/dimaslanjaka/bin/commit/72df5d9>)
    
    feat: add `remove-module` CLI tool to delete modules from Node, Composer, or Python environments
    
    - Added new script entry `"remove-module"` to `package.json` pointing to `lib/remove-module.cjs`
    - Implemented `remove-module.mjs` to support module removal from:
      - `node_modules` (Node.js)
      - `vendor/composer` (PHP Composer)
      - `venv/.venv site-packages` (Python)
    - Includes CLI help flags `--help` and `-h`
    - Added basic tests for CLI help output in `remove-module.test.ts`
- [ _2025-08-08 21:14:05_ ] [6585351](<https://github.com/dimaslanjaka/bin/commit/6585351>)
    
    refactor: rename utils index file from .js to .cjs extension
    
    Update all import statements across source files to reference the renamed
    utils/index.cjs file instead of utils/index.js to properly reflect CommonJS
    module format.
- [ _2025-08-09 00:32:15_ ] [602211a](<https://github.com/dimaslanjaka/bin/commit/602211a>)
    
    refactor: extract ChatGPT automation logic into utils/chatgpt.js
    
    - Moved Puppeteer-based ChatGPT interaction code from src/free-chatgpt.js to new src/utils/chatgpt.js module.
    - Added `runChatGpt` function to handle both text questions and file uploads.
    - Implemented login detection, cookie handling, DOM stability checks, and temporary chat activation.
    - Updated free-chatgpt.js to delegate to `runChatGpt`.
    - Added `es-main` dependency for module entry point detection.
- [ _2025-08-09 00:34:56_ ] [f59b0a0](<https://github.com/dimaslanjaka/bin/commit/f59b0a0>) fix: update log messages to use relative paths for output files in git-diff
- [ _2025-08-09 02:13:53_ ] [1607e24](<https://github.com/dimaslanjaka/bin/commit/1607e24>) refactor: migrate project to ESM with CJS support
- [ _2025-08-09 02:15:54_ ] [173a573](<https://github.com/dimaslanjaka/bin/commit/173a573>) refactor: rename build.mjs to build.exports.mjs
- [ _2025-08-09 02:16:51_ ] [a59dd32](<https://github.com/dimaslanjaka/bin/commit/a59dd32>) feat: add Rollup configuration for building ESM and CJS modules
- [ _2025-08-09 03:34:54_ ] [f9577b7](<https://github.com/dimaslanjaka/bin/commit/f9577b7>) refactor: consolidate ESM export support for findNodeModules function
- [ _2025-08-09 03:45:50_ ] [a753b46](<https://github.com/dimaslanjaka/bin/commit/a753b46>)
    
    feat(build): generate `src/index.ts` automatically and switch lib output to CJS
    
    - Added build step in `build.exports.mjs` to scan `src/` and generate `src/index.ts`
      exporting all modules, handling `.ts`, `.mjs`, `.js`, and `.cjs` formats.
    - Updated `src/index.ts` to export every available module in the project.
    - Changed Rollup's `lib` build format from ESM to CommonJS.
    - Updated `releases/bin.tgz` with the new compiled output.
- [ _2025-08-09 03:46:18_ ] [5b90dc8](<https://github.com/dimaslanjaka/bin/commit/5b90dc8>) feat(build): generate src/index.ts to export all modules dynamically
- [ _2025-08-09 03:48:22_ ] [769a496](<https://github.com/dimaslanjaka/bin/commit/769a496>) feat(build): change output format from ESM to CJS in Rollup configuration
- [ _2025-08-09 04:38:35_ ] [4474f37](<https://github.com/dimaslanjaka/bin/commit/4474f37>)
    
    refactor(git-diff): modularize CLI entry and add JSDoc for `runGitDiff`
    
    - Added `getArgs` import at the top for clarity.
    - Wrapped CLI logic in `mainGitDiff()` for better testability and reuse.
    - Enhanced `runGitDiff` with detailed JSDoc explaining purpose, parameters, and usage examples.
    - Exported both `runGitDiff` and `gitDiff` for programmatic use.
    - Added CLI execution guard (`require.main === module`) for cleaner module usage.
- [ _2025-08-09 04:38:53_ ] [4f55a9a](<https://github.com/dimaslanjaka/bin/commit/4f55a9a>) fix(tsconfig): ensure allowSyntheticDefaultImports is set to true
- [ _2025-08-09 04:39:10_ ] [8c0972c](<https://github.com/dimaslanjaka/bin/commit/8c0972c>) fix(tsconfig): correct output directory to 'lib' and ensure compiler options are set
- [ _2025-08-09 04:39:30_ ] [68142f8](<https://github.com/dimaslanjaka/bin/commit/68142f8>) refactor(build): remove automatic generation of src/index.ts for module exports
- [ _2025-08-09 05:01:42_ ] [28c3fe1](<https://github.com/dimaslanjaka/bin/commit/28c3fe1>) feat(rollup): modularize Rollup configuration to support multiple entry files
- [ _2025-08-09 05:04:38_ ] [7fb9b60](<https://github.com/dimaslanjaka/bin/commit/7fb9b60>) refactor: reusing tsup and disable dts build
- [ _2025-08-09 05:21:10_ ] [0670abf](<https://github.com/dimaslanjaka/bin/commit/0670abf>)
    
    refactor(git-diff): modularize CLI logic and enhance documentation
    
    - Moved argument parsing and CLI execution into a dedicated `mainGitDiff()` function for better structure and reusability.
    - Added detailed JSDoc comments to `runGitDiff()` describing purpose, parameters, and usage examples.
    - Imported `getArgs` at the top for consistency.
    - Exported both `runGitDiff` and `gitDiff` for programmatic use.
    - Added CLI entry point guard (`require.main === module`) to separate script execution from module usage.
- [ _2025-08-09 05:21:42_ ] [3b7c088](<https://github.com/dimaslanjaka/bin/commit/3b7c088>) fix(git-diff): update GPT question file path to use constant variable
- [ _2025-08-09 05:22:36_ ] [20375fb](<https://github.com/dimaslanjaka/bin/commit/20375fb>)
    
    refactor(git-diff): restructure CLI flow and improve documentation
    
    - Imported `getArgs` at the top for consistency.
    - Added detailed JSDoc to `runGitDiff()` describing its purpose, parameters, and usage examples.
    - Moved CLI argument parsing and execution logic into a new `mainGitDiff()` function for better modularity.
    - Exported `runGitDiff` and `gitDiff` for programmatic usage.
    - Added CLI entry point check (`require.main === module`) to separate module usage from direct execution.
- [ _2025-08-09 05:28:21_ ] [15ea2e3](<https://github.com/dimaslanjaka/bin/commit/15ea2e3>) fix(package): remove unused dependency 'es-main
- [ _2025-08-09 05:31:41_ ] [3ccb6df](<https://github.com/dimaslanjaka/bin/commit/3ccb6df>) refactor(git-diff): convert mainGitDiff to async and await runChatGpt
- [ _2025-08-09 05:56:31_ ] [e9f1789](<https://github.com/dimaslanjaka/bin/commit/e9f1789>)
    
    refactor(git-diff): improve CLI detection, emoji logging, and ChatGPT invocation
    
    - Added `fileURLToPath` and `pathToFileURL` imports to support robust `__dirname` and `__filename` handling in ESM.
    - Reintroduced `runChatGpt` import after argument parsing for clarity.
    - Implemented cross-environment detection for direct script execution in both CommonJS and ESM.
    - Updated console logs to use clearer emoji indicators for statuses and errors.
    - Changed `runChatGpt` call to run in headless mode by default.
- [ _2025-08-09 05:58:05_ ] [a7206ea](<https://github.com/dimaslanjaka/bin/commit/a7206ea>)
    
    refactor(chatgpt): enhance documentation, add response file option, and improve CLI detection
    
    - Added detailed JSDoc comments for multiple helper functions (`saveCookies`, `_restoreCookies`, `writeQuestion`, `clickSubmitButton`, `sleep`, etc.).
    - Updated `handleStreamingResponse` to accept a customizable output file path.
    - Added `responseFile` option to `runChatGpt` for saving responses to a specified location.
    - Modified `runChatGpt` to pass `responseFile` to `handleStreamingResponse`.
    - Implemented cross-environment detection to determine if script is run directly in CommonJS or ESM.
- [ _2025-08-09 06:05:59_ ] [72e4007](<https://github.com/dimaslanjaka/bin/commit/72e4007>) fix(chatgpt): check for plus button existence before clicking to prevent errors
- [ _2025-08-09 06:17:23_ ] [5d0093d](<https://github.com/dimaslanjaka/bin/commit/5d0093d>) feat(chatgpt): enhance browser launch with fallback options and add robust error handling in runChatGpt
- [ _2025-08-09 06:24:18_ ] [933b3c3](<https://github.com/dimaslanjaka/bin/commit/933b3c3>) feat(git-diff): add --ai flag to generate commit messages via ChatGPT with error handling
- [ _2025-08-09 22:38:13_ ] [cf13c9f](<https://github.com/dimaslanjaka/bin/commit/cf13c9f>) fix(eslint): add missing ignore pattern for lib directory
- [ _2025-08-09 22:47:27_ ] [5e75a62](<https://github.com/dimaslanjaka/bin/commit/5e75a62>) refactor(chatgpt): remove direct script execution logic and create runner script
- [ _2025-08-09 22:55:34_ ] [ca50d9a](<https://github.com/dimaslanjaka/bin/commit/ca50d9a>) feat(build): update Node.js version from 18 to 22 in workflow
- [ _2025-08-09 23:34:48_ ] [8535b0e](<https://github.com/dimaslanjaka/bin/commit/8535b0e>) fix(resolutions): update URLs for git-command-helper and sbg-utility packages
- [ _2025-08-10 00:06:08_ ] [0e91217](<https://github.com/dimaslanjaka/bin/commit/0e91217>)
    
    refactor(cli): improve binary resolution and split git-diff CLI entry
    
    - Enhanced binBuilder to map *-cli files to their base command name while removing redundant entries
    - Updated package.json bin entries to point directly to CLI-specific implementations for `find-node-modules` and `git-diff`
    - Improved `binary-collections`:
      - Added detailed JSDoc comments for key functions
      - Enhanced `findScript` to detect and prefer CLI variants of scripts
      - Added debug logging for argument parsing and script execution
      - Refined argument reconstruction to preserve flags and values
    - Split `git-diff` CLI execution into a dedicated `git-diff-cli.js` entrypoint
    - Cleaned up `git-diff.js` by removing direct execution detection logic and exporting `mainGitDiff` and related constants for reuse
- [ _2025-08-10 00:08:09_ ] [dd6255c](<https://github.com/dimaslanjaka/bin/commit/dd6255c>) fix(git-diff): remove duplicate console message
- [ _2025-08-10 00:36:22_ ] [5eb7a4b](<https://github.com/dimaslanjaka/bin/commit/5eb7a4b>) refactor(jest): migrate to ESM syntax
- [ _2025-08-10 01:12:27_ ] [c220ede](<https://github.com/dimaslanjaka/bin/commit/c220ede>) refactor(gitattributes): change to CJS extension
- [ _2025-08-10 01:21:11_ ] [61141f8](<https://github.com/dimaslanjaka/bin/commit/61141f8>) fix(test): rename files to cjs extension
- [ _2025-08-25 13:52:27_ ] [2ac6d78](<https://github.com/dimaslanjaka/bin/commit/2ac6d78>) refactor(git-diff): replace fs and path with fs-extra and upath for improved functionality
- [ _2025-08-25 13:57:43_ ] [94a358f](<https://github.com/dimaslanjaka/bin/commit/94a358f>) fix(package): update sbg-utility version to 2.0.10 and fix resolution URL
- [ _2025-08-25 14:03:27_ ] [a626c7d](<https://github.com/dimaslanjaka/bin/commit/a626c7d>) refactor(build): add project cleanup step before build process
- [ _2025-08-25 14:06:06_ ] [32d9a0c](<https://github.com/dimaslanjaka/bin/commit/32d9a0c>)
    
    feat(submodule): add CLI and core logic for removing git submodules
    
    - introduce `src/submodule-remove-cli.js` for CLI usage
    - add `src/submodule-remove.cjs` with submodule removal logic
    - update `package.json` to point `submodule-remove` command to new CLI
    - rename `bin/submodule-remove` to `bin/submodule-remove.txt`
- [ _2025-08-25 14:06:19_ ] [a5ff099](<https://github.com/dimaslanjaka/bin/commit/a5ff099>) fix(git-diff): update script to call git-diff-cli.cjs instead of git-diff.cjs
- [ _2025-08-25 14:07:23_ ] [e27e293](<https://github.com/dimaslanjaka/bin/commit/e27e293>) test(jest): update config with rootDir and cacheDirectory options
- [ _2025-08-25 14:33:19_ ] [cd32d51](<https://github.com/dimaslanjaka/bin/commit/cd32d51>) fix(dependencies): update package versions for axios, dotenv, fs-extra, git-command-helper, puppeteer, yaml, babel, eslint, jest, rollup, typedoc, and others
- [ _2025-08-25 14:33:42_ ] [e514e19](<https://github.com/dimaslanjaka/bin/commit/e514e19>) fix(jest): run single test
- [ _2025-10-22 17:36:22_ ] [e61aa18](<https://github.com/dimaslanjaka/bin/commit/e61aa18>)
    
    fix(submodule): add robust cleanup and logging when removing submodules
    
    - Wrap `git submodule deinit` in try/catch and warn instead of throwing when the submodule doesn't exist.
    - Add try/catch around removal of `submodule.*` git config section with warning on failure.
    - Log removal of `.git/modules/<submodule>` when present; warn if missing.
    - Remove the submodule entry from `.gitmodules` (safely strip its section) and log the action; warn if `.gitmodules` is absent.
    - Ensure submodule directory is removed and print final confirmation.
    
    This improves resilience of the submodule removal routine by handling missing entries gracefully and providing clearer logs.
- [ _2025-10-22 17:37:56_ ] [dcca34b](<https://github.com/dimaslanjaka/bin/commit/dcca34b>) feat(npmignore): add .npmignore to exclude temporary files while keeping .gitkeep
- [ _2025-10-28 15:13:47_ ] [e49a749](<https://github.com/dimaslanjaka/bin/commit/e49a749>) fix(dependencies): update git-command-helper and sbg-utility URLs in resolutions
- [ _2026-03-11 12:29:04_ ] [51585ec](<https://github.com/dimaslanjaka/bin/commit/51585ec>) fix(settings): update PATH environment variable for Linux and Windows
- [ _2026-03-11 13:00:09_ ] [dfb63d7](<https://github.com/dimaslanjaka/bin/commit/dfb63d7>)
    
    fix: correct gitattributes import and make deletion utility resilient
    
    Remove the erroneous `.default` access when requiring `src/git/gitattributes.cjs` to prevent the runtime
    TypeError and correctly destructure the named `updateGitAttributes` export.
    
    Harden `del` and `delStream` in `src/utils/index.cjs`:
    - Check existence and use `lstatSync` to detect symlinks; unlink symlinks without following targets.
    - For directories, delete children then remove the directory with `rmdirSync`, falling back to `fs.rmSync` if needed.
    - For files, prefer `unlinkSync` with a fallback to `rmSync` on failure.
    - Add robust try/catch handling and clearer logging for success/failure cases.
    
    Files changed:
    - src/git/line-endings.cjs: fixed import
    - src/utils/index.cjs: robust deletion logic and improved delStream error handling
- [ _2026-03-11 13:00:41_ ] [c17a4c3](<https://github.com/dimaslanjaka/bin/commit/c17a4c3>) fix(gitattributes): standardize line endings and improve formatting consistency
- [ _2026-03-11 13:01:47_ ] [72e7906](<https://github.com/dimaslanjaka/bin/commit/72e7906>)
    
    refactor(build): remove package.json key reordering in build.exports.mjs
    
    Simplify `build.exports.mjs` by writing `pkg` directly to `package.json` instead of
    reconstructing an ordered object. Removes the `orderedKeys` array and
    `reconstructPackageJson` helper to reduce complexity and preserve original key order.
- [ _2026-03-11 13:02:51_ ] [b0859ee](<https://github.com/dimaslanjaka/bin/commit/b0859ee>)
    
    feat(pkg): add php-cs-fixer-staged and restore CLI bins
    
    - Add `src/php-cs-fixer-staged.cjs`: a new CLI that runs `php-cs-fixer` on staged PHP files (auto-detects common binary locations and supports Windows via `php <script>`).
    - Restore/reintroduce the `bin` mapping in `package.json` to expose project CLI commands (e.g. `git-fix`, `free-chatgpt`, `binary-collections`, etc.).
    - Pin `cross-spawn` tarball URL to a specific commit hash for reproducible installs.
- [ _2026-03-12 08:44:46_ ] [9d2110b](<https://github.com/dimaslanjaka/bin/commit/9d2110b>) fix(npmignore): update tmp directory pattern for better exclusion
- [ _2026-03-12 08:51:19_ ] [9202a09](<https://github.com/dimaslanjaka/bin/commit/9202a09>) fix(jest): add missing module file extensions for Jest configuration
- [ _2026-03-12 09:06:48_ ] [ad1ca1c](<https://github.com/dimaslanjaka/bin/commit/ad1ca1c>) fix(dotenv): add override and quiet options for dotenv configuration
- [ _2026-03-12 09:12:21_ ] [e8c8383](<https://github.com/dimaslanjaka/bin/commit/e8c8383>)
    
    feat(cli): add kill-night-crows command with packaged ps1 support
    
    Add a new Windows PowerShell watcher script to detect non-responding
    MadGlobal-Win64-Shipping.exe and kill the related MadGlobal.exe process tree.
    
    Add kill-night-crows Node CLI wrapper with:
    - --help output
    - script path diagnostics
    - script resolution priority: ../bin then ../binaries
    
    Update build export flow to copy bin/kill-night-crows.ps1 into binaries
    for packaged installs, and include copy logging.
    
    Register kill-night-crows in package.json bin mappings and extend
    tarball validation tests to cover the new command and runtime package check timing.
- [ _2026-03-17 08:31:26_ ] [02d2882](<https://github.com/dimaslanjaka/bin/commit/02d2882>)
    
    feat(bin): add Windows batch launcher for kill-night-crows
    
    Add `bin/kill-night-crows.bat` to invoke the existing PowerShell script with
    forwarded arguments and propagated exit code.
    
    Also set `$KeepWindowOpen` to `false` in `bin/kill-night-crows.ps1` and include
    the new batch file in `requiredBinFiles` within `build.exports.mjs` so it is
    packaged with build outputs.
- [ _2026-03-19 17:07:44_ ] [f1a7a14](<https://github.com/dimaslanjaka/bin/commit/f1a7a14>)
    
    fix(kill-night-crows): harden process tree termination to avoid killing unrelated processes
    
    Replace custom recursive process enumeration with guarded taskkill /T by root PID.
    Add safety checks for invalid/self PID and verify expected root process name before termination.
    Improve failure logging for taskkill output and pass expected launcher name when invoking Stop-ProcessTree.
- [ _2026-03-19 17:23:25_ ] [4505aea](<https://github.com/dimaslanjaka/bin/commit/4505aea>)
    
    build(puppeteer): add Puppeteer config and browser install script
    
    Add a new .puppeterrc.cjs configuration file to manage Puppeteer cache/temp paths,
    ensure required directories are created, and disable Chrome/Firefox auto-download.
    
    Also add a package script:
    - puppeteer:browser -> npx puppeteer browsers install chrome
- [ _2026-03-19 17:23:57_ ] [3e710f0](<https://github.com/dimaslanjaka/bin/commit/3e710f0>)
    
    fix(chatgpt): avoid navigation timeout on persistent network connections
    
    Replace strict network-idle navigation waits with a resilient strategy:
    - add configurable navigation and network-idle timeout constants
    - introduce a fallback navigation helper that waits for DOM content first
    - keep network-idle waiting as best-effort to avoid hard failures
    - update login navigation flow to use the same non-blocking approach
    
    This prevents Puppeteer timeouts on pages that keep long-lived connections open.
- [ _2026-03-19 17:27:42_ ] [c9b5c97](<https://github.com/dimaslanjaka/bin/commit/c9b5c97>) fix(chatgpt): ensure single page operation by closing additional pages
- [ _2026-03-19 18:10:52_ ] [999bcdc](<https://github.com/dimaslanjaka/bin/commit/999bcdc>)
    
    fix(chatgpt): stabilize prompt submission and streamline runner setup
    
    Improve the ChatGPT automation flow to submit prompts reliably and reduce local setup friction.
    
    - add resilient prompt input with instant injection and keyboard fallback
    - harden submit logic with selector validation, retries, and submission confirmation
    - support composer-submit-button and layered fallback strategies with diagnostics
    - inline small question files (<= 2 KB) to skip upload/login flow when possible
    - fix page initialization order and guard failed submissions before waiting for responses
    - maximize browser launch and prefer local Chrome executable on Windows
    - add VS Code launch configuration for ChatGPT runner debugging
    - update Puppeteer install flow (postinstall browser setup) and bump Puppeteer version
    - include updated release archive artifact
- [ _2026-03-19 18:19:48_ ] [43f5aa1](<https://github.com/dimaslanjaka/bin/commit/43f5aa1>) fix(git-diff-cli): add shebang for executable script compatibility
- [ _2026-03-19 18:20:03_ ] [53ee626](<https://github.com/dimaslanjaka/bin/commit/53ee626>) fix(build): add condition to prevent .tgz files from triggering the build job
- [ _2026-03-19 18:23:31_ ] [8292462](<https://github.com/dimaslanjaka/bin/commit/8292462>) fix(build): add shebang to .cjs files if missing in final bin mapping
- [ _2026-03-19 18:26:52_ ] [2ff27e0](<https://github.com/dimaslanjaka/bin/commit/2ff27e0>) fix(env): enable quiet mode and override for dotenv configuration
- [ _2026-03-19 18:27:56_ ] [43dfaf1](<https://github.com/dimaslanjaka/bin/commit/43dfaf1>) fix(env): check for .env file existence before loading configuration
- [ _2026-03-31 09:41:18_ ] [f37c3ee](<https://github.com/dimaslanjaka/bin/commit/f37c3ee>)
    
    chore: update package.json configuration
    
    - include .puppeterrc.* in published files
    - remove postinstall script that automatically installs Puppeteer browser
- [ _2026-04-21 07:33:07_ ] [ccdfe29](<https://github.com/dimaslanjaka/bin/commit/ccdfe29>)
    
    chore: enhance del-node-modules.js for better cleanup
    
    Refactor node_modules cleanup script to improve concurrency and add dry-run functionality.
- [ _2026-04-25 16:39:09_ ] [dd21494](<https://github.com/dimaslanjaka/bin/commit/dd21494>) fix(env): enable quiet mode for dotenv configuration across multiple files
- [ _2026-04-25 16:42:25_ ] [0543d9a](<https://github.com/dimaslanjaka/bin/commit/0543d9a>)
    
    feat(git): add undo-commit and undo-staged commands
    
    - Add CLI entrypoints `src/git/undo-commit-cli.js` and `src/git/undo-staged-cli.js`.
    - Implement `undoLastCommit` in `src/git/undo-commit.cjs` (runs `git reset --soft HEAD~1` to undo the last commit while keeping changes staged).
    - Implement `undoStagedChanges` in `src/git/undo-staged.cjs` (runs `git reset HEAD .` to unstage staged changes).
    - Register new commands and aliases in `package.json` and `build.exports.mjs`:
      - `undo-commit`, `undo-last-commit`, `git-undo-commit` → `lib/git/undo-commit.cjs`
      - `undo-staged`, `git-undo-staged` → `lib/git/undo-staged.cjs`
    
      ref: https://github.com/dimaslanjaka/bin/issues/16
- [ _2026-04-25 16:46:06_ ] [e9ac107](<https://github.com/dimaslanjaka/bin/commit/e9ac107>) chore: update sbg-utility dependency to version 2.0.11
- [ _2026-04-25 16:47:34_ ] [9a62d82](<https://github.com/dimaslanjaka/bin/commit/9a62d82>) feat: add default alias for ESM default export in gitattributes module
- [ _2026-04-25 16:54:19_ ] [1960cc6](<https://github.com/dimaslanjaka/bin/commit/1960cc6>) chore: update dependencies to latest versions
- [ _2026-04-25 16:58:11_ ] [da3990f](<https://github.com/dimaslanjaka/bin/commit/da3990f>) test(build): update cache paths to include tmp and test directories
- [ _2026-04-25 17:00:03_ ] [b3d645b](<https://github.com/dimaslanjaka/bin/commit/b3d645b>)
    
    test(jest): configure ts-jest and include Node types for tests
    
    Add `globals.ts-jest.tsconfig` in `jest.config.js` pointing to `tsconfig.jest.json`
    and add `"node"` to the `types` array in `tsconfig.jest.json` so test files
    have Node typings (e.g. `child_process`, `path`, `__dirname`) and ts-jest uses
    the proper tsconfig during Jest runs.
- [ _2026-04-25 17:02:28_ ] [ae790ef](<https://github.com/dimaslanjaka/bin/commit/ae790ef>)
    
    build(tsconfig): add ignoreDeprecations to tsconfig.build.json
    
    Add compilerOption "ignoreDeprecations": "6.0" to tsconfig.build.json to
    silence TypeScript deprecation errors (TS5101, TS5107) caused by
    deprecated options like downlevelIteration and moduleResolution=node10,
    allowing the build to succeed while preparing migration to TypeScript 7.0.
- [ _2026-04-25 17:05:01_ ] [91c6d3c](<https://github.com/dimaslanjaka/bin/commit/91c6d3c>)
    
    Refactor clean-logs workflow with enhanced inputs
    
    Updated workflow to improve parameter handling and added scheduling.
- [ _2026-05-13 06:24:15_ ] [5aab1f5](<https://github.com/dimaslanjaka/bin/commit/5aab1f5>) feat(cli): extract package-resolutions-updater CLI, refactor core module exports, and update bin mappings & dependency resolutions
- [ _2026-05-13 06:25:51_ ] [9751714](<https://github.com/dimaslanjaka/bin/commit/9751714>) chore(package-resolutions): comment out hexo-related package resolutions
- [ _2026-05-13 06:41:33_ ] [cc60c82](<https://github.com/dimaslanjaka/bin/commit/cc60c82>)
    
    feat(tests): add tests for getLatestCommit function and mock GitHub responses
    
    Co-authored-by: Copilot <copilot@github.com>
- [ _2026-05-13 06:58:11_ ] [00a9ddc](<https://github.com/dimaslanjaka/bin/commit/00a9ddc>) fix(bin): update pkg-resolutions-updater path to use CLI version
- [ _2026-05-13 07:15:14_ ] [aa547d4](<https://github.com/dimaslanjaka/bin/commit/aa547d4>) fix(cli): comment out console log for valid GitHub URL validation
- [ _2026-05-13 07:18:20_ ] [3fc7f60](<https://github.com/dimaslanjaka/bin/commit/3fc7f60>) fix(cli): improve console log formatting and add summary for GitHub URL updates
- [ _2026-05-13 07:19:07_ ] [de162dc](<https://github.com/dimaslanjaka/bin/commit/de162dc>) fix(deps): update marked dependency to version 18.0.3
- [ _2026-05-14 05:02:59_ ] [49745cc](<https://github.com/dimaslanjaka/bin/commit/49745cc>) feat(token-validation): add function to check GitHub token validity
- [ _2026-05-14 05:06:40_ ] [811f731](<https://github.com/dimaslanjaka/bin/commit/811f731>) feat(workspace): add functions to find Yarn workspace root directory
- [ _2026-05-14 05:11:46_ ] [9a498ca](<https://github.com/dimaslanjaka/bin/commit/9a498ca>) feat(env-files): add function to find .env files in current and parent directories
- [ _2026-05-14 05:13:53_ ] [ed429f7](<https://github.com/dimaslanjaka/bin/commit/ed429f7>)
    
    refactor(findEnvFiles): simplify glob ignore handling and expand ignored directories
    
    - replace plain directory names with full glob ignore patterns
    - remove dynamic ignore pattern mapping logic
    - add more ignored directories for faster scanning
    - improve glob filtering consistency for nested paths
- [ _2026-05-14 05:17:35_ ] [52fea76](<https://github.com/dimaslanjaka/bin/commit/52fea76>) feat(findEnvFiles): enhance function to support filtering and improve file handling
- [ _2026-05-14 05:18:08_ ] [e8aac93](<https://github.com/dimaslanjaka/bin/commit/e8aac93>)
    
    feat(package-resolutions-updater): auto-detect .env files with GitHub tokens
    
    - add findEnvFiles utility integration for recursive .env discovery
    - fallback to scanning parent and subdirectories when local .env is missing
    - filter .env files containing GITHUB_TOKEN or ACCESS_TOKEN
    - automatically load the first matching environment file
    - improve dotenv loading flexibility in monorepo and nested projects
- [ _2026-05-14 05:31:39_ ] [c820ac6](<https://github.com/dimaslanjaka/bin/commit/c820ac6>) feat(yarn-clean): add bash and cmd scripts for cleaning workspaces node_modules and yarn.lock
- [ _2026-05-14 05:33:07_ ] [235d5c0](<https://github.com/dimaslanjaka/bin/commit/235d5c0>)
    
    docs(bin): add comprehensive block comments to binary executor script
    
    Add detailed documentation throughout the binary launcher script
    to explain module usage, platform-specific script resolution,
    execution flow, argument forwarding, and process handling.
    
    Also remove unused commented-out shell detection code and improve
    readability with structured comment sections.
- [ _2026-05-14 05:37:12_ ] [f984402](<https://github.com/dimaslanjaka/bin/commit/f984402>)
    
    chore(jest): upgrade jest & babel-jest; move ts-jest config into transform
    
    Remove deprecated `globals["ts-jest"]` from `jest.config.js` and add
    `tsconfig: "tsconfig.jest.json"` to the `^.+\.ts$` `transform` entry so
    ts-jest config lives under `transform` (per ts-jest deprecation notice).
    
    Bump devDependencies:
    - `babel-jest`: ^30.3.0 → ^30.4.1
    - `jest`: ^30.3.0 → ^30.4.2
    
    Also add `yarn-clean` CLI entry to `package.json`.
- [ _2026-05-14 05:40:35_ ] [88c6098](<https://github.com/dimaslanjaka/bin/commit/88c6098>) feat(yarn): enable global cache for improved performance
- [ _2026-05-14 05:44:56_ ] [ec85215](<https://github.com/dimaslanjaka/bin/commit/ec85215>) fix(yarn-clean): correct script path to yarn-clean.py for proper execution
- [ _2026-05-14 05:49:15_ ] [b7bd89f](<https://github.com/dimaslanjaka/bin/commit/b7bd89f>)
    
    fix(tests): standardize quotes in validate-tarball.test.cjs for consistency
    fix(eslint): The value assigned to 'URL_WITH_TOKEN' is not used in subsequent statements.
    
    Co-authored-by: Copilot <copilot@github.com>
- [ _2026-05-14 05:50:06_ ] [f9d968d](<https://github.com/dimaslanjaka/bin/commit/f9d968d>) feat(requirements): add requirements.txt for Python dependencies
- [ _2026-05-14 05:50:43_ ] [568e314](<https://github.com/dimaslanjaka/bin/commit/568e314>) fix(workflow): remove scheduled trigger from clean-logs.yml
- [ _2026-05-14 08:23:37_ ] [a3b1aaf](<https://github.com/dimaslanjaka/bin/commit/a3b1aaf>) feat(scripts): add cross-platform Python environment setup scripts
- [ _2026-05-14 08:26:31_ ] [8104758](<https://github.com/dimaslanjaka/bin/commit/8104758>)
    
    feat(yarn-clean): add multi-location script resolution and improve robustness
    
    - Add fallback lookup for yarn-clean.py in bin/ and binaries/ directories
    - Introduce CANDIDATES array (bash) / variables (cmd) for script resolution
    - Select first existing script path automatically
    - Add explicit error handling when no candidate script is found
    - Improve bash safety with set -euo pipefail
    - Improve Windows batch script with delayed expansion and clearer flow
    - Print resolved script path before execution
    - Preserve argument forwarding to Python script
- [ _2026-05-14 18:50:49_ ] [3171488](<https://github.com/dimaslanjaka/bin/commit/3171488>)
    
    feat: add logging for command execution status on error
    
    Log the result of the command if the status is not zero.
- [ _2026-05-15 09:22:28_ ] [6d44692](<https://github.com/dimaslanjaka/bin/commit/6d44692>) feat: enable dotenv override for environment configuration
- [ _2026-05-15 09:24:32_ ] [636771e](<https://github.com/dimaslanjaka/bin/commit/636771e>)
    
    fix: update import statement for findEnvFiles to include file extension
    
    Co-authored-by: Copilot <copilot@github.com>
- [ _2026-05-15 09:36:29_ ] [1e7087a](<https://github.com/dimaslanjaka/bin/commit/1e7087a>) fix: update token usage to fallback on GITHUB_TOKEN in workflows
- [ _2026-05-15 09:51:20_ ] [d57131b](<https://github.com/dimaslanjaka/bin/commit/d57131b>)
    
    refactor(package-resolutions-updater): use parseGitHubUrl from git-command-helper
    
    Remove duplicate parseGitHubUrl implementation and replace with import from
    git-command-helper package. This eliminates code duplication and ensures a
    single source of truth for URL parsing logic across the codebase.
    
    The function is re-exported for backward compatibility with existing imports.
    
    Co-authored-by: Copilot <copilot@github.com>
- [ _2026-05-15 09:52:46_ ] [7ec70f6](<https://github.com/dimaslanjaka/bin/commit/7ec70f6>)
    
    chore(deps): update git-command-helper and sbg-utility package sources
    
    - bump package version to 2.0.11
    - replace git-command-helper dependency with pre-release tarball URL
    - update git-command-helper resolution commit reference
    - update sbg-utility resolution commit reference
- [ _2026-05-15 10:16:36_ ] [ec38107](<https://github.com/dimaslanjaka/bin/commit/ec38107>)
    
    chore(test): add cross-platform Jest wrappers for CJS test execution
    
    - add `test-cjs` bash script for forwarding Jest arguments
    - add `test-cjs.cmd` Windows batch equivalent
    - update VS Code Code Runner config for `.test.cjs` files
    - separate `.cjs` test handling from existing JS/TS test pattern
- [ _2026-05-15 10:17:11_ ] [3c79832](<https://github.com/dimaslanjaka/bin/commit/3c79832>) fix: update terminal environment variables for cross-platform compatibility
- [ _2026-05-15 10:21:33_ ] [2423251](<https://github.com/dimaslanjaka/bin/commit/2423251>)
    
    refactor(test): extract validate tarball helpers into utility module
    
    Move shared validate-tarball helper logic into a dedicated
    `validate-tarball-utils.cjs` file to improve test organization
    and reduce duplication.
    
    - extract installation preparation logic into utility module
    - extract bin link validation helper into reusable function
    - centralize shared constants and lock file paths
    - import utilities into validate-tarball test file
    - simplify test setup and improve maintainability
    
    Co-authored-by: Copilot <copilot@github.com>
- [ _2026-05-15 10:22:35_ ] [dcc8fb7](<https://github.com/dimaslanjaka/bin/commit/dcc8fb7>) fix: rename test-fail script to test-cjs for clarity
- [ _2026-05-15 10:25:53_ ] [09be3e3](<https://github.com/dimaslanjaka/bin/commit/09be3e3>) chore(build): add custom bins to PATH for improved script execution
- [ _2026-05-15 10:40:37_ ] [fc3abe5](<https://github.com/dimaslanjaka/bin/commit/fc3abe5>)
    
    test: split tarball validation tests for npm and yarn
    
    - add dedicated npm tarball validation test suite
    - rename existing tarball test file to yarn-specific test
    - verify binary commands and proxy execution after npm install
    - keep package manager test flows isolated for better maintainability
- [ _2026-05-15 10:45:37_ ] [e8429fb](<https://github.com/dimaslanjaka/bin/commit/e8429fb>) refactor(ci): drop cleaning caches workflow
- [ _2026-05-15 10:53:06_ ] [6f1bdb9](<https://github.com/dimaslanjaka/bin/commit/6f1bdb9>)
    
    docs(readme): improve installation examples and markdown formatting
    
    - add `-y` flag to NPX usage example
    - rename "VS Code Setup" section to "VSCode Setup"
    - simplify markdown table spacing for cleaner formatting
- [ _2026-05-15 10:55:43_ ] [96f0eed](<https://github.com/dimaslanjaka/bin/commit/96f0eed>) docs(readme): reorganize and enhance binary list generation section
- [ _2026-05-15 10:59:09_ ] [9155bfa](<https://github.com/dimaslanjaka/bin/commit/9155bfa>) refactor(main): remove debug log for parsed arguments
- [ _2026-05-15 11:04:32_ ] [eee1f03](<https://github.com/dimaslanjaka/bin/commit/eee1f03>)
    
    refactor(config): move config file into binary-collections directory
    
    - relocate `binary-collections-config.cjs` to `binary-collections/config.cjs`
    - update import path in `git-diff.js`
    - add commented debug log for script lookup
- [ _2026-05-15 11:17:24_ ] [a42160c](<https://github.com/dimaslanjaka/bin/commit/a42160c>)
    
    refactor(findScript): move findScript implementation to a separate file
    
    Co-authored-by: Copilot <copilot@github.com>
- [ _2026-05-15 11:44:52_ ] [3b9def7](<https://github.com/dimaslanjaka/bin/commit/3b9def7>) refactor(binary-collections): extract executeScript function into dedicated module
- [ _2026-05-15 12:11:37_ ] [2d47767](<https://github.com/dimaslanjaka/bin/commit/2d47767>) refactor(findScript): add additional search path for script files
- [ _2026-05-15 12:29:09_ ] [e0dc5f7](<https://github.com/dimaslanjaka/bin/commit/e0dc5f7>)
    
    feat: add 'list' command to display available binary scripts
    
    - Add listScript utility to locate and verify binaries in package.json
    - Search multiple directories to find script files
    - Update CLI to handle the 'list' argument and print script paths
- [ _2026-05-15 12:34:35_ ] [59dc2fc](<https://github.com/dimaslanjaka/bin/commit/59dc2fc>)
    
    docs(readme): restructure content and improve descriptions
    
    - Reorganize installation methods into distinct options.
    - Enhance VSCode integration section title and instructions.
    - Improve Git Fix utility documentation structure.
    - Standardize formatting for tables, lists, and code blocks.
    - Add visual separators for better readability.
- [ _2026-05-15 13:57:10_ ] [023cb03](<https://github.com/dimaslanjaka/bin/commit/023cb03>) fix(package.json): update resolutions for git-command-helper and sbg-utility
- [ _2026-05-15 13:57:34_ ] [5400280](<https://github.com/dimaslanjaka/bin/commit/5400280>) fix: ensure newline at end of file in package.json and update subproject commit for git-command-helper
- [ _2026-05-15 14:01:01_ ] [cde668d](<https://github.com/dimaslanjaka/bin/commit/cde668d>)
    
    Add PUPPETEER_SKIP_DOWNLOAD to terminal env settings
    
    Added PUPPETEER_SKIP_DOWNLOAD environment variable to terminal configuration.
- [ _2026-05-15 14:02:23_ ] [c29a3db](<https://github.com/dimaslanjaka/bin/commit/c29a3db>) Add Short Command Prompt configuration to readme
- [ _2026-05-15 14:15:19_ ] [3bd5d97](<https://github.com/dimaslanjaka/bin/commit/3bd5d97>) Add Short PowerShell and update Command Prompt args
- [ _2026-05-15 14:16:46_ ] [777e516](<https://github.com/dimaslanjaka/bin/commit/777e516>) Update PATH environment variable in readme.md
- [ _2026-05-17 12:09:06_ ] [18568d9](<https://github.com/dimaslanjaka/bin/commit/18568d9>) feat: add support for .test.mjs files in code-runner executorMap
- [ _2026-05-17 12:11:19_ ] [ff64c38](<https://github.com/dimaslanjaka/bin/commit/ff64c38>)
    
    fix(package-resolutions-updater): support raw.githubusercontent.com URLs in hash replacement
    
    Update replaceRawWithLatestHash to accept both raw GitHub URL formats and preserve the original host when rebuilding the URL.
    
    Add a focused test for raw.githubusercontent.com tarball URLs.
- [ _2026-05-17 12:16:23_ ] [e8cfb82](<https://github.com/dimaslanjaka/bin/commit/e8cfb82>) ci(test): add --ci flag for GitHub Actions and GitLab CI environments
- [ _2026-05-17 12:19:48_ ] [41bf4d4](<https://github.com/dimaslanjaka/bin/commit/41bf4d4>)
    
    feat(test): add cross-platform ESM Jest runners with CI support
    
    - add bash and CMD scripts for Jest ESM execution
    - enable automatic `--ci` detection for GitHub Actions and GitLab CI
    - use `npx -y` to skip interactive install confirmation prompts
    - update VS Code `.test.mjs` runner to use `test-mjs`
- [ _2026-05-18 02:05:31_ ] [1a19fd0](<https://github.com/dimaslanjaka/bin/commit/1a19fd0>) feat(package): add ESM test script to package.json
- [ _2026-05-18 02:06:09_ ] [acb00dc](<https://github.com/dimaslanjaka/bin/commit/acb00dc>)
    
    fix(cli): change missing submodule path handling to warning
    
    - Downgrade missing path from error to warning message
    - Prevent process exit when submodule path does not exist
    - Allow deinitialization and cleanup steps to continue execution
- [ _2026-05-18 02:59:25_ ] [5eb91ab](<https://github.com/dimaslanjaka/bin/commit/5eb91ab>)
    
    chore(submodule): skip processing when .gitmodules is missing or empty
    
    Add a guard check to ensure .gitmodules exists and is not empty before proceeding with submodule installation. If the file is missing or empty, log a message and exit early to prevent downstream git errors.
- [ _2026-05-18 03:00:47_ ] [6639b2e](<https://github.com/dimaslanjaka/bin/commit/6639b2e>)
    
    fix(submodule): handle missing and empty .gitmodules per module safely
    
    Split the .gitmodules validation into separate checks for existence and empty file content. Instead of exiting the process, skip processing per module using continue, and improve log messages to include the module path for better debugging clarity.
- [ _2026-05-18 03:24:12_ ] [c83ab41](<https://github.com/dimaslanjaka/bin/commit/c83ab41>)
    
    refactor(submodule-install): harden submodule processing and improve git error handling
    
    Introduce robust validation for .gitmodules at both root and submodule levels, preventing unsafe git config execution when files are missing or empty. Improve error handling for git operations, normalize branch fallback logic, and enhance recursion safety and logging clarity.
    
    Key improvements include safer submodule discovery, explicit handling of invalid or missing .gitmodules, better fallback for branch resolution, and improved recursive execution flow control.
- [ _2026-05-18 04:46:05_ ] [b217ce0](<https://github.com/dimaslanjaka/bin/commit/b217ce0>) feat(git-diff): enhance output messages with color for better visibility
- [ _2026-05-18 04:46:11_ ] [5c1ad1b](<https://github.com/dimaslanjaka/bin/commit/5c1ad1b>) fix(resolutions): update sbg-utility URL to the latest release
- [ _2026-05-18 13:38:06_ ] [4855fac](<https://github.com/dimaslanjaka/bin/commit/4855fac>)
    
    refactor(env): migrate env discovery utility to CommonJS
    
    - rename findEnvFiles.js to findEnvFiles.cjs
    - convert utility module from ESM to CommonJS
    - add findEnvWithToken helper for token-aware env lookup
    - update dotenv initialization to use dynamic env file detection
    - improve JSDoc coverage and inline type annotations
    - update imports to reference .cjs utility module
- [ _2026-05-18 13:44:46_ ] [ed56ab7](<https://github.com/dimaslanjaka/bin/commit/ed56ab7>)
    
    refactor(cache-cleaner): split CLI entrypoint from cache utility module
    
    - add dedicated clean-github-actions-caches-cli entrypoint
    - export cache utility functions from reusable module
    - update workflow and bin mappings to use CLI wrapper
    - add minimist-based CLI argument parsing and help output
    - improve JSDoc coverage and code formatting consistency
    - update documentation for cache retention behavior
    - refresh sbg-utility dependency resolution
- [ _2026-05-18 13:52:17_ ] [019fcac](<https://github.com/dimaslanjaka/bin/commit/019fcac>)
    
    docs(clean-github-actions-caches): refine CLI help text and add aliases
    
    - Update `src/clean-github-actions-caches.cjs` `printHelp()` to:
      - Use title "GitHub Actions Cache Cleaner"
      - Add a short description, behavior & safety notes, clearer env var notes, improved repo inference guidance, and expanded examples (npx/yarn dlx).
    - Update `docs-src/clean-github-actions-caches.md` to add an "Aliases" section listing:
      - clean-github-actions-cache
      - clear-github-actions-cache
      - clear-github-actions-caches
      - clear-gh-caches
- [ _2026-05-19 08:22:21_ ] [c920b04](<https://github.com/dimaslanjaka/bin/commit/c920b04>)
    
    feat(rm-node-modules): add parallel node_modules cleanup CLI with bash executor
    
    - Add new rm-node-modules CLI command with minimist support (-h/--help)
    - Introduce bash-based parallel node_modules cleanup script (rm-node-modules.cjs)
    - Execute cleanup via runBash utility with cross-platform spawn handling
    - Add Windows support fallback for Git Bash/WSL PATH detection
    - Register new CLI aliases in build.exports (rm-node-modules, remove-node-modules variants)
    - Update README with usage examples and documentation for large-project cleanup tool
    - Improve error handling and cleanup logic for temporary script files
- [ _2026-05-19 08:26:41_ ] [95a5c5e](<https://github.com/dimaslanjaka/bin/commit/95a5c5e>)
    
    refactor(rm-node-modules-cli): improve cleanup flow with explicit function and safer error handling
    
    - Extract main execution into cleanUp(rootDir) function for better testability
    - Pass rootDir explicitly instead of relying on process.cwd() inside function scope
    - Replace promise chain (.catch/.finally) with async/await try/catch/finally structure
    - Improve error handling by rethrowing execution errors after logging
    - Add safer filesystem cleanup with per-file try/catch to avoid masking original errors
    - Enhance logging for temporary script removal failures
    - Change entrypoint to cleanUp(process.cwd()) for clearer control flow
- [ _2026-05-19 09:41:39_ ] [844ec18](<https://github.com/dimaslanjaka/bin/commit/844ec18>)
    
    feat(workspaces): add workspace initialization script and configuration
    
    - add init-workspace.cjs to clone and manage git-based workspaces
    - introduce workspace directories handling with safe cleanup of non-git folders
    - add .gitignore entry for /workspaces directory
    - update package.json to support workspace-based monorepo structure
    - add init-workspace npm script for workspace bootstrap
    - add cross-spawn dependency from custom repository
- [ _2026-05-20 06:14:36_ ] [9529f99](<https://github.com/dimaslanjaka/bin/commit/9529f99>)
    
    chore(eslint): migrate to ESLint v9 flat config and modernize lint setup
    
    - migrate from legacy FlatCompat-based config to ESLint v9 flat config
    - switch to eslint config base using @eslint/js recommended rules (:contentReference[oaicite:0]{index=0})
    - integrate typescript-eslint flat config plugin and parser (:contentReference[oaicite:1]{index=1})
    - replace manual Prettier JSON loading and unify with eslint-config-prettier + eslint-plugin-prettier (:contentReference[oaicite:2]{index=2})
    - restructure config into separated TS / JS(CJS) / MJS blocks with explicit languageOptions
    - standardize globals per environment (node, browser, jest, amd)
    - add ESM restriction rule for .mjs (disallow require(), enforce import)
    - simplify ignores (node_modules, dist)
    - remove deprecated @eslint/eslintrc compatibility layer usage
    - pin major toolchain versions (eslint 9, @eslint/js 9, typescript-eslint 8.59.3, prettier 3.8.3)
    - update scripts and add rm-node-module utilities
    - update sbg-utility dependency revision
- [ _2026-05-20 06:31:39_ ] [eb16268](<https://github.com/dimaslanjaka/bin/commit/eb16268>)
    
    docs(readme): document `bc` local development executor
    
    Add a "Test Local Command Executor" note in the Development section describing how to run the bundled executor locally using `bc <commandName>` (use `bin/bc` on Unix/PowerShell or `bin/bc.cmd` on Windows). Clarifies that `bc` mirrors `binary-collections <commandName>` but is intended for development/testing only.
- [ _2026-05-20 07:08:11_ ] [e137444](<https://github.com/dimaslanjaka/bin/commit/e137444>) chore(package): update test scripts and sbg-utility resolution
- [ _2026-05-20 07:08:25_ ] [47bbeee](<https://github.com/dimaslanjaka/bin/commit/47bbeee>) chore(tsconfig): remove downlevelIteration option from compiler options
- [ _2026-05-20 07:08:36_ ] [3748293](<https://github.com/dimaslanjaka/bin/commit/3748293>) chore(tsconfig): add module and moduleResolution options to compilerOptions
- [ _2026-05-20 07:13:53_ ] [324b8fd](<https://github.com/dimaslanjaka/bin/commit/324b8fd>) chore(.gitignore): update yarn.lock entry to match pattern for yarn lock files
- [ _2026-05-20 07:22:46_ ] [b9b1dfa](<https://github.com/dimaslanjaka/bin/commit/b9b1dfa>) chore(rmx): enhance concurrent deletion logic and improve job management
- [ _2026-05-20 07:35:26_ ] [73f0d7b](<https://github.com/dimaslanjaka/bin/commit/73f0d7b>)
    
    chore(deps): update package.json dependencies and ncu exclusions
    
    - expand update:ncu exclusions for jest, eslint, babel, typescript, ts-node, and @yarnpkg/core
    - bump runtime and dev dependency versions
    - remove unused @types/yargs
- [ _2026-05-20 07:45:36_ ] [eecd382](<https://github.com/dimaslanjaka/bin/commit/eecd382>)
    
    Revise readme.md with enhanced features overview
    
    Expanded features section with detailed descriptions and added new headings for clarity.
- [ _2026-05-20 07:47:48_ ] [d388bf1](<https://github.com/dimaslanjaka/bin/commit/d388bf1>)
    
    feat(bin): add Windows wrapper for rmx script
    
    Add `rmx.cmd` to allow invoking the `rmx` bash script on Windows
    environments by locating `bash` from PATH and forwarding arguments.
- [ _2026-05-20 07:49:36_ ] [215dacd](<https://github.com/dimaslanjaka/bin/commit/215dacd>)
    
    feat(bin): add bcc and bcc.cmd wrapper scripts for binary-collections
    
    Introduce cross-platform CLI entry points:
    - `bin/bcc` (bash)
    - `bin/bcc.cmd` (Windows)
    
    Both scripts execute `binary-collections` via npx from the remote release tarball.
- [ _2026-05-20 08:03:46_ ] [76a42dc](<https://github.com/dimaslanjaka/bin/commit/76a42dc>) feat(submodule): add cross-spawn submodule for improved process handling
- [ _2026-05-20 10:05:41_ ] [26f163d](<https://github.com/dimaslanjaka/bin/commit/26f163d>)
    
    chore(scripts): standardize build script names and fix test pattern; remove pinned resolutions
    
    - rename build script aliases to use kebab-case (build:tsup → build-tsup, build:rollup → build-rollup, build:packages → build-packages)
    - update build pipeline command in build script to match renamed tsup script
    - fix test:nrs glob pattern from build:** to build-** for consistency with renamed scripts
    - remove unused yarn resolutions for cross-spawn and git-command-helper dependencies
- [ _2026-05-20 10:06:44_ ] [e243d0d](<https://github.com/dimaslanjaka/bin/commit/e243d0d>)
    
    feat(eslint): split CJS/ESM rules and introduce Babel parser for JS; update dependency sources
    
    - narrow CJS linting scope to only .cjs files for clearer module separation
    - expand ESM strict config to include .js and .mjs files for consistent enforcement
    - introduce @babel/eslint-parser with import assertions plugin for modern ESM support
    - update eslint parserOptions to avoid external Babel config dependency
    - improve config documentation for CJS vs ESM linting modes
    - update git-command-helper and cross-spawn dependency URLs to newer branches/paths
    - add missing Babel ESLint parser and import assertions plugin to devDependencies
- [ _2026-05-20 10:10:21_ ] [cec4d63](<https://github.com/dimaslanjaka/bin/commit/cec4d63>)
    
    refactor(build): replace lodash with native uniq and improve tsup build configuration
    
    - Remove lodash dependency and introduce native Set-based uniq helper
    - Improve external dependency construction with safer Object.keys fallbacks
    - Normalize bundledPackages list for better readability and maintainability
    - Refactor externalDeps pipeline to use explicit concat and deduplication logic
    - Clean up tsup build config formatting and remove redundant comments
    - Simplify switch/case and formatting in outExtension and banner sections
    - Improve code consistency and reduce unnecessary nesting/braces
- [ _2026-05-20 10:14:38_ ] [a8406e7](<https://github.com/dimaslanjaka/bin/commit/a8406e7>) fix(bin): update yarn-clean scripts to use SCRIPT_DIR for Python execution
- [ _2026-05-20 10:18:17_ ] [a8f83c5](<https://github.com/dimaslanjaka/bin/commit/a8f83c5>)
    
    feat(yarn-clean): add ignore rules and improve workspace cleanup logic
    
    - Add IGNORE_DIR_NAMES to exclude common build/cache directories (.git, tmp, dist, build, out, coverage, .cache)
    - Improve os.walk filtering to properly skip ignored directories and .deploy_* folders
    - Refactor directory filtering logic for clarity and maintainability
    - Simplify collect_workspace_dirs return sorting expression
    - Clean up comments and remove redundant documentation
    - Standardize symlink handling comment style
    - Keep node_modules and yarn.lock cleanup logic unchanged at behavior level
    - Add section headers for better code organization (IGNORE RULES, CLEAN FUNCTION, WORKSPACE COLLECTOR, MAIN)
- [ _2026-05-20 10:25:30_ ] [a4c1d41](<https://github.com/dimaslanjaka/bin/commit/a4c1d41>) feat(build): add submodule checkout and installation step in workflow
- [ _2026-05-20 10:27:44_ ] [1396c12](<https://github.com/dimaslanjaka/bin/commit/1396c12>) feat(build): add dist directory to cache path
- [ _2026-05-20 10:33:09_ ] [ddf5e54](<https://github.com/dimaslanjaka/bin/commit/ddf5e54>) feat(build): update submodule checkout to use specific package repositories
- [ _2026-05-20 10:35:41_ ] [e5617fb](<https://github.com/dimaslanjaka/bin/commit/e5617fb>) feat(vscode): update PATH to include binaries directory for improved accessibility
- [ _2026-05-20 10:35:51_ ] [ab97a63](<https://github.com/dimaslanjaka/bin/commit/ab97a63>) feat(dependencies): update cross-spawn and add git-command-helper with specific package URLs
- [ _2026-05-20 10:37:59_ ] [7fabe28](<https://github.com/dimaslanjaka/bin/commit/7fabe28>) feat(scripts): update build process to include build-exports and remove postbuild step
- [ _2026-05-20 10:38:38_ ] [5426cd1](<https://github.com/dimaslanjaka/bin/commit/5426cd1>) fix(tests): update test script names for consistency and clarity
- [ _2026-05-20 10:39:25_ ] [65e8768](<https://github.com/dimaslanjaka/bin/commit/65e8768>) feat(build): update checkout steps to specify branches for git-command-helper and test-repo
- [ _2026-05-20 10:41:16_ ] [0fb9223](<https://github.com/dimaslanjaka/bin/commit/0fb9223>) fix(ci): branch names
- [ _2026-05-20 10:50:22_ ] [89c16fa](<https://github.com/dimaslanjaka/bin/commit/89c16fa>)
    
    ci: use test branch for repository checkout and git clone single branch
    
    - add `ref: test` to workflow repository checkout step
    - update git clone to use `--single-branch --branch test` in test environment setup
- [ _2026-05-20 11:08:29_ ] [9bcea65](<https://github.com/dimaslanjaka/bin/commit/9bcea65>)
    
    refactor(git-diff): replace fs writeSync with writefile utility and improve cache handling
    
    - Replace fs.writeFileSync calls with writefile from sbg-utility
    - Generate stable cache filenames using md5 of positional args and CLI options
    - Organize output files into git-diff/ and gpt-question/ subdirectories
    - Replace manual directory creation with fs.ensureDirSync (mode 0o755)
    - Remove duplicate ansi-colors import and simplify args initialization scope
- [ _2026-05-20 11:09:25_ ] [ebc0dd0](<https://github.com/dimaslanjaka/bin/commit/ebc0dd0>)
    
    fix(eslint): use babel parser in flat config languageOptions
    
    Update ESLint v9 flat config to properly configure @babel/eslint-parser via languageOptions, fixing parser loader setup and ensuring compatibility with the new flat config format.
- [ _2026-05-20 11:36:00_ ] [3e94730](<https://github.com/dimaslanjaka/bin/commit/3e94730>)
    
    test(env): refactor test environment setup and improve repo/yarn initialization
    
    - normalize `originalCwd` to `path.resolve(__dirname, "..")`
    - introduce `ensureRepoExists()` helper for cloning test repo
    - refactor `ensureYarnProject()` for clearer flow and early returns
    - standardize lockfile backup path (`yarn-lock.bak`)
    - add automatic override of `package.json` dependencies and devDependencies
    - improve error messages and simplify spawn result checks
    - move `TGZ_PATH` definition inside `installYarnPackage()` and improve missing-file error message
    
    BREAKING CHANGE (tests):
    - test repo initialization logic changed (repo creation now requires `ensureRepoExists()`)
    - `package.json` is now automatically rewritten with fixed dependencies during setup
    - yarn lock backup filename changed from `yarn.lock.bak` to `yarn-lock.bak`
- [ _2026-05-20 12:03:14_ ] [c33bea1](<https://github.com/dimaslanjaka/bin/commit/c33bea1>)
    
    feat(git-diff): add unstaged file auto-detection
    
    Add --unstaged/-u support to git-diff, auto-detect file targets between staged and unstaged changes, and expand CLI tests to cover staged, explicit unstaged, and auto-resolved unstaged file cases.
- [ _2026-05-20 12:05:34_ ] [b19e577](<https://github.com/dimaslanjaka/bin/commit/b19e577>)
    
    feat(rm-node-modules): add dry-run mode and workspace support
    
    - Add --force flag to perform actual deletion (default is dry-run mode)
    - Add support for cleaning multiple workspaces via glob patterns
    - Replace custom runBash utility with child_process.spawnSync for better control
    - Add bash execution fallback to fs.rmSync for cross-platform compatibility
    - Improve error handling and output with colored ANSI messages
    - Add comprehensive tests for dry-run, workspace, and real delete modes
    - Update dependencies: upath, fs-extra, glob, ansi-colors
- [ _2026-05-20 12:07:51_ ] [4a566e5](<https://github.com/dimaslanjaka/bin/commit/4a566e5>)
    
    feat(yarn): add per-branch yarn.lock management CLI
    
    - Introduce yarn-per-branch-lock-installer script
    - Add git branch detection and safe branch name normalization
    - Support per-branch lockfile switching (yarn.<branch>.lock)
    - Restore branch-specific yarn.lock before install/up
    - Save updated yarn.lock back to branch-specific lockfile after execution
    - Add support for `--up <packages>` to run `yarn up`
    - Add CLI help system with `-h/--help`
    - Auto-detect Yarn binary across Windows and POSIX systems
    - Improve robustness with explicit process failure handling
    - Provide safe fallback when no branch lock exists (reset or initialize lock state)
- [ _2026-05-20 12:44:17_ ] [b11a2e8](<https://github.com/dimaslanjaka/bin/commit/b11a2e8>)
    
    chore(ci): guard missing bin directories and ensure executable permissions
    
    - refactor PATH setup in GitHub Actions using looped bin directory handling
    - skip non-existent directories to prevent CI failures
    - add binaries directory to PATH discovery
    - ensure generated export files are executable with chmod 755
- [ _2026-05-20 12:45:48_ ] [e83fa71](<https://github.com/dimaslanjaka/bin/commit/e83fa71>) feat(build): add script to fix permissions for PATH bins
- [ _2026-05-20 13:38:56_ ] [9d17e93](<https://github.com/dimaslanjaka/bin/commit/9d17e93>)
    
    test: improve error reporting in yarn tarball validation test
    
    Replace direct throws with console.log + expect assertions in
    validate-tarball-yarn.test.cjs for clearer failure output.
- [ _2026-05-20 13:43:58_ ] [31bd122](<https://github.com/dimaslanjaka/bin/commit/31bd122>) fix(.gitignore): update log file patterns and include .txt files in docs
- [ _2026-05-21 04:59:14_ ] [642d3d2](<https://github.com/dimaslanjaka/bin/commit/642d3d2>) test: enhance error reporting for npm install failures in tarball validation
- [ _2026-05-21 05:03:06_ ] [1385f0c](<https://github.com/dimaslanjaka/bin/commit/1385f0c>) fix(prepareInstallation): clarify comment on directory removal for clean installation
- [ _2026-05-21 05:04:07_ ] [ec9a265](<https://github.com/dimaslanjaka/bin/commit/ec9a265>) fix(cmd-here.bat): enhance cmd window startup with UTF-8 support and additional notes
- [ _2026-05-21 05:22:43_ ] [b753c79](<https://github.com/dimaslanjaka/bin/commit/b753c79>) fix(package.json): update sbg-utility resolution URL to latest version
- [ _2026-05-21 07:52:11_ ] [cbcabb6](<https://github.com/dimaslanjaka/bin/commit/cbcabb6>) fix(jest.config.js): update modulePathIgnorePatterns to include lib and releases directories
- [ _2026-05-21 12:03:22_ ] [da6d2d1](<https://github.com/dimaslanjaka/bin/commit/da6d2d1>)
    
    refactor(test): generalize tarball installation for npm and yarn
    
    - Replace installYarnPackage with installTarball
    - Add support for multiple package managers (yarn, npm)
    - Introduce package manager selection mapping
    - Improve spawnSync error handling and output capture
    - Replace stdio: inherit with pipe for better error diagnostics
    - Validate unsupported package managers with explicit error
    - Update test setup to use installTarball instead of yarn-specific installer
- [ _2026-05-21 12:06:04_ ] [20ba11e](<https://github.com/dimaslanjaka/bin/commit/20ba11e>)
    
    refactor(test/env): consolidate spawn logic and improve repo/test utilities
    
    - Introduce shared `run()` wrapper for spawnSync to reduce duplication
    - Standardize error handling for all external commands (git, yarn, npm)
    - Replace manual mkdirSync with fs.ensureDirSync for nonGitDir setup
    - Remove unsafe process.cwd override and replace with getCwd helper
    - Simplify module exports into a single consolidated export object
    - Refactor ensureRepoExists to use shared runner and early return pattern
    - Refactor ensureYarnProject using fs-extra JSON helpers (readJSON/writeJSON)
    - Improve package.json mutation logic readability and safety
    - Normalize package manager mapping in installTarball (tuple-based)
    - Reduce repeated spawnSync boilerplate across functions
    - Improve error messages for failed external commands
- [ _2026-05-21 12:07:52_ ] [9bd5af5](<https://github.com/dimaslanjaka/bin/commit/9bd5af5>) fix(package.json): update sbg-utility resolution URL to latest version
- [ _2026-05-21 12:24:20_ ] [2496f6f](<https://github.com/dimaslanjaka/bin/commit/2496f6f>) fix(package.json): add resolution for @types/through2
- [ _2026-05-21 12:39:46_ ] [e53c647](<https://github.com/dimaslanjaka/bin/commit/e53c647>)
    
    test(validate-tarball): refactor installation flow and extract shared utilities
    
    - extract `buildAndPack` and `validateBinaries` into shared utils
    - simplify cleanup logic in `beforeAll` using clearer loop structures
    - centralize repository initialization via `ensureRepoExists`
    - unify npm and yarn test flow to reduce duplication
    - improve install error logging for npm and yarn commands
    - enhance `prepareInstallation` with consistent environment setup
    - remove duplicated inline `validateBinaries` implementations from tests
- [ _2026-05-21 12:40:11_ ] [1754a97](<https://github.com/dimaslanjaka/bin/commit/1754a97>)
    
    feat(git-diff): add OpenCode CLI prompt output
    
    - print OpenCode prompt message after diff generation
    - include formatted instruction referencing DIFF_OUTPUT file
    - improve CLI usability for generating conventional commit prompts
- [ _2026-05-21 12:46:59_ ] [b9fc6d4](<https://github.com/dimaslanjaka/bin/commit/b9fc6d4>)
    
    fix(cli): avoid execa in npm-run-series
    
    Replace execa with child_process.spawnSync so the series runner no longer depends on the workspace cross-spawn package shape.
    Remove execa from package.json.
- [ _2026-05-21 12:49:09_ ] [d25ffe9](<https://github.com/dimaslanjaka/bin/commit/d25ffe9>) feat(bin): add yarn-install binary mapping to defaultBin
- [ _2026-05-21 12:49:36_ ] [1f49e3a](<https://github.com/dimaslanjaka/bin/commit/1f49e3a>) feat(bin): add y-install binary mapping to defaultBin
- [ _2026-05-21 12:51:12_ ] [8daa60b](<https://github.com/dimaslanjaka/bin/commit/8daa60b>) feat(bin): add y-install and yarn-install scripts for branch-specific installations
- [ _2026-05-21 12:53:30_ ] [027a0b7](<https://github.com/dimaslanjaka/bin/commit/027a0b7>)
    
    refactor(cli): simplify yarn branch lock sync workflow
    
    - simplify branch-safe name replacement regex
    - remove redundant helper functions and comments
    - simplify yarn argument handling
    - replace empty yarn.lock reset with file removal
    - inline lockfile copy operations
    - reduce temporary variables and branching logic
    - improve logging consistency
    - use process.exitCode for yarn process result handling
    - simplify help usage examples and CLI parsing
- [ _2026-05-21 12:59:03_ ] [59d105a](<https://github.com/dimaslanjaka/bin/commit/59d105a>) fix(tests): enable overwrite when moving lock files in tarball validation tests
- [ _2026-05-21 13:03:57_ ] [171884f](<https://github.com/dimaslanjaka/bin/commit/171884f>)
    
    test(validate-tarball): remove unused lockfile imports and cleanup test setup
    
    Removed unused named imports (`npmLockFile`, `yarnLockFile`, `npmLockFileBackup`, `yarnLockFileBackup`)
    from `test/validate-tarball-npm.test.cjs` and `test/validate-tarball-yarn.test.cjs`.
    Also removed the lockfile backup/move logic and the creation of an empty `yarn.lock` in the yarn test.
    This simplifies the test setup without changing test behavior.
- [ _2026-05-21 13:06:42_ ] [25b86a2](<https://github.com/dimaslanjaka/bin/commit/25b86a2>) fix(settings): update test executor for .test.mjs files to use test-esm
- [ _2026-05-21 13:08:07_ ] [303d476](<https://github.com/dimaslanjaka/bin/commit/303d476>) fix(tests): update test commands to use bash scripts for CJS and ESM tests
- [ _2026-05-21 13:19:14_ ] [b18e228](<https://github.com/dimaslanjaka/bin/commit/b18e228>)
    
    fix(test): enable shell on win32 and fix yarn tarball syntax
    
    Enable shell mode conditionally on Windows for spawnSync to
    resolve commands correctly. Prefix the yarn tarball path with
    "binary-collections@file:" for proper package installation.
- [ _2026-05-21 13:25:45_ ] [470a49c](<https://github.com/dimaslanjaka/bin/commit/470a49c>)
    
    feat(git-diff): add diff existence tracking for OpenCode prompt output
    
    - return boolean status from runGitDiff()
    - skip OpenCode prompt helper when no diff changes exist
    - improve JSDoc with return description
    - enhance OpenCode prompt formatting for better CLI readability
- [ _2026-05-21 13:28:56_ ] [593d974](<https://github.com/dimaslanjaka/bin/commit/593d974>) fix(build): exclude test directory from cache paths
- [ _2026-05-21 13:31:51_ ] [43334fe](<https://github.com/dimaslanjaka/bin/commit/43334fe>)
    
    ci(github-actions): separate build and test workflows
    
    - split CI into dedicated build and test jobs
    - upload build artifacts for reuse across jobs
    - download artifacts in test workflow before running tests
    - remove duplicated PATH permission fix step from build job
    - add job dependency using needs: build
    - clean up workflow formatting and comments
- [ _2026-05-21 13:43:35_ ] [d31a12c](<https://github.com/dimaslanjaka/bin/commit/d31a12c>) feat: restore cache cleaner
- [ _2026-05-21 13:44:10_ ] [325d00a](<https://github.com/dimaslanjaka/bin/commit/325d00a>)
    
    ci(github-actions): split build and test workflows
    
    - separate test pipeline into dedicated test.yml workflow
    - keep build workflow focused on build and packaging tasks
    - remove artifact upload/download workflow dependency
    - preserve repository checkout, cache, and PATH setup steps in both workflows
    - add independent concurrency groups for build and test workflows
    - improve CI isolation and maintainability
- [ _2026-05-21 13:46:20_ ] [6631e48](<https://github.com/dimaslanjaka/bin/commit/6631e48>)
    
    ci(workflows): run test workflow after build workflow completion
    
    Switch test workflow trigger from push to workflow_run for "Node.js Package Build" completion, and run tests only when the build concludes successfully.
- [ _2026-05-21 13:50:26_ ] [b4469be](<https://github.com/dimaslanjaka/bin/commit/b4469be>)
    
    ci(workflows): trigger cache cleanup after build or test workflow completion
    
    Replace clean-caches workflow push trigger with workflow_run and run it when either "Node.js Package Build" or "Node.js Package Test" completes.
- [ _2026-05-21 13:51:34_ ] [8492357](<https://github.com/dimaslanjaka/bin/commit/8492357>) fix(workflows): update test job name to include workflow run SHA
- [ _2026-05-21 13:52:46_ ] [9557295](<https://github.com/dimaslanjaka/bin/commit/9557295>) ci(workflows): remove scheduled trigger from clean cache workflow
- [ _2026-05-21 13:57:00_ ] [a44a6f1](<https://github.com/dimaslanjaka/bin/commit/a44a6f1>)
    
    ci(clean-caches): restore submodule update step and simplify cache setup
    
    - replace `actions/cache/restore@v5` with `actions/cache@v5`
    - re-enable submodule initialization and sync workflow step
    - use `npx -y` commands for rimraf and binary-collections execution
    - remove obsolete commented submodule setup block
- [ _2026-05-21 13:58:28_ ] [1167bdb](<https://github.com/dimaslanjaka/bin/commit/1167bdb>) fix(workflows): truncate head SHA in test job name for better readability
- [ _2026-05-21 13:59:06_ ] [0f74860](<https://github.com/dimaslanjaka/bin/commit/0f74860>) fix(workflows): add clean-caches.yml to paths-ignore for build workflow
- [ _2026-05-21 13:59:37_ ] [ac1b595](<https://github.com/dimaslanjaka/bin/commit/ac1b595>) fix(package.json): update resolutions for @types/through2 and cross-spawn
- [ _2026-05-21 14:01:10_ ] [7d9d81d](<https://github.com/dimaslanjaka/bin/commit/7d9d81d>) fix(ci): invalid syntax
- [ _2026-05-21 14:02:15_ ] [2411f24](<https://github.com/dimaslanjaka/bin/commit/2411f24>) chore(workflows): add concurrency settings to clean-caches.yml
- [ _2026-05-21 14:05:07_ ] [5e826a3](<https://github.com/dimaslanjaka/bin/commit/5e826a3>)
    
    style(ci): improve workflow step naming and formatting in clean-caches workflow
    
    - add descriptive emoji-based step names
    - improve workflow readability with spacing adjustments
    - simplify NODE_OPTIONS comment
    - normalize Nuitka cache path formatting
    - include workflow_run head SHA in cache cleanup step name
- [ _2026-05-21 14:06:57_ ] [d0aaac1](<https://github.com/dimaslanjaka/bin/commit/d0aaac1>)
    
    ci(workflows): add Python environment setup to build and test pipelines
    
    - add Python setup using actions/setup-python
    - create and initialize virtual environments
    - install Python dependencies from requirements files
    - cache Python virtualenv and bytecode artifacts
    - include requirements files in cache keys
    - remove redundant workflow file header comments
- [ _2026-05-21 14:09:12_ ] [8507c30](<https://github.com/dimaslanjaka/bin/commit/8507c30>) chore(workflows): update cache paths
- [ _2026-05-21 14:10:12_ ] [e6b13af](<https://github.com/dimaslanjaka/bin/commit/e6b13af>) chore(workflows): remove unnecessary cache paths from build and test workflows
- [ _2026-05-21 14:13:02_ ] [cc7ed84](<https://github.com/dimaslanjaka/bin/commit/cc7ed84>) chore(workflows): enhance cache key to include all relevant files for better cache management
- [ _2026-05-21 14:14:29_ ] [03281b6](<https://github.com/dimaslanjaka/bin/commit/03281b6>) chore: remove deprecated TypeDoc scripts and configuration files
- [ _2026-05-21 14:29:35_ ] [6d0f888](<https://github.com/dimaslanjaka/bin/commit/6d0f888>)
    
    refactor(build): extract binary mapping generator into shared config module
    
    - move default binary mappings to build.config.cjs
    - extract bin mapping generation into reusable generateMapping()
    - simplify build.exports.mjs by reusing shared config
    - add validation and warning logs for missing/conflicting binaries
    - normalize generated paths using upath.toUnix()
    - write generated bin mapping to tmp/bin-mapping.json for debugging
- [ _2026-05-21 14:30:49_ ] [a4183d7](<https://github.com/dimaslanjaka/bin/commit/a4183d7>) chore(scripts): reorganize build scripts and remove duplicate entry
- [ _2026-05-21 14:32:52_ ] [440175a](<https://github.com/dimaslanjaka/bin/commit/440175a>) chore: remove deprecated TypeDoc and related plugin dependencies
- [ _2026-05-21 14:39:46_ ] [f3fdb8e](<https://github.com/dimaslanjaka/bin/commit/f3fdb8e>) chore: remove unused 'remove' dependency from package.json
- [ _2026-05-21 15:10:27_ ] [d340f38](<https://github.com/dimaslanjaka/bin/commit/d340f38>)
    
    refactor(resolutions): extract resolution update logic into reusable testable function
    
    - move package resolution processing into resolvePackageResolutionUpdates
    - simplify CLI by delegating update workflow to shared resolver
    - add URL accessibility validation using axios HEAD requests
    - prevent updating package resolutions to inaccessible GitHub URLs
    - improve skipped and failed update handling structure
    - add integration test for real GitHub resolution update scenario
    - clean up formatting and unused commented override entries
- [ _2026-05-21 15:12:04_ ] [86fb67e](<https://github.com/dimaslanjaka/bin/commit/86fb67e>) fix(resolutions): update @types/through2 resolution to use branch reference
- [ _2026-05-21 15:13:38_ ] [6b2b60c](<https://github.com/dimaslanjaka/bin/commit/6b2b60c>)
    
    fix(build): replace arguments.callee usage in generateMapping logs
    
    Use generateMapping.name via a local fnName constant for log prefixes.
    This avoids strict mode runtime errors when build-exports runs under Node ESM.
- [ _2026-05-21 15:17:45_ ] [8ce4be4](<https://github.com/dimaslanjaka/bin/commit/8ce4be4>) refactor(logging): enhance script execution and resolution processing logs
- [ _2026-05-22 13:19:08_ ] [6e5ac0c](<https://github.com/dimaslanjaka/bin/commit/6e5ac0c>)
    
    feat(cli): add copy and move file command utilities
    
    - add copy and move helper functions using fs-extra
    - add CLI commands for copy and move operations
    - support aliases: copy-file, move-file, node-copy, and node-move
    - add --help support and argument validation
    - improve CLI error handling for unexpected exceptions
- [ _2026-05-22 13:20:45_ ] [aa1a468](<https://github.com/dimaslanjaka/bin/commit/aa1a468>)
    
    docs(cli): add documentation for copy and move file commands
    
    - document copy and move CLI usage
    - add command aliases and examples
    - describe available CLI options
    - link related source implementation files
- [ _2026-05-22 13:27:07_ ] [3ec6f89](<https://github.com/dimaslanjaka/bin/commit/3ec6f89>)
    
    chore(package): refine npm package file inclusions
    
    - Remove `docs-src/**/*.md` from published files.
    - Replace `.puppeterrc.*` glob with explicit `.puppeterrc.cjs`.
- [ _2026-05-22 13:30:33_ ] [d77f0e4](<https://github.com/dimaslanjaka/bin/commit/d77f0e4>)
    
    docs: add comprehensive command documentation and reorganize README
    
    - add detailed markdown docs for Git, cleanup, package, process, and utility commands
    - document command usage, options, aliases, examples, and source references
    - introduce centralized "Command Documentation" section in README
    - replace large inline README command descriptions with links to docs-src files
    - improve maintainability and navigation of project documentation
- [ _2026-05-22 16:25:48_ ] [cd55bb8](<https://github.com/dimaslanjaka/bin/commit/cd55bb8>) feat(cli): ensure destination directory exists before copying and moving files
- [ _2026-05-22 18:04:20_ ] [542c2a2](<https://github.com/dimaslanjaka/bin/commit/542c2a2>)
    
    feat(file): support automatic file-to-directory resolution in copy and move CLI
    
    - replace fs.existsSync with async fs.pathExists in copy and move
    - remove invalid path.resolve validation
    - add fs.stat-based source type detection
    - enable file → directory handling using basename(src)
    - normalize destination resolution via finalDest
    - ensure parent directory creation uses resolved destination path
    - update CLI documentation to reflect new behavior and usage examples
    - improve formatting consistency across docs (lists, tables, and references)
- [ _2026-05-23 07:22:37_ ] [f9cb91d](<https://github.com/dimaslanjaka/bin/commit/f9cb91d>)
    
    feat(bin): add parallel node_modules cleanup script
    
    Introduce new `bin/yc` bash utility to clean `node_modules` in parallel by
    removing packages grouped by alphabetical letter. The script limits concurrent
    jobs, waits for all background tasks to finish, and performs a final removal
    of the entire `node_modules` directory after completion.
- [ _2026-05-23 07:43:48_ ] [582bea1](<https://github.com/dimaslanjaka/bin/commit/582bea1>)
    
    chore(deps): add eslint-base-config dependency and update resolutions
    
    - Add `@dimaslanjaka/eslint-base-config` to dependencies and resolutions.
    - Update `git-command-helper` resolution to commit `ed17f70`.
- [ _2026-05-23 07:49:46_ ] [f6304c7](<https://github.com/dimaslanjaka/bin/commit/f6304c7>)
    
    refactor(eslint): replace inline config with shared base package
    
    - Replace custom ESLint configuration with import from `@dimaslanjaka/eslint-base-config`.
    - Remove inline rules for TypeScript, Babel, and Prettier.
    - Simplify `eslint.config.mjs` to extend the base configuration.
- [ _2026-05-23 07:51:33_ ] [6505da8](<https://github.com/dimaslanjaka/bin/commit/6505da8>)
    
    feat(bin): add concurrent node_modules cleanup with logging and failure report
    
    Enhance the `bin/yc` cleanup script with structured logging, failure tracking,
    and improved concurrency control. Introduce timestamped logs, success/failure
    reporting for each deletion, and a summary report at the end of execution.
    
    Refactor cleanup logic to use nullglob-based glob expansion with grouped
    targets per letter, improving safety and clarity. Replace simple sequential
    deletion with a controlled parallel execution model using a job limiter.
    
    Add final aggregated node_modules removal step with explicit logging and error
    tracking, along with a summary section that reports any failed deletions.
- [ _2026-05-24 09:51:33_ ] [77313fc](<https://github.com/dimaslanjaka/bin/commit/77313fc>) feat: cross-env source code
- [ _2026-05-24 10:13:49_ ] [c90de35](<https://github.com/dimaslanjaka/bin/commit/c90de35>) refactor: eslint --fix
- [ _2026-05-24 10:27:40_ ] [b917723](<https://github.com/dimaslanjaka/bin/commit/b917723>) feat: add documentation creation agent for binary-collections project
- [ _2026-05-24 10:29:48_ ] [8093182](<https://github.com/dimaslanjaka/bin/commit/8093182>)
    
    feat(cli): add node-executor command with multi-language runtime dispatch
    
    - Add new `node-executor` CLI script for executing files based on extension
    - Support PHP, Node.js, Python, Ruby, Bash, and CMD execution
    - Add CLI aliases: `node-exec`, `exec-node`, `execute-node`, `node-executor`
    - Register CLI commands in package.json bin entries
    - Add full documentation for node-executor usage and supported extensions
    - Improve CLI help output with usage, options, and examples
    - Ensure configurable exit code behavior for missing/invalid files
- [ _2026-05-24 11:00:15_ ] [49fec8a](<https://github.com/dimaslanjaka/bin/commit/49fec8a>)
    
    refactor(node-executor): extract safe exit code handler and improve CLI structure
    
    - add getExitCode helper to correctly parse --exit-code (fixes 0 fallback bug)
    - replace inline exit code logic with reusable function
    - improve code readability by grouping sections with clear comments
    - fix help text formatting consistency
    
    test(node-executor): add CLI integration test suite
    
    - add Jest-based integration tests for CLI execution
    - test help output, missing file handling, and unknown extension error
    - test execution of js and python files via spawned processes
    - verify custom exit-code behavior
- [ _2026-05-24 11:08:26_ ] [c9ed9f7](<https://github.com/dimaslanjaka/bin/commit/c9ed9f7>) chore(dependencies): update cross-spawn, git-command-helper, sbg-utility, and eslint-base-config to specific versions
- [ _2026-05-24 11:42:00_ ] [a82c294](<https://github.com/dimaslanjaka/bin/commit/a82c294>)
    
    feat(node-cache-cleaner): add CLI tool with help flag and documentation
    
    - add node-cache-cleaner CLI entry with minimist support for --help/-h
    - introduce CLI usage help output for better user experience
    - register node-cache-cleaner binary in package.json scripts
    - add documentation for node-cache-cleaner usage and behavior
    - implement npm cache cleaner using npm cache clean --force
    - implement yarn cache cleaner with version-aware cache cleaning logic
    - implement npx cache cleaner by removing npm cache, _npx, and related cache directories
    - run all cache cleaning operations in parallel using Promise.allSettled
    - ensure CLI exits with proper status code based on success/failure
- [ _2026-05-25 07:53:07_ ] [9dad882](<https://github.com/dimaslanjaka/bin/commit/9dad882>) feat(devcontainer): add initial devcontainer configuration with PHP, Node, and Python support
- [ _2026-05-25 08:02:59_ ] [11ea4e3](<https://github.com/dimaslanjaka/bin/commit/11ea4e3>) docs(readme): update features section and enhance quick reference with command documentation
- [ _2026-05-25 08:03:13_ ] [de5bc9a](<https://github.com/dimaslanjaka/bin/commit/de5bc9a>) feat(vscode): enhance markdown editor settings with unicode highlights and formatting options
- [ _2026-05-25 08:54:25_ ] [a172440](<https://github.com/dimaslanjaka/bin/commit/a172440>) feat(devcontainer): add Dockerfile and update devcontainer configuration for PHP 8.3, Node 22, and Python 3.11
- [ _2026-05-26 10:12:39_ ] [ddd200d](<https://github.com/dimaslanjaka/bin/commit/ddd200d>)
    
    refactor(clean-node): simplify cleanup logging and add colored console output
    
    - remove log file and failure file generation
    - add colored status logging for OK, FAIL, SKIP, and INFO messages
    - display relative paths instead of absolute paths in logs
    - simplify cleanup summary into direct console output
    - improve final node_modules cleanup reporting
    - export reusable relative path helper for subprocess jobs
- [ _2026-05-26 10:13:02_ ] [0e7f6d1](<https://github.com/dimaslanjaka/bin/commit/0e7f6d1>) fix(dependencies): update @dimaslanjaka/eslint-base-config version to ^1.0.1
- [ _2026-05-26 10:14:28_ ] [2eb9ccc](<https://github.com/dimaslanjaka/bin/commit/2eb9ccc>) fix(git-diff): correct output path for GPT-formatted prompt file
- [ _2026-05-26 10:18:54_ ] [3923ff8](<https://github.com/dimaslanjaka/bin/commit/3923ff8>)
    
    feat(git-diff): persist OpenCode prompts and improve console output formatting
    
    - add saved OpenCode prompt file generation for commit message workflows
    - improve console output readability with colored relative paths
    - replace inline OpenCode prompt display with file-based output
    - enhance GPT diff prompt logging using ansi color formatting
- [ _2026-05-26 10:20:10_ ] [619124f](<https://github.com/dimaslanjaka/bin/commit/619124f>) fix(package): update version to 2.0.12
- [ _2026-05-26 11:10:57_ ] [60af18b](<https://github.com/dimaslanjaka/bin/commit/60af18b>) fix(log): improve log output formatting for better readability
- [ _2026-05-26 11:11:25_ ] [3a9d8ef](<https://github.com/dimaslanjaka/bin/commit/3a9d8ef>)
    
    feat(bin): add workspace-aware node_modules cleanup script
    
    - introduce portable cleanup script without git dependency
    - add automatic monorepo root detection via package.json workspaces
    - implement workspace glob expansion for package.json workspaces field
    - add safe workspace resolution with directory validation
    - deduplicate node_modules targets across root and workspaces
    - implement parallel deletion with configurable concurrency
    - add letter-based segmented cleanup strategy for node_modules pruning
    - improve logging with timestamped colored output
    - support execution from any subdirectory in a monorepo
- [ _2026-05-26 11:15:46_ ] [af8a9e0](<https://github.com/dimaslanjaka/bin/commit/af8a9e0>)
    
    feat(cli): add --help/-h usage output for yc and ycw scripts
    
    - Add usage() function for both yc and ycw commands
    - Implement CLI argument parsing for -h and --help
    - Provide detailed help output including description, behavior, and examples
    - Document max_jobs configuration and parallel execution behavior
    - Improve usability by allowing quick help access without running main logic
- [ _2026-05-26 11:17:29_ ] [93df109](<https://github.com/dimaslanjaka/bin/commit/93df109>)
    
    feat(cli): add --concurrent option and improve argument parsing for yc and ycw
    
    - Add -c/--concurrent flag to control max parallel jobs
    - Replace simple for-loop argument parsing with while/case shift-based parser
    - Allow dynamic configuration of concurrency instead of hardcoded max_jobs=4
    - Improve help output formatting and alignment for readability
    - Update examples to include concurrent usage (-c 8)
    - Clarify cleanup steps in ycw help description
- [ _2026-05-26 11:21:54_ ] [5260f3f](<https://github.com/dimaslanjaka/bin/commit/5260f3f>) docs(docs-src): consolidate yarn cache cleaner docs into node-cache-cleaner.md and remove yarn-clean.md
- [ _2026-05-26 11:22:41_ ] [1c760a5](<https://github.com/dimaslanjaka/bin/commit/1c760a5>) fix(package): replace package.json with docs-src in files array
- [ _2026-05-26 11:28:22_ ] [deb58b4](<https://github.com/dimaslanjaka/bin/commit/deb58b4>)
    
    docs: consolidate cleanup utility docs into node-cache-cleaner
    
    - Merge del-node-modules, del-yarn-caches, and rm-node-modules documentation into node-cache-cleaner.md
    - Remove standalone documentation files
    - Update readme.md links to point to the consolidated node-cache-cleaner.md
- [ _2026-05-26 11:39:40_ ] [f15d5d5](<https://github.com/dimaslanjaka/bin/commit/f15d5d5>)
    
    feat(executor): add shebang parsing and bash fallback
    
    - Parse shebangs to dynamically resolve the interpreter for .sh and extensionless scripts
    - Add fallback to check for `bash` availability if standard platform candidates are not found
    - Normalize string quotes from double to single
    - Add execution logging for debugging
- [ _2026-05-26 11:45:23_ ] [ff08511](<https://github.com/dimaslanjaka/bin/commit/ff08511>)
    
    feat(bin): resolve interpreter using `which` and improve command logging
    
    - Add `which` dependency to resolve interpreter path before execution
    - Fallback to original interpreter if resolution fails
    - Improve execution logging by normalizing absolute paths to relative paths
    - Normalize command arguments in log output for better readability
    - Add new binary alias `ycw` in package.json
- [ _2026-05-26 11:59:19_ ] [c56b073](<https://github.com/dimaslanjaka/bin/commit/c56b073>)
    
    feat(git-diff): improve CLI output formatting, error handling, and add untracked diff support
    
    - standardize console output by removing redundant icons and normalizing log messages
    - improve help output formatting and simplify usage text display
    - replace verbose logging markers with cleaner informational logs (ℹ️, ❌, ✅)
    - refactor GPT prompt generation wording for consistency ("Hello!" instead of "Hello, ChatGPT!")
    - improve error messages for git-related failures and command execution logs
    - add getUntrackedDiff() to generate synthetic diff output for untracked files
    - save untracked file diffs and AI prompts to separate temporary files
    - improve OpenCode and AI prompt saving logs for clarity and consistency
    - minor UX improvements in CLI messaging (tip wording and output confirmations)
- [ _2026-05-26 12:05:28_ ] [e96d686](<https://github.com/dimaslanjaka/bin/commit/e96d686>)
    
    chore(build): rename build.exports.mjs to build.mjs
    
    - Rename build script file to a simpler name
    - Update build-exports script in package.json to reflect the new filename
- [ _2026-05-26 13:22:10_ ] [64d8c2f](<https://github.com/dimaslanjaka/bin/commit/64d8c2f>) docs(readme): remove package-resolutions-updater from other utilities table
- [ _2026-05-26 13:26:44_ ] [a30f1a6](<https://github.com/dimaslanjaka/bin/commit/a30f1a6>) refactor(table-parser): improve JSDoc comments for clarity and consistency
- [ _2026-05-26 13:50:05_ ] [0d31c66](<https://github.com/dimaslanjaka/bin/commit/0d31c66>)
    
    chore(opencode): add JS/TS modification agent
    
    - Define workflow and rules for safely modifying JavaScript and TypeScript code
    - Enforce src/lib separation, strict eslint formatting, and memory logging
- [ _2026-05-26 14:10:30_ ] [34fe110](<https://github.com/dimaslanjaka/bin/commit/34fe110>) chore(opencode): add initial opencode configuration file
- [ _2026-05-26 14:27:10_ ] [786e120](<https://github.com/dimaslanjaka/bin/commit/786e120>) feat(run-by-checksum): add CLI tool to run commands conditionally based on file checksums
- [ _2026-05-26 14:37:23_ ] [075c7bd](<https://github.com/dimaslanjaka/bin/commit/075c7bd>) feat(git-commit-from-diff): add automated conventional commit generation from staged changes
- [ _2026-05-26 16:26:50_ ] [0b53751](<https://github.com/dimaslanjaka/bin/commit/0b53751>) feat(run-by-checksum): add -c/--cwd option for working directory
- [ _2026-05-26 16:31:11_ ] [ade7567](<https://github.com/dimaslanjaka/bin/commit/ade7567>)
    
    chore(opencode): enhance git-commit agent and rename js-ts agent
    
    - Improve git-commit-from-diff workflow structure and commit splitting rules
    - Fix multiline commit execution to use multiple `-m` arguments
    - Add strict validation, style, and safety rules
    - Rename modify-js-ts-agent.md to modify-js-ts.md
- [ _2026-05-26 16:34:53_ ] [49f642c](<https://github.com/dimaslanjaka/bin/commit/49f642c>)
    
    fix(run-by-checksum): only save checksum cache after successful command
    
    Why: - Previously the checksum cache was saved before the command executed, so if the command failed the new checksum was already persisted. On the next invocation the unchanged files would be skipped despite the previous failure. - Now the cache is saved only after runCommand exits successfully (exit code 0). Failed executions retain the old checksum, ensuring the command re-runs on next invocation. Changes: - src/run-by-checksum/run.js: move saveCache() call from before runCommand to after await runCommand(exec, cwd) - docs-src/run-by-checksum.md: update 'How it works' steps 4-6 to describe the new behavior
- [ _2026-05-26 18:25:53_ ] [a643fe5](<https://github.com/dimaslanjaka/bin/commit/a643fe5>)
    
    docs(opencode): enhance js/ts agent instructions and memory format
    
    - Change memory logging format from JSON to Markdown
    - Update memory file path sanitization rules and provide examples
    - Expand formatting rules and add TypeScript validation step
    - Add explicit safety rules section
    - Improve structure with sub-headers and horizontal rules
- [ _2026-05-26 19:04:16_ ] [5aaaafb](<https://github.com/dimaslanjaka/bin/commit/5aaaafb>)
    
    feat(run-by-checksum): add CLI tests and shared CRUD helpers
    
    Why: - Need test coverage for run-by-checksum CLI argument parsing and real spawn execution - Existing tests used raw fs-extra calls duplicated across files - Dry-run test had invalid assertion (expected cache persistence without saving) Changes: - Add debug logging (patterns, ignore, cwd, exec) to CLI - Create shared.mjs CRUD helpers: ensureTestDir, createTestFile, readTestFile, deleteTestFile, updateTestFile, cleanTestRoot - Add mocked CLI test (7 tests) for arg parsing --help error handling via jest.unstable_mockModule - Add real spawn CLI test (8 tests) for help execution idempotency re-execute complex glob mixed args error exits - Refactor runChecksum.test.mjs and runChecksum-dry-run.test.mjs to use shared helpers - Fix dry-run test: changed from invalid two-dry-runs to normal-run-then-dry-run - Add cli-sample.md with reference CLI commands Impact: - All 19 tests across 4 test suites pass - shared.mjs now provides reusable file CRUD for all run-by-checksum tests
- [ _2026-05-27 14:45:21_ ] [674c7c4](<https://github.com/dimaslanjaka/bin/commit/674c7c4>)
    
    refactor(package-resolutions-updater): replace axios HEAD request with fetchResponse utility
    
    - introduce fetchResponse utility to wrap axios.get and return response metadata
    - replace axios.head validation with unified fetchResponse-based request
    - simplify control flow for URL verification and update handling
    - improve error handling by centralizing status validation logic
    - remove direct axios usage from package-resolutions-updater
    
    test(utils): add fetchResponse tests for archive response validation and metadata handling
- [ _2026-05-28 08:26:58_ ] [84a24fb](<https://github.com/dimaslanjaka/bin/commit/84a24fb>) chore: update lint-staged configuration for file patterns
- [ _2026-05-27 14:59:51_ ] [a4835ca](<https://github.com/dimaslanjaka/bin/commit/a4835ca>)
    
    refactor(fetch): unify JSON requests with fetchResponse utility
    
    - replace custom https-based fetchJson implementation with fetchResponse
    - remove direct https dependency from package-resolutions-updater
    - add axios request options support to fetchResponse utility
    - improve GitHub API error handling and messaging
    - enhance inaccessible URL error output with original and resolved URLs
    
    test(resolve): add debug logging for update result inspection
- [ _2026-05-29 01:08:55_ ] [42bd1bd](<https://github.com/dimaslanjaka/bin/commit/42bd1bd>)
    
    feat(yarn-installer): add Corepack fallback support for Yarn execution
    
    - add Corepack detection before resolving Yarn binary
    - replace spawnSync with cross-spawn for improved cross-platform execution
    - refactor Yarn runner handling into command/args structure
    - improve install command logging output
    - update error handling when neither Corepack nor Yarn is available
- [ _2026-05-29 01:09:58_ ] [5915ea6](<https://github.com/dimaslanjaka/bin/commit/5915ea6>)
    
    feat(vscode): update editor tooling and add checksum/downloader CLI commands
    
    - reformat VSCode terminal and workspace settings
    - switch Jest test runner command for Code Runner integration
    - simplify and clean Intelephense/files watcher configuration
    - add js/ts TypeScript SDK path setting
    - add downloader CLI binary entry
    - add run-by-checksum CLI aliases
    - update git-command-helper and eslint-base-config resolutions
- [ _2026-05-29 01:13:46_ ] [20d79d0](<https://github.com/dimaslanjaka/bin/commit/20d79d0>) feat: add agent instructions for binary-collections
- [ _2026-05-29 01:14:51_ ] [4cf88f0](<https://github.com/dimaslanjaka/bin/commit/4cf88f0>) feat(opencode): reorder plugin entries and specify versioned agent memory URL
- [ _2026-05-29 01:18:17_ ] [d525652](<https://github.com/dimaslanjaka/bin/commit/d525652>)
    
    feat(cli): add downloader command with multiple aliases and documentation
    
    - add downloader CLI for downloading files via HTTP/HTTPS streams
    - support automatic filename resolution and custom output paths
    - add downloader command aliases (download, fetch-file, file-downloader, download-file)
    - register downloader binaries in package and build config
    - add downloader usage documentation and examples
- [ _2026-05-29 01:30:06_ ] [1564b74](<https://github.com/dimaslanjaka/bin/commit/1564b74>)
    
    docs(agent): simplify commit message workflow and formatting guide
    
    - normalize markdown formatting and code fences
    - redesign commit message guidance using bullet-list body format
    - add preferred conventional commit style examples
    - expand commit body requirement and validation rules
    - document BREAKING CHANGE usage requirements
    - replace multiline shell examples with commit file workflow
    - add cross-platform git commit file usage examples
    - simplify commit execution instructions for Windows and Linux environments
    - remove legacy "Why / Changes / Impact" commit structure guidance
    - remove verbose multiline shell command documentation
- [ _2026-05-29 01:33:20_ ] [595506f](<https://github.com/dimaslanjaka/bin/commit/595506f>) feat(opencode): add instructions section to opencode configuration
- [ _2026-05-29 01:35:02_ ] [35575eb](<https://github.com/dimaslanjaka/bin/commit/35575eb>) feat(opencode): add additional instructions monorepo path for agent documentation
- [ _2026-05-29 08:15:02_ ] [98f0587](<https://github.com/dimaslanjaka/bin/commit/98f0587>)
    
    fix(cli): improve error logging and consistency in GitHub Actions cache cleaner
    
    - Standardize require import quotes
    - Enhance error logging with status/code and message extraction
    - Include stack trace in cache deletion errors
    - Improve top-level error handling with structured output
    - Ensure CLI exits with code 1 on fatal errors
- [ _2026-05-29 08:17:23_ ] [79eedb5](<https://github.com/dimaslanjaka/bin/commit/79eedb5>) style: standardize string quotes and improve error messages in cache management script
- [ _2026-05-29 08:20:55_ ] [4131a29](<https://github.com/dimaslanjaka/bin/commit/4131a29>) fix: reorder ACCESS_TOKEN assignment for consistency across scripts
- [ _2026-05-29 08:24:41_ ] [c51a23a](<https://github.com/dimaslanjaka/bin/commit/c51a23a>)
    
    ci(workflow): simplify cache cleanup job and replace local CLI with remote binary execution
    
    - Remove dependency installation and build steps from workflow
    - Replace local Node CLI execution with npx remote binary command
    - Pass repository and commit SHA explicitly via CLI arguments
    - Reduce workflow complexity by delegating logic to external binary
- [ _2026-05-29 08:25:38_ ] [37d94d6](<https://github.com/dimaslanjaka/bin/commit/37d94d6>)
    
    ci(workflow): remove caching and submodule setup steps from clean-caches pipeline
    
    - Remove pip cache directory detection step
    - Remove actions/cache configuration and cache restore logic
    - Remove submodule initialization, sync, and update steps
    - Remove rimraf-based git modules cleanup and binary submodule install
    - Simplify workflow to focus only on cache cleanup execution
- [ _2026-05-29 08:37:24_ ] [2ba249f](<https://github.com/dimaslanjaka/bin/commit/2ba249f>)
    
    docs(ci): add GitHub Actions workflow usage examples and expand trigger configuration
    
    - Add commented explanations for workflow triggers (workflow_run, workflow_dispatch, schedule, push, workflow_call)
    - Document additional CI usage example for clean GitHub Actions cache workflow
    - Include full sample workflow configuration with concurrency control and environment variables
    - Improve documentation clarity for CLI-based cache cleaning in CI environments
- [ _2026-05-29 09:54:03_ ] [51739fb](<https://github.com/dimaslanjaka/bin/commit/51739fb>)
    
    feat(bin): add Windows fallback for bash/sh interpreter resolution
    
    - Add Windows-specific lookup for bash/sh when not found via `which`
    - Search common Git/MSYS2/Cygwin/MinGW installation paths for `bash.exe`
    - Introduce `isWindows` utility to gate platform-specific resolution logic
    - Improve interpreter resolution robustness on Windows environments
    
    refactor(utils): remove unused imports and legacy platform helper
    
    - Remove unused `URL` import from utils index
    - Delete deprecated `isWin.js` utility in favor of centralized platform detection
- [ _2026-05-29 10:10:10_ ] [fda6f61](<https://github.com/dimaslanjaka/bin/commit/fda6f61>)
    
    refactor(rmpath): extract CLI entry point and update bin configuration
    
    - Remove legacy bin/rmpath and bin/rmpath.cmd shell scripts
    - Add src/rmpath-cli.mjs as dedicated CLI entry point
    - Remove CLI invocation logic and getArgs from src/rmpath.mjs, keeping it as a pure library module
    - Register rmpath in build.config.cjs pointing to lib/rmpath-cli.cjs
    - Expand and restructure docs-src/rmpath.md with usage examples, aliases, and behavior details
- [ _2026-05-29 10:14:01_ ] [5be77bd](<https://github.com/dimaslanjaka/bin/commit/5be77bd>) refactor(index): remove joinPathPreserveDriveLetter function and its export
- [ _2026-05-29 10:16:17_ ] [3f17d47](<https://github.com/dimaslanjaka/bin/commit/3f17d47>)
    
    style: enforce single quotes and reformat multiline arrays in config and source files
    
    - Switch singleQuote to true in .prettierrc.json
    - Replace double quotes with single quotes in clean-github-actions-caches.cjs and clean-github-actions-caches-cli.cjs
    - Reformat multiline arrays and args in .vscode/settings.json for consistency
    - Add PowerShell 7, Short PowerShell 7, and Oh My Posh terminal profiles to VS Code settings
    - Replace hardcoded Ollama PATH with %LOCALAPPDATA% variable reference
    - Add WORKSPACE_FOLDER env variable to VS Code terminal environment
- [ _2026-05-29 10:19:49_ ] [61d508f](<https://github.com/dimaslanjaka/bin/commit/61d508f>)
    
    ci: improve concurrency key and add manual trigger to test workflow
    
    - Change concurrency group from github.ref to workflow_run.head_sha to prevent conflicts across branches
    - Add workflow_dispatch trigger to allow manual runs
    - Remove head_sha from job name for cleaner display
- [ _2026-05-29 10:23:47_ ] [bdc2209](<https://github.com/dimaslanjaka/bin/commit/bdc2209>)
    
    refactor(del-ps): migrate CLI entry point from CJS to ESM
    
    - Replace src/del-ps.js (CommonJS) with src/del-ps-cli.mjs (ES module)
    - Update imports to use named exports from cross-spawn and ps-node
    - Fix isWindows import path to use utils/isWindows.js
    - Point del-ps bin entry in build.config.cjs to lib/del-ps-cli.cjs
- [ _2026-05-29 10:35:09_ ] [e5bfa1e](<https://github.com/dimaslanjaka/bin/commit/e5bfa1e>)
    
    fix(del-ps): use named export and fix isWindows import across modules
    
    - Switch default import to named export isWindows in del-ps-cli.mjs
    - Call isWindows() as a function instead of using it as a boolean value
    - Update src/ps/index.cjs to import isWindows from utils/isWindows.js and invoke it
    - Fix table-parser require path to include .js extension
- [ _2026-05-29 10:36:05_ ] [e259f91](<https://github.com/dimaslanjaka/bin/commit/e259f91>)
    
    refactor: replace direct minimist usage with centralized getArgs utility
    
    - Update getArgs in src/utils/index.cjs to accept optional minimist opts parameter
    - Replace minimist imports and direct process.argv.slice(2) calls with getArgs across all CLI entry points:
      - clean-github-actions-caches.cjs
      - del-node-modules.js
      - downloader-cli.cjs
      - file/copy-cli.mjs
      - file/move-cli.mjs
      - node-cache-cleaner-cli.ts
      - node-executor.cjs
      - rm-node-module-cli.cjs
      - run-by-checksum-cli.js
      - submodule-remove-cli.js
      - yarn-per-branch-lock-installer.cjs
- [ _2026-05-29 10:38:58_ ] [2b5c801](<https://github.com/dimaslanjaka/bin/commit/2b5c801>) fix: update eslint-base-config URL to the correct release version
- [ _2026-05-29 10:43:13_ ] [b1d8d42](<https://github.com/dimaslanjaka/bin/commit/b1d8d42>) style: standardize quotes and formatting across packer.cjs
- [ _2026-05-29 10:44:19_ ] [396a79b](<https://github.com/dimaslanjaka/bin/commit/396a79b>) refactor: rename packer.cjs to package.cjs and update reference in package.json
- [ _2026-05-29 10:45:57_ ] [ec49e07](<https://github.com/dimaslanjaka/bin/commit/ec49e07>)
    
    fix(package): improve hash filtering, cleanup, and minor code quality fixes
    
    - Add PowerShell download command to file header comments
    - Rename _isCI to isCI for consistent naming convention
    - Exclude yarn.lock and package-lock.json entries from loaded meta hashes
    - Remove lock file inclusion from tgz readDir list
    - Append newline at end of metafile and readme.md writes
    - Reformat multiline Object.assign and md string concatenation for readability
- [ _2026-05-29 10:48:01_ ] [6f52553](<https://github.com/dimaslanjaka/bin/commit/6f52553>) refactor(package): remove package installation checks from packer script
- [ _2026-05-29 10:49:43_ ] [3f95fe3](<https://github.com/dimaslanjaka/bin/commit/3f95fe3>)
    
    refactor(package): replace native crypto with crypto-js for file hashing
    
    - Replace built-in crypto module with crypto-js library in package.cjs
    - Rewrite file_to_hash to use synchronous fs.readFileSync with CryptoJS WordArray
    - Add explicit switch-case handling for sha1, sha256, sha384, sha512, and md5 algorithms
    - Support both hex and base64 output encodings via CryptoJS encoders
    - Add crypto-js and @types/crypto-js dependencies to package.json
- [ _2026-05-29 10:56:02_ ] [8d62d80](<https://github.com/dimaslanjaka/bin/commit/8d62d80>)
    
    refactor(package): consolidate upath imports and use path namespace throughout
    
    - Remove individual named imports (resolve, join, dirname, toUnix, basename) from upath
    - Import upath as path namespace and replace all standalone calls with path.* equivalents
    - Rename shadowed path variables in filter/map callbacks to f and str for clarity
    - Deduplicate redundant path require declaration
- [ _2026-05-29 11:09:33_ ] [698be0f](<https://github.com/dimaslanjaka/bin/commit/698be0f>) refactor(releases): update .gitignore to include releases and add metadata for bin.tgz
- [ _2026-05-29 11:31:31_ ] [0e249e6](<https://github.com/dimaslanjaka/bin/commit/0e249e6>)
    
    feat(cli,packaging): introduce node package packer CLI and expand bin aliases
    
    - Add node-package-packer documentation with usage, options, and aliases
    - Replace legacy package.cjs script with modular ESM-based implementation
    - Introduce CLI entrypoint for tarball packaging workflow
    - Add build-readme and build-tarball modules for release generation
    - Implement package hash generation with integrity metadata
    - Support both npm pack and yarn pack workflows
    - Extend package.json bin with multiple aliases for packer commands
    - Refactor rmpath CLI entry to cli-specific implementation
    - Improve tarball release generation and GitHub URL mapping logic
- [ _2026-05-29 11:32:23_ ] [336b08b](<https://github.com/dimaslanjaka/bin/commit/336b08b>) refactor(.gitignore): add .tgz files to ignore list
- [ _2026-05-29 11:33:55_ ] [9ab23ca](<https://github.com/dimaslanjaka/bin/commit/9ab23ca>)
    
    docs(cli): add npx one-off execution example for node-package-packer
    
    - Document npx usage for running node-package-packer without installation
    - Provide direct binary-collections remote tarball command example
    - Improve CLI documentation for quick usage scenarios
- [ _2026-05-29 11:38:54_ ] [ad7569b](<https://github.com/dimaslanjaka/bin/commit/ad7569b>)
    
    refactor: replace crypto with crypto-js and split fs imports
    
    - Replace built-in `crypto` module with `crypto-js` for SHA256 hashing
    - Split `fs` import into `fs` (sync) and `fsp` (promises) for clarity
    - Filter out non-existent files before hashing using `fs.existsSync()`
- [ _2026-05-29 11:49:29_ ] [b413d59](<https://github.com/dimaslanjaka/bin/commit/b413d59>)
    
    feat(print-tarball-tree): add CLI tool to display tgz archive directory trees
    
    - add print-tarball-tree command for reading .tgz files and rendering their internal directory structure as a tree
    - add tarball-tree alias registered in build config and package bin map
    - add tar-stream and zlib runtime dependencies with @types/tar-stream dev dependency
    - register command entry points and binary aliases in build.config.cjs and package.json
    - add documentation page under docs-src/ covering usage, aliases, options, and examples
- [ _2026-05-29 11:50:38_ ] [cd21111](<https://github.com/dimaslanjaka/bin/commit/cd21111>) docs(commit-rules): update guidelines to include encoding and line endings
- [ _2026-05-29 11:55:33_ ] [e2094e0](<https://github.com/dimaslanjaka/bin/commit/e2094e0>)
    
    test(getLatestCommit): mock fetchResponse module in ESM test
    
    Replace the axios/https spy with a mock for the actual fetchResponse helper used by getLatestCommit, so the test exercises the real import path and stays deterministic.
- [ _2026-05-29 12:07:10_ ] [d8bf54a](<https://github.com/dimaslanjaka/bin/commit/d8bf54a>)
    
    refactor: migrate from path to upath across codebase
    
    - replace Node.js `path` module with `upath` for cross-platform path normalization
    - update ESM imports (import path from 'path' → import path from 'upath')
    - update CJS requires (const path = require('path') → const path = require('upath'))
    - migrate inline require('path').join() calls to require('upath').join()
    - update both source (src/) and test files consistently
- [ _2026-05-29 12:21:55_ ] [8ed47f8](<https://github.com/dimaslanjaka/bin/commit/8ed47f8>)
    
    feat(clean-github-actions-caches): make cache grouping configurable
    
    Add `--prefix-depth` and `--repo` CLI options to the GitHub Actions cache cleaner, update the prefix extraction logic to ignore checksum-like segments, and add regression tests plus docs for the new behavior.
- [ _2026-05-29 12:24:18_ ] [45e7dcf](<https://github.com/dimaslanjaka/bin/commit/45e7dcf>)
    
    ci: replace build.yml with build-release workflow and update dependents
    
    - Add new build-release.yml with Yarn 4, Bun, submodule support, and artifact size validation
    - Remove legacy build.yml workflow
    - Update clean-caches.yml and test.yml to reference new "Build Release" workflow name
- [ _2026-05-29 12:29:46_ ] [90f9e3b](<https://github.com/dimaslanjaka/bin/commit/90f9e3b>) test: add depth parameter to getCachePrefix and getMeaningfulCacheKeyParts assertions
- [ _2026-05-29 12:32:15_ ] [9182710](<https://github.com/dimaslanjaka/bin/commit/9182710>)
    
    ci: isolate test path triggers between build and test workflows
    
    - Exclude "**/test*/**" paths from build-release.yml triggers
    - Add push trigger on "**/test*/**" paths to test.yml
- [ _2026-05-29 12:38:52_ ] [b0065b2](<https://github.com/dimaslanjaka/bin/commit/b0065b2>) fix(jest.config): update roots and testMatch for improved test discovery
- [ _2026-05-29 12:47:22_ ] [802197d](<https://github.com/dimaslanjaka/bin/commit/802197d>) test: add testPathPatterns to CJS and ESM test commands for folder `<rootDir>/test` only
- [ _2026-05-29 12:48:17_ ] [f26d8ae](<https://github.com/dimaslanjaka/bin/commit/f26d8ae>) test: add step to pack project before running tests
- [ _2026-05-29 12:55:27_ ] [03ccfd6](<https://github.com/dimaslanjaka/bin/commit/03ccfd6>)
    
    fix: add --legacy-peer-deps flag to all npx binary-collections invocations
    
    Add `--legacy-peer-deps` flag to resolve npm EOVERRIDE error caused by
    conflict between direct dependency and overrides for markdown-it package.
- [ _2026-05-29 12:59:20_ ] [e1feaa7](<https://github.com/dimaslanjaka/bin/commit/e1feaa7>) fix: update testPathPatterns to use workspace variable for CJS and ESM tests
- [ _2026-05-29 13:00:49_ ] [212af4d](<https://github.com/dimaslanjaka/bin/commit/212af4d>) fix: add ACCESS_TOKEN environment variable for CJS and ESM test runs
- [ _2026-05-29 13:02:17_ ] [08def68](<https://github.com/dimaslanjaka/bin/commit/08def68>) fix: update paths-ignore to exclude test and docs directories in build-release workflow
- [ _2026-05-29 13:03:41_ ] [df6c7b6](<https://github.com/dimaslanjaka/bin/commit/df6c7b6>) fix: update cache key format to include 'test' prefix for better cache management
- [ _2026-05-29 13:06:40_ ] [614d1e8](<https://github.com/dimaslanjaka/bin/commit/614d1e8>)
    
    ci: disable clean-caches workflow and add cache cleanup step to test
    
    Rename clean-caches.yml to .txt to disable the standalone workflow.
    Add clean GitHub Actions cache step at the end of the test job.
- [ _2026-05-29 13:07:59_ ] [4d78528](<https://github.com/dimaslanjaka/bin/commit/4d78528>) fix: update cache cleanup step to use new command and include repository SHA
- [ _2026-05-29 13:11:20_ ] [d6b2a7b](<https://github.com/dimaslanjaka/bin/commit/d6b2a7b>)
    
    ci: upgrade Node.js to 24.x, pin Python to 3.11, and optimize workflow
    
    - Remove hardcoded ref: master from checkout step
    - Upgrade Node.js from 22 to 24.x
    - Pin Python version from 3.x to 3.11
    - Move venv creation after cache step to skip on cache hit
    - Add build step before pack step
- [ _2026-05-29 13:12:58_ ] [0ae4818](<https://github.com/dimaslanjaka/bin/commit/0ae4818>) fix: update push paths in test workflow to include additional test and src directories
- [ _2026-05-29 13:15:21_ ] [3a52f02](<https://github.com/dimaslanjaka/bin/commit/3a52f02>) fix(ci): allow push and dispatch runs in test workflow
- [ _2026-05-31 22:31:00_ ] [c2c847f](<https://github.com/dimaslanjaka/bin/commit/c2c847f>)
    
    ci(github-actions): refactor test workflow with reusable checkout action and split build/test stages
    
    - add reusable `checkout-dependencies` composite action for repository checkouts
    - eliminate duplicated checkout steps across workflow jobs
    - split workflow into separate build and test jobs with dependency chain
    - add shared Node.js and Python version environment variables
    - optimize cache configuration and restore strategy
    - upload build artifacts after build/pack and consume them in test job
    - move cache cleanup into dedicated cleanup job executed once after build and tests
    - improve PATH setup and executable permission handling
    - use frozen lockfile installation for reproducible builds
    - update token references to use `github.token` fallback
    - simplify workflow structure and improve job isolation
- [ _2026-05-31 22:49:30_ ] [340e329](<https://github.com/dimaslanjaka/bin/commit/340e329>) fix: add missing checkout step in build and test jobs
- [ _2026-05-31 22:54:30_ ] [20164b0](<https://github.com/dimaslanjaka/bin/commit/20164b0>) fix: rename environment variables for Node.js and Python in workflow
- [ _2026-05-31 22:57:53_ ] [bbd2348](<https://github.com/dimaslanjaka/bin/commit/bbd2348>)
    
    refactor(ci): extract environment setup into reusable composite action
    
    - add `setup-environments` composite action for CI environment initialization
    - centralize Node.js and Python setup, cache restoration, and PATH configuration
    - automate virtual environment creation and dependency installation
    - remove duplicated setup logic from build and test jobs
    - replace inline environment setup steps with reusable action invocations
    - improve workflow maintainability and reduce configuration duplication
- [ _2026-05-31 22:58:58_ ] [bc2ec96](<https://github.com/dimaslanjaka/bin/commit/bc2ec96>)
    
    fix(ci): use Corepack-managed Yarn commands in test workflow
    
    - replace direct Yarn invocations with `corepack yarn`
    - create `yarn.lock` before dependency installation
    - switch install step to `corepack yarn install`
    - update build step to use `corepack yarn build`
    - update pack step to use `corepack yarn pack`
    - improve compatibility with environments where Yarn is provided through Corepack
- [ _2026-05-31 23:00:08_ ] [9a88018](<https://github.com/dimaslanjaka/bin/commit/9a88018>)
    
    refactor(ci): standardize Node.js version variable usage
    
    - rename `NODE_VERSION` to `CI_NODE_VERSION` for clearer CI-specific configuration
    - fix `actions/setup-node` configuration to use `node-version`
    - remove built-in Yarn cache configuration from Node.js setup
    - update cache keys and restore keys to reference `CI_NODE_VERSION`
    - improve consistency of environment variable naming across workflow configuration
- [ _2026-05-31 23:17:55_ ] [38c26e9](<https://github.com/dimaslanjaka/bin/commit/38c26e9>)
    
    perf(test): add checksum-based build cache for tarball validation
    
    - compute SHA-256 checksum from git revision, release tarballs, and source files
    - skip build and pack steps when inputs are unchanged
    - cache checksum in tmp/.buildAndPack-checksum
    - rebuild automatically when tracked artifacts change
    - add CryptoJS and glob-based file discovery utilities
    - persist checksum only after successful build and pack operations
- [ _2026-05-31 23:27:47_ ] [f65eea1](<https://github.com/dimaslanjaka/bin/commit/f65eea1>)
    
    fix(node-package-packer): use newest Yarn tarball during packaging
    
    Prevent stale package archives from being bundled by selecting the most
    recently generated .tgz file. This ensures release artifacts always
    match the current build output.
    
    - add newest-tarball resolution logic
    - support fallback discovery of arbitrary .tgz files
    - throw explicit errors when no pack artifact exists
    - remove redundant tarball existence checks
    - clean up generated tarballs after packaging
    - support varying Yarn pack output filenames
### 2.0.3

- [ _2024-02-02 21:43:10_ ] [72dd215](<https://github.com/dimaslanjaka/bin/commit/72dd215>) Update readme.md
- [ _2024-02-02 21:45:25_ ] [3787a2f](<https://github.com/dimaslanjaka/bin/commit/3787a2f>) add repo
- [ _2024-02-02 21:45:53_ ] [fc8d735](<https://github.com/dimaslanjaka/bin/commit/fc8d735>) add homepage
- [ _2024-02-06 16:12:55_ ] [4c260e8](<https://github.com/dimaslanjaka/bin/commit/4c260e8>) update docs
- [ _2024-02-06 16:13:41_ ] [e0b9ac0](<https://github.com/dimaslanjaka/bin/commit/e0b9ac0>) Update readme.md
- [ _2024-02-06 16:18:51_ ] [8814c7c](<https://github.com/dimaslanjaka/bin/commit/8814c7c>) fix invalid path of binary files
- [ _2024-02-06 16:20:27_ ] [13f70c7](<https://github.com/dimaslanjaka/bin/commit/13f70c7>)
    
    bump v2.0.5
    - add yarn caches cleaner
    - fix invalid binary path files
- [ _2024-02-07 15:54:11_ ] [b802f9f](<https://github.com/dimaslanjaka/bin/commit/b802f9f>) add getArgs method
- [ _2024-02-07 15:56:18_ ] [c11a6f8](<https://github.com/dimaslanjaka/bin/commit/c11a6f8>) add process killer with node
- [ _2024-02-11 23:28:13_ ] [3856756](<https://github.com/dimaslanjaka/bin/commit/3856756>) feat: add gradle build folder deleter
- [ _2024-02-11 23:32:21_ ] [074e779](<https://github.com/dimaslanjaka/bin/commit/074e779>) update package info
- [ _2024-02-11 23:39:24_ ] [7ef960a](<https://github.com/dimaslanjaka/bin/commit/7ef960a>) update yarn
- [ _2024-02-11 23:57:38_ ] [f3d90d4](<https://github.com/dimaslanjaka/bin/commit/f3d90d4>) split test unit
- [ _2024-02-11 23:57:50_ ] [cc23b76](<https://github.com/dimaslanjaka/bin/commit/cc23b76>) init typescript for VSCode
- [ _2024-02-12 00:00:30_ ] [c5e9802](<https://github.com/dimaslanjaka/bin/commit/c5e9802>) split test unit
- [ _2024-02-12 00:06:55_ ] [05a255d](<https://github.com/dimaslanjaka/bin/commit/05a255d>) dont index test
- [ _2024-02-12 00:21:03_ ] [3a16c9f](<https://github.com/dimaslanjaka/bin/commit/3a16c9f>) add ts-node hook
- [ _2024-02-12 00:23:18_ ] [f9ae34a](<https://github.com/dimaslanjaka/bin/commit/f9ae34a>)
    
    moved dotenv to production
    used for user defined secret keys
- [ _2024-02-12 00:27:01_ ] [0a91407](<https://github.com/dimaslanjaka/bin/commit/0a91407>) allow modification env
- [ _2024-02-12 00:28:52_ ] [85b7e35](<https://github.com/dimaslanjaka/bin/commit/85b7e35>) pending add purge git repository
- [ _2024-02-15 01:59:27_ ] [1013ba1](<https://github.com/dimaslanjaka/bin/commit/1013ba1>) feat: register `git-purge`
- [ _2024-02-15 02:01:32_ ] [1960653](<https://github.com/dimaslanjaka/bin/commit/1960653>) add install global
- [ _2024-02-15 02:24:04_ ] [5f16107](<https://github.com/dimaslanjaka/bin/commit/5f16107>) rename lib to src
- [ _2024-02-15 02:29:54_ ] [f8c3d13](<https://github.com/dimaslanjaka/bin/commit/f8c3d13>) update tsconfigs
- [ _2024-02-15 02:33:08_ ] [0df6474](<https://github.com/dimaslanjaka/bin/commit/0df6474>) update fetch dirs
- [ _2024-02-16 15:22:32_ ] [29e7620](<https://github.com/dimaslanjaka/bin/commit/29e7620>) missing await on delayed
- [ _2024-03-07 22:49:12_ ] [4268dba](<https://github.com/dimaslanjaka/bin/commit/4268dba>) add numbers and common symbol filenames
- [ _2024-03-07 22:50:54_ ] [fc8c797](<https://github.com/dimaslanjaka/bin/commit/fc8c797>) merged into variable vowels
- [ _2024-09-27 14:45:01_ ] [48e2178](<https://github.com/dimaslanjaka/bin/commit/48e2178>) Update readme.md
- [ _2024-10-04 13:42:38_ ] [f8c355e](<https://github.com/dimaslanjaka/bin/commit/f8c355e>) update yarn 4.5.0
- [ _2024-10-04 13:48:25_ ] [3a148df](<https://github.com/dimaslanjaka/bin/commit/3a148df>) move index
- [ _2024-10-04 14:51:27_ ] [6bef91c](<https://github.com/dimaslanjaka/bin/commit/6bef91c>) feat: disable require warning in js files
- [ _2024-10-04 14:56:30_ ] [600960d](<https://github.com/dimaslanjaka/bin/commit/600960d>) feat: reusable process.cwd inheriter
- [ _2024-10-04 15:04:46_ ] [9e5c913](<https://github.com/dimaslanjaka/bin/commit/9e5c913>) feat: build using `tsup` for ESM and CJS
- [ _2024-10-04 16:17:07_ ] [23a6b5e](<https://github.com/dimaslanjaka/bin/commit/23a6b5e>) update env
- [ _2024-10-04 16:21:27_ ] [36f16ae](<https://github.com/dimaslanjaka/bin/commit/36f16ae>) update packer
- [ _2024-10-04 16:23:33_ ] [b900783](<https://github.com/dimaslanjaka/bin/commit/b900783>) fix(prettier): use double quote
- [ _2024-10-04 16:33:28_ ] [1ca4b15](<https://github.com/dimaslanjaka/bin/commit/1ca4b15>) try migrate eslint v9
- [ _2024-10-04 16:34:38_ ] [73b55f1](<https://github.com/dimaslanjaka/bin/commit/73b55f1>) eslint --fix
- [ _2024-10-05 13:13:22_ ] [a7f75e1](<https://github.com/dimaslanjaka/bin/commit/a7f75e1>) feat: MINGW detection
- [ _2024-10-07 12:16:59_ ] [826e2e3](<https://github.com/dimaslanjaka/bin/commit/826e2e3>) feat: MINGW support
- [ _2024-10-07 12:18:40_ ] [429a176](<https://github.com/dimaslanjaka/bin/commit/429a176>)
    
    bump: v2.0.6
    - map default bin extension to `cjs`
- [ _2024-10-07 14:55:14_ ] [f4f1be7](<https://github.com/dimaslanjaka/bin/commit/f4f1be7>) feat: NodeJS API
- [ _2024-10-07 15:08:25_ ] [3e8ac5f](<https://github.com/dimaslanjaka/bin/commit/3e8ac5f>) chore(tsup): disable bundle node_modules
- [ _2025-06-26 03:31:09_ ] [6d46bf8](<https://github.com/dimaslanjaka/bin/commit/6d46bf8>) Create submodule-install.cjs
- [ _2025-06-28 05:32:12_ ] [7f8e121](<https://github.com/dimaslanjaka/bin/commit/7f8e121>)
    
    refactor(submodule): improve .env loading and path handling
    
    - Removed `dotenv` dependency and implemented custom `.env` loader
    - Added support for inline quotes and trimming in env parsing
    - Replaced `require('path')`/`require('fs')` methods with consistent `path`/`fs` usage
    - Used `path.resolve` and `path.join` for better cross-platform compatibility
    - Enhanced submodule cleanup with safe recursive deletion
    - Improved logging, structure, and error handling in submodule operations
- [ _2025-06-28 05:39:43_ ] [bd6ee9a](<https://github.com/dimaslanjaka/bin/commit/bd6ee9a>) eslint --fix
- [ _2025-06-28 06:04:08_ ] [35845b3](<https://github.com/dimaslanjaka/bin/commit/35845b3>)
    
    chore(build): improve bin entry resolution and logging
    
    - Added `ansi-colors` for better CLI log readability
    - Exclude additional patterns from glob (e.g., tsbuildinfo, eslint, build files)
    - Prioritize files inside `bin/` when registering `pkg.bin` entries
    - Normalize path comparison using `path.toUnix`
    - Improved bin entry key sanitization (replaces `.` with `-`)
    - Added colored logs to indicate bin registration sources (green for `bin/`, yellow otherwise)
- [ _2025-06-28 06:07:23_ ] [211b1f6](<https://github.com/dimaslanjaka/bin/commit/211b1f6>) feat: Yarn reinstaller
- [ _2025-06-28 06:07:41_ ] [d6596f8](<https://github.com/dimaslanjaka/bin/commit/d6596f8>) feat: fresh build from github workspace
- [ _2025-06-30 13:48:51_ ] [5104dbe](<https://github.com/dimaslanjaka/bin/commit/5104dbe>)
    
    feat(git-diff): add unified Node.js implementation with cross-platform support
    
    - Create git-diff.cjs with CLI for staged git diffs
    - Add bash and cmd wrappers for cross-platform compatibility
    - Support file-specific and full staged diff modes
    - Include help system and short flag aliases
    - Output to .cache/git/diff.txt with proper error
- [ _2025-07-04 16:57:20_ ] [eb4b498](<https://github.com/dimaslanjaka/bin/commit/eb4b498>) feat: add configuration instructions for Node.js, PHP, and Python
- [ _2025-07-04 17:00:54_ ] [709fe59](<https://github.com/dimaslanjaka/bin/commit/709fe59>) refactor: update to yarn v4.9.2
- [ _2025-07-04 17:02:24_ ] [5c848fd](<https://github.com/dimaslanjaka/bin/commit/5c848fd>) feat: add Jest configuration and update test scripts in package.json
- [ _2025-07-04 17:03:16_ ] [c199dcd](<https://github.com/dimaslanjaka/bin/commit/c199dcd>) fix(git-diff): improve error handling and user feedback for empty diffs
- [ _2025-07-04 17:08:36_ ] [c64867a](<https://github.com/dimaslanjaka/bin/commit/c64867a>)
    
    refactor: use double quotes and improve CLI UX
    
    - Switched all require/import and string literals to double quotes for consistency.
    - Improved help output formatting.
    - Added command logging for better traceability.
    - Enhanced error handling and user feedback.
    - Fixed help display logic to only show when --help or -h is passed.
    - Defaulted to full diff if no file argument is provided.
- [ _2025-07-04 17:09:06_ ] [97177d9](<https://github.com/dimaslanjaka/bin/commit/97177d9>) feat: add git-diff command script for improved functionality
- [ _2025-07-04 17:10:19_ ] [86bc87c](<https://github.com/dimaslanjaka/bin/commit/86bc87c>)
    
    refactor: update jest.config.js formatting, add git-diff script, and add tests for findNodeModules
    
    - Reformatted jest.config.js to use double quotes and single-line arrays for consistency.
    - Added "git-diff" script entry to package.json.
    - Added comprehensive tests for findNodeModules in test/find-node-modules.test.ts, covering directory discovery, callback handling, error handling, cwd usage, and .git directory exclusion.
- [ _2025-07-04 17:13:20_ ] [f7374e8](<https://github.com/dimaslanjaka/bin/commit/f7374e8>)
    
    feat: support token authentication for GitHub, GitLab, and generic Git providers
    
    - Refactored remote URL handling to inject access tokens for GitHub, GitLab, and other Git providers.
    - Added conditional logic for GitLab using GITLAB_TOKEN.
    - Fallback to a generic approach for other providers.
    - Improved logging for clarity.
- [ _2025-07-04 17:14:11_ ] [615af7b](<https://github.com/dimaslanjaka/bin/commit/615af7b>) chore: update build
- [ _2025-07-05 15:09:45_ ] [c56d670](<https://github.com/dimaslanjaka/bin/commit/c56d670>) fix: ensure process.cwd returns a valid path with package.json
- [ _2025-07-05 15:23:10_ ] [d66c9ea](<https://github.com/dimaslanjaka/bin/commit/d66c9ea>) bump: v2.0.8
- [ _2025-07-05 17:22:36_ ] [b340f24](<https://github.com/dimaslanjaka/bin/commit/b340f24>)
    
    fix(git-diff): increase buffer size to handle large diffs
    
    - Add maxBuffer option (10MB) to execSync to prevent ENOBUFS errors
    - Fixes issue when git diff output exceeds default buffer size
    - Resolves 'spawnSync ENOBUFS' error for large staged changes
- [ _2025-07-05 17:26:23_ ] [25d71ab](<https://github.com/dimaslanjaka/bin/commit/25d71ab>)
    
    feat: add binary-collections CLI for dynamic script execution
    
    - Add main binary-collections command that can dynamically find and execute other scripts
    - Update .gitignore to handle yarn cache variations with wildcard pattern
    - Add binary-collections entry point in package.json and build.js
    - Implement help system and error handling for script discovery
    - Support .cjs, .js, and .mjs script extensions
    - Update binary release package
    
    Usage: npx binary-collections <script-name> [...args]
    Example: npx binary-collections git-diff -s
- [ _2025-07-05 17:29:25_ ] [c437eb4](<https://github.com/dimaslanjaka/bin/commit/c437eb4>)
    
    feat(cli): enhance CLI output with emojis and improved formatting
    
    - Added emojis to help, usage, examples, and error messages for better UX
    - Improved section headers and formatting for clarity
    - Updated script execution and error logs with visual indicators
- [ _2025-07-05 17:37:33_ ] [a55c9b1](<https://github.com/dimaslanjaka/bin/commit/a55c9b1>)
    
    chore: remove compiled lib directory and update .gitignore
    
    - Deleted all files under lib/ to clean up compiled outputs
    - Updated .gitignore to include **/lib/** for future builds
    - Updated readme.md to remove deprecated Git install instructions
- [ _2025-07-05 17:40:28_ ] [6654aff](<https://github.com/dimaslanjaka/bin/commit/6654aff>)
    
    refactor: centralize temp directory config and update git-diff output path
    
    - Add src/binary-collections-config.js for centralized temp directory and path management
    - Update git-diff.cjs to use getTempPath from the new config module
    - Add binary-collections-config bin entry in package.json
- [ _2025-07-05 17:52:18_ ] [04a378b](<https://github.com/dimaslanjaka/bin/commit/04a378b>)
    
    refactor: use glob for script discovery and improve filtering
    
    - Replaced manual fs/path script search with glob for more flexible matching.
    - Added ignore patterns to exclude config, utils, index, chunk, and TypeScript declaration files.
    - Improved help flag handling and output.
    - Now prints found script path relative to current working directory.
- [ _2025-07-05 17:55:26_ ] [b533da1](<https://github.com/dimaslanjaka/bin/commit/b533da1>)
    
    refactor: replace sbg-utility with fs and upath, improve JSDoc comments
    
    - Replaced usage of 'sbg-utility' with native 'fs' and 'upath' modules.
    - Enhanced JSDoc comments for better clarity and type annotations.
    - Improved function documentation and parameter descriptions.
- [ _2025-07-05 18:05:30_ ] [dfa7508](<https://github.com/dimaslanjaka/bin/commit/dfa7508>)
    
    feat: add comprehensive git-fix utility and remove deprecated git-fix-encoding
    
    - Add new git-fix.cjs utility with enhanced Git configuration management
      - Forces LF line endings (core.autocrlf=false, core.eol=lf)
      - Ignores file permission changes (core.filemode=false)
      - Sets pull strategy (pull.rebase=false)
      - Creates/updates .gitattributes with proper line ending rules
      - Normalizes existing file line endings
      - Supports flexible CLI options (--lf-only, --permissions, --normalize)
    
    - Remove deprecated git-fix-encoding scripts
      - Delete bin/git-fix-encoding and bin/git-fix-encoding.cmd
      - Remove from package.json bin configuration
      - All functionality superseded by new git-fix utility
    
    - Add cross-platform support
      - Create bin/git-fix (bash) and bin/git-fix.cmd (Windows)
      - Add test/git-fix.js test file
      - Update build.js to include git-fix in compilation
    
    - Update documentation
      - Add comprehensive git-fix documentation to README
      - Update tools table to reflect new utility
      - Note replacement of git-fix-encoding
    
    BREAKING CHANGE: git-fix-encoding command removed, use git-
- [ _2025-07-05 18:20:40_ ] [036536c](<https://github.com/dimaslanjaka/bin/commit/036536c>) docs: add instruction for testing current project as dependency in test-project directory
- [ _2025-07-05 18:33:51_ ] [23cbf67](<https://github.com/dimaslanjaka/bin/commit/23cbf67>)
    
    refactor(git-fix): modularize utility and add CLI user configuration
    
    - Refactor git-fix.cjs into modular structure with separate files in src/git/
      - utils.cjs: Core git command execution and repository detection
      - line-endings.cjs: LF line ending configuration and .gitattributes management
      - permissions.cjs: File permission settings
      - pull-strategy.cjs: Git pull strategy configuration
      - user-config.cjs: Git user configuration with CLI/environment precedence
      - normalize.cjs: Line ending normalization for existing files
    
    - Add CLI argument support for git user configuration
      - Support --user NAME EMAIL syntax for direct user specification
      - Maintain --user flag for environment variable usage
      - Implement precedence: CLI args > environment variables > skip
      - Add comprehensive help documentation for new features
    
    - Update build configuration to exclude src/git/ directory from processing
    
    - Enhance README with detailed user configuration examples and precedence rules
    
    - Add comprehensive test coverage for modular structure and CLI arguments
    
    - Remove deprecated git-fix.js test file and replace with git-fix.direct.js
    
    Breaking changes: None - all existing functionality preserved
    New features: CLI arguments for git user configuration with precedence handling
- [ _2025-07-05 19:42:15_ ] [7b4d699](<https://github.com/dimaslanjaka/bin/commit/7b4d699>)
    
    test: add comprehensive tests for git-fix utility and git modules
    
    - Add integration and unit tests for git-fix CLI, user config, utils, and gitattributes logic
    - Ensure .env is loaded for test environment
    - Cover line endings, permissions, user config, and normalization features
    - Add test helpers for temp git repo setup and cleanup
    - Improve .gitattributes handling and conflict resolution logic
    - Update devDependencies and scripts for test tooling (jest, lint-staged, husky)
    - Add focused and integration test suites for robust coverage
- [ _2025-07-05 19:58:18_ ] [90e63f8](<https://github.com/dimaslanjaka/bin/commit/90e63f8>)
    
    refactor: ensure package.json key order and cleanup
    
    - Updated build.js to reconstruct package.json with a consistent and valid key order.
    - Cleaned up package.json: reordered keys, removed duplicates, and ensured standard fields appear in the correct order.
    - No functional changes to package logic.
- [ _2025-07-08 17:20:52_ ] [90bae8e](<https://github.com/dimaslanjaka/bin/commit/90bae8e>)
    
    feat: add getFileTreeString function to create a directory/file tree from hashes
    test: add unit tests for getFileTreeString function
- [ _2025-07-08 17:34:54_ ] [c331f0e](<https://github.com/dimaslanjaka/bin/commit/c331f0e>)
    
    feat: add print-directory-tree script to generate directory tree with file hashes
    
    - Adds src/print-directory-tree.cjs script to generate a directory/file tree with SHA-256 hashes for each file.
    - Supports filtering by file extension, custom glob patterns, and directory exclusions via CLI arguments.
    - Outputs the tree to a specified file and optionally stages it for git.
    - Includes special handling for common project files (package.json, composer.json, requirements.txt).
- [ _2025-07-08 17:35:25_ ] [0c0798b](<https://github.com/dimaslanjaka/bin/commit/0c0798b>)
    
    feat: add ESM export and CLI support to find-node-modules
    
    - Added support for both CommonJS and ESM usage in find-node-modules.js.
    - Added CLI entry point for direct execution.
    - Removed unused test/find-node-modules-cli.js file.
- [ _2025-07-08 17:36:42_ ] [8b02cd2](<https://github.com/dimaslanjaka/bin/commit/8b02cd2>)
    
    feat: add print-tree and dir-tree commands for directory tree printing
    
    - Added "print-tree" and "dir-tree" entries to build.js and package.json, both pointing to lib/print-directory-tree.cjs.
    - Added "print-directory-tree" and "print-tree" scripts to package.json for easier access.
- [ _2025-07-08 17:41:58_ ] [26c864c](<https://github.com/dimaslanjaka/bin/commit/26c864c>) feat: add help command with usage instructions for print-directory-tree script
- [ _2025-07-08 17:44:40_ ] [c5516d0](<https://github.com/dimaslanjaka/bin/commit/c5516d0>) chore: drop submodule
- [ _2025-07-08 18:07:34_ ] [3ee32d5](<https://github.com/dimaslanjaka/bin/commit/3ee32d5>)
    
    feat: add script to update GitHub tarball URLs in package.json resolutions to latest commit SHA
    
    - Adds package-resolutions-updater.mjs to automate updating GitHub tarball URLs in the `resolutions` field of package.json.
    - Fetches the latest commit SHA for each GitHub package and replaces branch names or old SHAs in URLs.
    - Supports static override rules for specific packages/branches.
    - Ensures deterministic builds by always using immutable SHAs.
- [ _2025-07-08 18:16:15_ ] [02a7387](<https://github.com/dimaslanjaka/bin/commit/02a7387>)
    
    refactor: optimize package.json loading and persist GitHub User-Agent
    
    - Load package.json once at the top for efficiency.
    - Persist a randomly selected GitHub User-Agent in the system temp folder to reduce API rate limiting.
    - Improve error handling for reading and writing package.json.
    - Minor code cleanup and improved update logic.
- [ _2025-07-08 18:18:11_ ] [2bfc4a9](<https://github.com/dimaslanjaka/bin/commit/2bfc4a9>)
    
    feat: update dependencies and add pkg-res-updater bin alias
    
    - Updated several dependencies and devDependencies to latest versions in package.json.
    - Added "pkg-res-updater" bin alias for "package-resolutions-updater.cjs" in build.js.
    - Added "resolutions" field for cross-spawn in package.json.
- [ _2025-07-10 04:33:57_ ] [3567546](<https://github.com/dimaslanjaka/bin/commit/3567546>) feat: add git-command-helper submodule configuration
- [ _2025-07-10 04:35:55_ ] [cb24007](<https://github.com/dimaslanjaka/bin/commit/cb24007>)
    
    feat: add support for .mjs and .cjs test files and enable workspaces
    
    - Update test scripts and patterns to include .mjs and .cjs extensions
    - Add jest globals to ESLint config for test files
    - Improve Jest config to handle .mjs and .cjs files with babel-jest
    - Expand collectCoverageFrom patterns for additional extensions
    - Add Yarn workspaces support in package.json
- [ _2025-07-10 05:30:47_ ] [303547a](<https://github.com/dimaslanjaka/bin/commit/303547a>) fix: update glob options to ignore directories and enhance package.json workspaces
- [ _2025-07-10 05:36:25_ ] [0fd3430](<https://github.com/dimaslanjaka/bin/commit/0fd3430>) fix: update dotenv dependency to version 17.2.0 and refactor .env loading in submodule-install script
- [ _2025-07-10 06:32:33_ ] [332d141](<https://github.com/dimaslanjaka/bin/commit/332d141>) feat: add instructions for updating readme and ensure lookup for build.js and src folder
- [ _2025-07-10 06:36:45_ ] [f66703d](<https://github.com/dimaslanjaka/bin/commit/f66703d>) fix: remove duplicate git-command-helper dependency from devDependencies and add it to dependencies
- [ _2025-07-10 06:36:58_ ] [8e0d4d5](<https://github.com/dimaslanjaka/bin/commit/8e0d4d5>) fix: update package management section in README to include additional utilities
- [ _2025-07-10 06:37:14_ ] [f4cd66f](<https://github.com/dimaslanjaka/bin/commit/f4cd66f>) chore: update subproject commit for git-command-helper
- [ _2025-07-10 08:44:34_ ] [0429ad6](<https://github.com/dimaslanjaka/bin/commit/0429ad6>) feat: add build:packages script for workspace builds
- [ _2025-07-10 08:50:06_ ] [07d3b65](<https://github.com/dimaslanjaka/bin/commit/07d3b65>)
    
    refactor: add runGitCommandOutput for capturing git command output
    
    - Added runGitCommandOutput to execute git commands and return stdout or null on error.
    - Improved logging and error handling for command execution.
    - Cleaned up formatting and removed unnecessary blank lines.
- [ _2025-07-10 08:53:36_ ] [81257bd](<https://github.com/dimaslanjaka/bin/commit/81257bd>) refactor: update script paths to use lib directory and add echo for script execution
- [ _2025-07-10 09:00:50_ ] [8b3825b](<https://github.com/dimaslanjaka/bin/commit/8b3825b>) refactor: simplify process.cwd function and ensure git repository cloning
- [ _2025-07-10 09:04:19_ ] [72e3e94](<https://github.com/dimaslanjaka/bin/commit/72e3e94>) fix: include TypeScript files in test script pattern for code runner
- [ _2025-07-10 09:30:56_ ] [fcf536c](<https://github.com/dimaslanjaka/bin/commit/fcf536c>) docs: update Node.js instructions to include environment setup for testing
- [ _2025-07-10 09:39:52_ ] [ff015cb](<https://github.com/dimaslanjaka/bin/commit/ff015cb>) test: add unit tests for parseGitAttributes function
- [ _2025-07-10 09:44:05_ ] [a2c86dc](<https://github.com/dimaslanjaka/bin/commit/a2c86dc>)
    
    Refactor gitattributes rule merging logic and improve tests
    
    - Simplified mergeGitAttributeRules to use exact pattern matching for rule conflicts.
    - Improved handling of rule replacement based on priority.
    - Updated integration tests in git-fix-focused.test.js to use process.cwd() and clarified comments.
    - Added new gitattributes-update.test.js for integration testing of updateGitAttributes, covering rule creation, addition, deduplication, and priority replacement.
- [ _2025-07-10 09:46:08_ ] [9b9f478](<https://github.com/dimaslanjaka/bin/commit/9b9f478>) fix: update workflow trigger to ignore .tgz files on push
- [ _2025-07-10 10:01:16_ ] [36dc8cd](<https://github.com/dimaslanjaka/bin/commit/36dc8cd>) delete: remove git-fix integration test file
- [ _2025-07-10 10:02:23_ ] [e3f1f60](<https://github.com/dimaslanjaka/bin/commit/e3f1f60>) fix: ensure environment setup in test files
- [ _2025-07-10 10:03:27_ ] [0120be4](<https://github.com/dimaslanjaka/bin/commit/0120be4>) fix: ensure LF rule is added to .gitattributes if missing
- [ _2025-07-10 10:17:15_ ] [c0d92e2](<https://github.com/dimaslanjaka/bin/commit/c0d92e2>) feat: add interactive remote URL update prompt in Git user configuration
- [ _2025-07-10 10:29:01_ ] [57f2a83](<https://github.com/dimaslanjaka/bin/commit/57f2a83>) fix: update test script in code-runner executor map to use npm test
- [ _2025-07-10 10:35:06_ ] [243b4e3](<https://github.com/dimaslanjaka/bin/commit/243b4e3>) fix: improve caching strategy in build workflow by including package.json hash
- [ _2025-07-10 10:44:53_ ] [eadfa90](<https://github.com/dimaslanjaka/bin/commit/eadfa90>) fix: add resolution for sbg-utility package in package.json
- [ _2025-07-10 11:01:35_ ] [db0aa19](<https://github.com/dimaslanjaka/bin/commit/db0aa19>) fix: add test coverage step before build workflow
- [ _2025-07-10 11:08:56_ ] [7500228](<https://github.com/dimaslanjaka/bin/commit/7500228>)
    
    refactor(git-fix): make git user config and remote update fully non-interactive
    
    - Refactor `configureGitUser` to remove all interactive prompts; remote URL updates are now controlled by the `--update-remote` CLI flag or options parameter.
    - Update `git-fix.cjs` to always call `configureGitUser` with the correct `updateRemote` option, even if only `--update-remote` is passed.
    - Update CLI and test documentation in `readme.md` to reflect new argument-driven, non-interactive behavior.
    - Expand and update tests in `test/git-fix.test.js` and `test/git-user-config.test.js` to cover all combinations of `--user` and `--update-remote`.
    - Remove all `readline`/prompt logic and related test code.
- [ _2025-07-10 11:14:35_ ] [c67a15c](<https://github.com/dimaslanjaka/bin/commit/c67a15c>) feat: add readline mock for testing input handling
- [ _2025-07-10 11:25:07_ ] [d6e1010](<https://github.com/dimaslanjaka/bin/commit/d6e1010>) refactor(env): restructure repoDir assignment for clarity and export
- [ _2025-07-10 13:44:42_ ] [4e28c2a](<https://github.com/dimaslanjaka/bin/commit/4e28c2a>) test: add integration tests for npm and yarn installation from remote tarball
- [ _2025-07-10 13:47:32_ ] [397a5fb](<https://github.com/dimaslanjaka/bin/commit/397a5fb>) fix(build): update cache key and reorder test coverage execution
- [ _2025-07-10 13:51:24_ ] [e4a67c2](<https://github.com/dimaslanjaka/bin/commit/e4a67c2>) feat(dependabot): add initial configuration for version updates across npm, GitHub Actions, and git submodules
- [ _2025-07-10 13:52:30_ ] [b86367a](<https://github.com/dimaslanjaka/bin/commit/b86367a>) fix: update path import to use 'upath' in del-gradle.js and env.js
- [ _2025-07-10 13:59:34_ ] [3ee6c90](<https://github.com/dimaslanjaka/bin/commit/3ee6c90>) fix(env): improve error handling for git clone failure
- [ _2025-07-10 14:00:28_ ] [5359dfa](<https://github.com/dimaslanjaka/bin/commit/5359dfa>) fix(build): add checkout step for dimaslanjaka/test-repo in workflow
- [ _2025-07-10 14:09:23_ ] [35bb4bf](<https://github.com/dimaslanjaka/bin/commit/35bb4bf>) fix(build): update cache paths to use glob patterns for better matching
- [ _2025-07-10 14:27:24_ ] [537b6b6](<https://github.com/dimaslanjaka/bin/commit/537b6b6>)
    
    Refactor utils.js: modularize exports and add new utility functions
    
    - Export all utility functions individually instead of as a single object.
    - Add parseGitRemotes: parses GitHub remotes from `git remote -v` output.
    - Add joinPathPreserveDriveLetter: joins path segments and preserves drive letter case on Windows.
    - Add missing exports for getArgs, del, delStream, getFileTreeString, and delay.
    - Improve code organization and maintainability.
- [ _2025-07-10 14:37:27_ ] [979d113](<https://github.com/dimaslanjaka/bin/commit/979d113>) fix(index.js): simplify callback checks in kill function
- [ _2025-07-10 14:58:20_ ] [c413dc1](<https://github.com/dimaslanjaka/bin/commit/c413dc1>)
    
    refactor: unify CLI argument parsing via getArgs utility
    
    - Replace direct usage of process.argv and minimist with getArgs() from utils.js across all CLI scripts in src/
    - Standardize positional and flag argument handling for consistency
    - Update help and option checks to use parsed args object
    - Refactor scripts to use args._ for positional arguments and args.<flag> for options
    - Remove redundant manual argument parsing logic
    
    This change improves maintainability and ensures consistent CLI behavior across
- [ _2025-07-10 15:00:21_ ] [18e070a](<https://github.com/dimaslanjaka/bin/commit/18e070a>) docs: update commit message guidelines and structure in instructions
- [ _2025-07-10 15:02:53_ ] [4278304](<https://github.com/dimaslanjaka/bin/commit/4278304>) fix(build.yml): correct git status check to only include releases directory
- [ _2025-07-10 15:09:58_ ] [ea37f33](<https://github.com/dimaslanjaka/bin/commit/ea37f33>) refactor: update dotenv import and loading mechanism in package-resolutions-updater and print-directory-tree
- [ _2025-07-10 15:20:09_ ] [10163a8](<https://github.com/dimaslanjaka/bin/commit/10163a8>) refactor(test): use resolved path for git-fix module in tests
- [ _2025-07-10 15:29:01_ ] [8fb2f33](<https://github.com/dimaslanjaka/bin/commit/8fb2f33>)
    
    refactor(test): improve isolation and mocking in --update-remote test
    
    - Moves process.argv assignment before requiring modules to ensure correct test setup.
    - Uses jest.doMock to mock dependencies for better isolation.
    - Adds local spies and restores them after test.
    - Ensures runGitCommand and runGitCommandOutput are properly mocked and asserted.
- [ _2025-07-10 16:20:04_ ] [688a3da](<https://github.com/dimaslanjaka/bin/commit/688a3da>) fix: ensure correct working directory for git repository check
- [ _2025-07-10 16:31:15_ ] [2f1faa5](<https://github.com/dimaslanjaka/bin/commit/2f1faa5>) refactor(env): improve directory handling and ensure non-git directory creation
- [ _2025-07-10 16:34:37_ ] [cdf9081](<https://github.com/dimaslanjaka/bin/commit/cdf9081>) refactor(git): enhance isGitRepository function to accept custom cwd parameter
- [ _2025-07-10 16:45:33_ ] [de3f3d9](<https://github.com/dimaslanjaka/bin/commit/de3f3d9>) test: add unit tests for isGitRepository function
- [ _2025-07-10 16:48:15_ ] [783fbe9](<https://github.com/dimaslanjaka/bin/commit/783fbe9>) refactor(env): store original working directory for improved context
- [ _2025-07-12 15:56:28_ ] [eed3799](<https://github.com/dimaslanjaka/bin/commit/eed3799>) test: enhance isGitRepository tests with logging and cwd restoration
- [ _2025-07-12 15:56:57_ ] [5a54516](<https://github.com/dimaslanjaka/bin/commit/5a54516>) feat: add new bin command for cleaning GitHub Actions caches and update dependencies
- [ _2025-07-12 15:59:07_ ] [03eb490](<https://github.com/dimaslanjaka/bin/commit/03eb490>) test: add unit tests for git-fix utility help functionality
- [ _2025-07-12 17:13:49_ ] [0c3e6d3](<https://github.com/dimaslanjaka/bin/commit/0c3e6d3>) fix: update `git-diff` command path to use the correct module location
- [ _2025-07-12 17:27:03_ ] [1acb07c](<https://github.com/dimaslanjaka/bin/commit/1acb07c>)
    
    refactor(test/env.js): improve dotenv loading and add yarn project/package helpers
    
    - Use explicit dotenv import and check for .env file before loading
    - Add ensureYarnProject() to initialize yarn project and restore/create yarn.lock
    - Add installYarnPackage() to install local tgz package in test repo
    - Use shell option for spawnSync to improve cross-platform compatibility
- [ _2025-07-12 17:27:42_ ] [dbc69ab](<https://github.com/dimaslanjaka/bin/commit/dbc69ab>) test: add initial tests for git-diff CLI functionality
- [ _2025-07-12 17:43:58_ ] [f950cc4](<https://github.com/dimaslanjaka/bin/commit/f950cc4>) test: add unit tests for git-fix utility individual options
- [ _2025-07-12 17:45:56_ ] [fe9abc6](<https://github.com/dimaslanjaka/bin/commit/fe9abc6>) fix(package.json): update test script to remove unused option and add debug variant
- [ _2025-07-12 17:46:20_ ] [aeb6f0b](<https://github.com/dimaslanjaka/bin/commit/aeb6f0b>) fix: improve error handling in installYarnPackage function to include stdout and stderr
- [ _2025-07-12 17:56:42_ ] [83e4e59](<https://github.com/dimaslanjaka/bin/commit/83e4e59>) fix: replace path module with upath for cross-platform compatibility
- [ _2025-07-12 17:58:35_ ] [1fe1028](<https://github.com/dimaslanjaka/bin/commit/1fe1028>) test: add unit tests for git-fix utility summary messages
- [ _2025-07-12 17:59:12_ ] [61418c6](<https://github.com/dimaslanjaka/bin/commit/61418c6>) fix: remove outdated comments in env.js for clarity
- [ _2025-07-12 17:59:55_ ] [bf1a624](<https://github.com/dimaslanjaka/bin/commit/bf1a624>)
    
    refactor: improve --user argument parsing and add cwd output
    
    - Enhanced --user flag parsing to handle string, array, and boolean types.
    - Improved error handling for missing NAME/EMAIL arguments.
    - Moved help display logic after argument parsing.
    - Added current working directory output using upath.
    - Updated git repository detection to use process.cwd().
- [ _2025-07-12 18:13:15_ ] [0ab4c77](<https://github.com/dimaslanjaka/bin/commit/0ab4c77>)
    
    feat: add GitHub Actions cache cleaner utility
    
    - Added `clean-github-actions-caches.cjs` to remove old GitHub Actions caches, keeping only the latest for each prefix.
    - Updated `build.js` to register new CLI binaries: `clean-github-actions-caches`, `clean-github-actions-cache`, `clear-github-actions-cache`, `clear-github-actions-caches`, `clear-gh-caches`.
    - Documented cache cleaner usage and features in `readme.md`.
    - Improved JSDoc comments and code clarity in `src/utils.js`.
    - Added GitHub Actions workflow for scheduled cache cleaning.
- [ _2025-07-12 18:15:43_ ] [1576599](<https://github.com/dimaslanjaka/bin/commit/1576599>) refactor: remove isGitRepository tests and unused execSync import
- [ _2025-07-12 18:17:42_ ] [9bdd8c3](<https://github.com/dimaslanjaka/bin/commit/9bdd8c3>) chore(clean-caches): comment out repository-specific workflow conditions and checkout options
- [ _2025-07-12 19:48:09_ ] [479c162](<https://github.com/dimaslanjaka/bin/commit/479c162>) refactor: remove git repository detection tests for focused integration
- [ _2025-07-12 19:53:32_ ] [a276a28](<https://github.com/dimaslanjaka/bin/commit/a276a28>) refactor: remove obsolete git-fix utility tests
- [ _2025-07-14 05:03:55_ ] [d5d92ff](<https://github.com/dimaslanjaka/bin/commit/d5d92ff>) refactor: re-order update submodule step
- [ _2025-07-15 04:50:53_ ] [606e90c](<https://github.com/dimaslanjaka/bin/commit/606e90c>) chore: add detectOpenHandles option to Jest configuration
- [ _2025-07-15 04:52:46_ ] [50865c5](<https://github.com/dimaslanjaka/bin/commit/50865c5>)
    
    feat(bin): prefer lib/.cjs files for bin/src name collisions; add submodule-install bin entry
    
    - add "submodule-install" to defaultBin mapping
    - prefer lib/<basename>.cjs over src/<basename> for bin key collisions
- [ _2025-07-19 12:52:27_ ] [d9624cd](<https://github.com/dimaslanjaka/bin/commit/d9624cd>) chore: bump version to 2.0.9
- [ _2025-07-20 17:57:09_ ] [06ec3fd](<https://github.com/dimaslanjaka/bin/commit/06ec3fd>) chore: remove outdated PHP and Python coding standards instructions
- [ _2025-07-20 17:57:27_ ] [5adf09d](<https://github.com/dimaslanjaka/bin/commit/5adf09d>) chore: update paths-ignore pattern to exclude release files in build workflow
- [ _2025-07-20 17:58:00_ ] [376060b](<https://github.com/dimaslanjaka/bin/commit/376060b>) chore: update paths-ignore pattern to exclude release files
- [ _2025-07-20 18:06:48_ ] [53dceed](<https://github.com/dimaslanjaka/bin/commit/53dceed>) chore: reorder PATH entries in terminal environment settings for consistency
- [ _2025-07-20 18:20:12_ ] [c430333](<https://github.com/dimaslanjaka/bin/commit/c430333>)
    
    fix(bin): improve fallback script resolution from package.json bin map
    
    - Enhance `findScript` to search `pkg.bin[scriptName]` if glob fails
    - Adds fallback to node_modules path
    - Warns when script is not found, including searched pattern and valid extensions
- [ _2025-07-20 18:38:22_ ] [74e769a](<https://github.com/dimaslanjaka/bin/commit/74e769a>)
    
    test(validate-tarball): rename and refactor install tests for clarity
    
    - Replace old `install.test.cjs` with `validate-tarball.test.cjs`
    - Consolidate tarball tests into a focused suite
    - Improve file naming and separation of concerns
    - Ensure proper cleanup and validation of binary links
- [ _2025-07-20 18:51:15_ ] [579c1b2](<https://github.com/dimaslanjaka/bin/commit/579c1b2>)
    
    refactor(token): prioritize GITHUB_TOKEN over ACCESS_TOKEN
    
    - Unifies token logic by consistently preferring GITHUB_TOKEN if available
    - Applies the update to both `clean-github-actions-caches` and `submodule-install` scripts
    - Simplifies token usage and avoids redundant env checks
- [ _2025-07-20 18:54:28_ ] [103af3b](<https://github.com/dimaslanjaka/bin/commit/103af3b>)
    
    feat(resolutions-updater): add CLI help option and unify token usage
    
    - Added --help / -h support to display usage instructions
    - Prioritized GITHUB_TOKEN over ACCESS_TOKEN for GitHub API authentication
    - Applied consistent token usage via `ACCESS_TOKEN` variable
- [ _2025-07-20 19:03:37_ ] [cbff32e](<https://github.com/dimaslanjaka/bin/commit/cbff32e>) chore(git-command-helper): update subproject commit reference
- [ _2025-07-20 19:10:50_ ] [c4e0b30](<https://github.com/dimaslanjaka/bin/commit/c4e0b30>)
    
    feat(changelog): add custom script to generate changelog from git history
    
    - Parses git logs to group commits by semantic version tags
    - Skips irrelevant commits (e.g. dependabot, build, merge)
    - Outputs formatted markdown to CHANGELOG.md
    - Supports CLI usage with --help/-h flags
    - Saves raw log output to tmp/original.md for reference
- [ _2025-07-20 19:11:35_ ] [26e2a21](<https://github.com/dimaslanjaka/bin/commit/26e2a21>)
    
    test(tarball): enhance tarball validation with binary CLI checks
    
    - Renamed test suite to clarify scope
    - Added `validateBinaries()` to check `npx` execution of key CLI tools:
      - git-diff
      - pkg-resolutions-updater
      - changelog
    - Extended timeout for npm/yarn installation tests to 2 minutes
    - Improved readability in `prepareInstallation()` by adding brackets
- [ _2025-07-20 19:13:50_ ] [88aa58d](<https://github.com/dimaslanjaka/bin/commit/88aa58d>)
    
    ci(build): improve build steps with named actions and push condition
    
    - Added descriptive names to steps: install, build, pack, test
    - Added `success()` check to push condition to avoid pushing on failed jobs
- [ _2025-07-20 19:15:14_ ] [a78366a](<https://github.com/dimaslanjaka/bin/commit/a78366a>) chore(clean-caches): comment out submodule update steps in workflow
- [ _2025-07-20 19:16:09_ ] [f02d420](<https://github.com/dimaslanjaka/bin/commit/f02d420>) feat(workflow): add workflow to delete old workflow runs with customizable options
### 2.0.2

- [ _2023-09-09 09:44:35_ ] [b6da66d](<https://github.com/dimaslanjaka/bin/commit/b6da66d>) add linter
- [ _2023-10-13 17:45:40_ ] [95a7eb3](<https://github.com/dimaslanjaka/bin/commit/95a7eb3>) Create submodule-token
- [ _2024-01-30 03:04:13_ ] [ba95ff4](<https://github.com/dimaslanjaka/bin/commit/ba95ff4>) using `killall`
- [ _2024-02-02 20:34:51_ ] [c8c154c](<https://github.com/dimaslanjaka/bin/commit/c8c154c>) update dependencies
- [ _2024-02-02 20:35:33_ ] [b91ec54](<https://github.com/dimaslanjaka/bin/commit/b91ec54>) change license to MIT
- [ _2024-02-02 20:56:18_ ] [cbc8201](<https://github.com/dimaslanjaka/bin/commit/cbc8201>) initialize ESLint
- [ _2024-02-02 21:16:12_ ] [1c5c8dd](<https://github.com/dimaslanjaka/bin/commit/1c5c8dd>) install `sbg-utility`
- [ _2024-02-02 21:18:28_ ] [8d99a7b](<https://github.com/dimaslanjaka/bin/commit/8d99a7b>) add node_modules cleaner nodejs
### 2.0.0

- [ _2023-09-09 09:13:52_ ] [9f58a31](<https://github.com/dimaslanjaka/bin/commit/9f58a31>)
    
    fix: remove shebang lines with arguments
    fail on non-BSD platform
- [ _2023-09-09 09:14:33_ ] [8f09786](<https://github.com/dimaslanjaka/bin/commit/8f09786>)
    
    chore: bump v2.0.1
    - remove shebang lines with arguments
       fail on non-BSD platform
### 0.0.0

- [ _2023-04-18 22:10:01_ ] [3d0dd55](<https://github.com/dimaslanjaka/bin/commit/3d0dd55>) Create header
- [ _2023-04-18 22:10:38_ ] [7cd82d9](<https://github.com/dimaslanjaka/bin/commit/7cd82d9>) Create rmpath
- [ _2023-04-22 17:53:21_ ] [8ddc9c3](<https://github.com/dimaslanjaka/bin/commit/8ddc9c3>) feat: add more initial codes
- [ _2023-04-22 18:17:36_ ] [addfe71](<https://github.com/dimaslanjaka/bin/commit/addfe71>) docs: add docs
- [ _2023-04-22 18:17:52_ ] [2cd7040](<https://github.com/dimaslanjaka/bin/commit/2cd7040>) feat: add hexo git management
- [ _2023-04-22 18:19:55_ ] [9cbf402](<https://github.com/dimaslanjaka/bin/commit/9cbf402>) chore: update header
- [ _2023-04-22 18:20:26_ ] [7fec603](<https://github.com/dimaslanjaka/bin/commit/7fec603>) docs: update
- [ _2023-04-22 18:58:49_ ] [fe43b2f](<https://github.com/dimaslanjaka/bin/commit/fe43b2f>) feat: add hexo-asset-link
- [ _2023-04-22 18:59:29_ ] [e51ccc0](<https://github.com/dimaslanjaka/bin/commit/e51ccc0>) feat: remove non-related bin
- [ _2023-04-22 19:05:20_ ] [654aedf](<https://github.com/dimaslanjaka/bin/commit/654aedf>) feat: add common nodejs binary helper
- [ _2023-04-22 19:18:12_ ] [96a0351](<https://github.com/dimaslanjaka/bin/commit/96a0351>) chore: update headers
- [ _2023-04-24 02:51:18_ ] [943e393](<https://github.com/dimaslanjaka/bin/commit/943e393>) feat: add git repository size reducer
- [ _2023-04-24 22:43:00_ ] [8e80d39](<https://github.com/dimaslanjaka/bin/commit/8e80d39>)
    
    feat: add bin
    
    - add node processes killer
    - add file truncater
- [ _2023-04-24 23:00:48_ ] [d04af54](<https://github.com/dimaslanjaka/bin/commit/d04af54>) feat: add bundler
- [ _2023-04-24 23:06:33_ ] [c5db582](<https://github.com/dimaslanjaka/bin/commit/c5db582>) feat: ignore non tarball in releases
- [ _2023-04-24 23:09:39_ ] [78b29a0](<https://github.com/dimaslanjaka/bin/commit/78b29a0>) feat: ignore releases folder
- [ _2023-04-24 23:12:26_ ] [90ab437](<https://github.com/dimaslanjaka/bin/commit/90ab437>) docs: add installation
- [ _2023-04-26 15:56:23_ ] [2e5e283](<https://github.com/dimaslanjaka/bin/commit/2e5e283>) docs: update
- [ _2023-04-26 16:02:28_ ] [7fc0f0b](<https://github.com/dimaslanjaka/bin/commit/7fc0f0b>) chore: delete single file first
- [ _2023-04-26 16:54:00_ ] [d287d95](<https://github.com/dimaslanjaka/bin/commit/d287d95>) Create git-fix-encoding.cmd
- [ _2023-04-26 16:55:14_ ] [4329545](<https://github.com/dimaslanjaka/bin/commit/4329545>) Update git-fix-encoding.cmd
- [ _2023-04-26 16:55:55_ ] [bcef941](<https://github.com/dimaslanjaka/bin/commit/bcef941>) Create git-fix-encoding
- [ _2023-04-26 16:56:45_ ] [171fd21](<https://github.com/dimaslanjaka/bin/commit/171fd21>) register git-fix-encoding
- [ _2023-04-27 23:53:00_ ] [281b3a7](<https://github.com/dimaslanjaka/bin/commit/281b3a7>) feat: add rmfind
- [ _2023-04-27 23:53:49_ ] [6046421](<https://github.com/dimaslanjaka/bin/commit/6046421>) feat: add empty line end of line
- [ _2023-04-29 02:56:54_ ] [b0e173f](<https://github.com/dimaslanjaka/bin/commit/b0e173f>) feat: import yarn config
- [ _2023-04-29 02:57:13_ ] [8dde6f1](<https://github.com/dimaslanjaka/bin/commit/8dde6f1>) chore: update bin and script build
- [ _2023-04-29 02:57:24_ ] [6791beb](<https://github.com/dimaslanjaka/bin/commit/6791beb>) feat: add kill-process
- [ _2023-04-29 02:57:51_ ] [c091261](<https://github.com/dimaslanjaka/bin/commit/c091261>) chore: fallback to kill-process
- [ _2023-04-30 18:38:38_ ] [c711628](<https://github.com/dimaslanjaka/bin/commit/c711628>) fix: ignore nested auto generated files
- [ _2023-04-30 18:48:13_ ] [a587371](<https://github.com/dimaslanjaka/bin/commit/a587371>) feat: add tester
- [ _2023-04-30 18:49:06_ ] [27746f6](<https://github.com/dimaslanjaka/bin/commit/27746f6>) chore: register new bin
- [ _2023-04-30 19:06:59_ ] [b18211c](<https://github.com/dimaslanjaka/bin/commit/b18211c>) chore(deps): add yargs
- [ _2023-04-30 19:21:24_ ] [1fb6fa8](<https://github.com/dimaslanjaka/bin/commit/1fb6fa8>) chore: rename build script
- [ _2023-04-30 19:21:58_ ] [32b2f8f](<https://github.com/dimaslanjaka/bin/commit/32b2f8f>) chore(deps): update
- [ _2023-04-30 19:28:00_ ] [e49be22](<https://github.com/dimaslanjaka/bin/commit/e49be22>) feat: import vscode settings
- [ _2023-04-30 19:40:36_ ] [7b39f06](<https://github.com/dimaslanjaka/bin/commit/7b39f06>) refactor: move all binary to bin
- [ _2023-04-30 19:45:21_ ] [8943674](<https://github.com/dimaslanjaka/bin/commit/8943674>) hotfix binary name
- [ _2023-04-30 19:46:34_ ] [ebf2791](<https://github.com/dimaslanjaka/bin/commit/ebf2791>) chore: restore bin
- [ _2023-04-30 19:48:35_ ] [a4bbc1d](<https://github.com/dimaslanjaka/bin/commit/a4bbc1d>) chore: ignore index test
- [ _2023-04-30 19:55:11_ ] [a039304](<https://github.com/dimaslanjaka/bin/commit/a039304>) chore: add minimist
- [ _2023-04-30 20:37:39_ ] [fd4cb7b](<https://github.com/dimaslanjaka/bin/commit/fd4cb7b>) chore: hotfix npm-run-series
- [ _2023-04-30 21:10:29_ ] [906480d](<https://github.com/dimaslanjaka/bin/commit/906480d>) docs: update
- [ _2023-04-30 21:15:29_ ] [91513ff](<https://github.com/dimaslanjaka/bin/commit/91513ff>) chore: rename bin to bash
- [ _2023-04-30 21:25:57_ ] [80340cb](<https://github.com/dimaslanjaka/bin/commit/80340cb>) chore: rename back bin
- [ _2023-04-30 21:27:07_ ] [f1cb0db](<https://github.com/dimaslanjaka/bin/commit/f1cb0db>) chore(script): update test
- [ _2023-04-30 21:29:50_ ] [79dcc93](<https://github.com/dimaslanjaka/bin/commit/79dcc93>) chore: force unix path serparator
- [ _2023-04-30 22:19:36_ ] [5c4eaad](<https://github.com/dimaslanjaka/bin/commit/5c4eaad>) refactor: using classic yarn
- [ _2023-04-30 22:48:29_ ] [e334400](<https://github.com/dimaslanjaka/bin/commit/e334400>) refactor: update packer
- [ _2023-04-30 22:50:05_ ] [5a8a6d8](<https://github.com/dimaslanjaka/bin/commit/5a8a6d8>) refactor: update packer
- [ _2023-04-30 22:52:28_ ] [10c428c](<https://github.com/dimaslanjaka/bin/commit/10c428c>) refactor: index lock file
- [ _2023-04-30 22:55:56_ ] [8cc63b9](<https://github.com/dimaslanjaka/bin/commit/8cc63b9>) Update package.json
- [ _2023-04-30 22:57:29_ ] [c846b91](<https://github.com/dimaslanjaka/bin/commit/c846b91>) refactor: filter only file
- [ _2023-04-30 23:04:30_ ] [f04c0d6](<https://github.com/dimaslanjaka/bin/commit/f04c0d6>) refactor: fix build script
- [ _2023-05-01 19:55:32_ ] [c6c3218](<https://github.com/dimaslanjaka/bin/commit/c6c3218>) refactor: using stable yarn
- [ _2023-05-01 21:06:56_ ] [43b55d1](<https://github.com/dimaslanjaka/bin/commit/43b55d1>) docs: update installation
- [ _2023-05-02 14:32:07_ ] [bb319b3](<https://github.com/dimaslanjaka/bin/commit/bb319b3>) refactor: update yarn
- [ _2023-05-02 14:33:54_ ] [8035247](<https://github.com/dimaslanjaka/bin/commit/8035247>) docs: add usages
- [ _2023-05-02 14:34:11_ ] [8e86164](<https://github.com/dimaslanjaka/bin/commit/8e86164>) chore: bump v1.0.2
- [ _2023-05-04 17:45:18_ ] [ff4b292](<https://github.com/dimaslanjaka/bin/commit/ff4b292>) Update readme.md
- [ _2023-05-04 17:46:12_ ] [aa06d5e](<https://github.com/dimaslanjaka/bin/commit/aa06d5e>) docs: update troubleshooting
- [ _2023-05-04 18:14:23_ ] [8767a3b](<https://github.com/dimaslanjaka/bin/commit/8767a3b>) docs: update docs
- [ _2023-05-04 19:01:31_ ] [898fb0f](<https://github.com/dimaslanjaka/bin/commit/898fb0f>) docs: update docs
- [ _2023-05-04 19:03:34_ ] [46ed6ff](<https://github.com/dimaslanjaka/bin/commit/46ed6ff>)
    
    chore: bump v1.0.3
    
    - add `-yarn` arg to run script with yarn
- [ _2023-05-04 19:07:28_ ] [a902908](<https://github.com/dimaslanjaka/bin/commit/a902908>)
    
    chore: bump v1.0.4
    feat: add `-yarn` arg to run script with yarn
    refactor: run `yarn install` after build
    feat(deps): add `cross-spawn`
- [ _2023-05-04 19:09:39_ ] [4d30469](<https://github.com/dimaslanjaka/bin/commit/4d30469>) feat(prop): add directories
- [ _2023-05-09 03:05:14_ ] [68f1770](<https://github.com/dimaslanjaka/bin/commit/68f1770>) docs: add `\"`
- [ _2023-07-19 12:00:18_ ] [200ef81](<https://github.com/dimaslanjaka/bin/commit/200ef81>) refactor: update packer
- [ _2023-07-19 12:02:02_ ] [7e0df48](<https://github.com/dimaslanjaka/bin/commit/7e0df48>) chore(deps): moved cross-spawn to production
- [ _2023-07-19 12:26:07_ ] [aa545e0](<https://github.com/dimaslanjaka/bin/commit/aa545e0>) chore(deps): install git-command-helper
- [ _2023-07-19 12:26:52_ ] [c191360](<https://github.com/dimaslanjaka/bin/commit/c191360>) chore(deps): install yaml
- [ _2023-07-19 12:28:08_ ] [1cc19c5](<https://github.com/dimaslanjaka/bin/commit/1cc19c5>) refactor: update yarn
- [ _2023-07-19 16:28:29_ ] [121d68f](<https://github.com/dimaslanjaka/bin/commit/121d68f>) refactor: rollback packer
- [ _2023-08-13 06:52:12_ ] [1e43c28](<https://github.com/dimaslanjaka/bin/commit/1e43c28>) feat: add java killer
- [ _2023-08-24 17:55:34_ ] [afe082f](<https://github.com/dimaslanjaka/bin/commit/afe082f>) Update header
- [ _2023-08-25 18:31:33_ ] [8a284b9](<https://github.com/dimaslanjaka/bin/commit/8a284b9>) Update header
- [ _2023-08-26 07:34:02_ ] [b6fd6f5](<https://github.com/dimaslanjaka/bin/commit/b6fd6f5>) try fix bad subtitution
- [ _2023-08-26 07:34:55_ ] [56f4e61](<https://github.com/dimaslanjaka/bin/commit/56f4e61>) update header
- [ _2023-09-03 23:10:52_ ] [c0534e9](<https://github.com/dimaslanjaka/bin/commit/c0534e9>) feat: rm path recursive smarter
- [ _2023-09-04 05:08:06_ ] [91d0dfd](<https://github.com/dimaslanjaka/bin/commit/91d0dfd>) Update rmx
- [ _2023-09-06 06:26:14_ ] [ff06bcc](<https://github.com/dimaslanjaka/bin/commit/ff06bcc>) add dotenv parser
- [ _2023-09-06 06:33:47_ ] [566502d](<https://github.com/dimaslanjaka/bin/commit/566502d>)
    
    Create submodule
    
    alias submodule-install submodule-remove with extended features
- [ _2023-09-06 06:37:26_ ] [c28705e](<https://github.com/dimaslanjaka/bin/commit/c28705e>) Create build.yml
- [ _2023-09-06 06:38:32_ ] [47828db](<https://github.com/dimaslanjaka/bin/commit/47828db>) Update build.yml
- [ _2023-09-06 06:40:53_ ] [481fceb](<https://github.com/dimaslanjaka/bin/commit/481fceb>) Update build.yml
- [ _2023-09-06 06:41:40_ ] [b829785](<https://github.com/dimaslanjaka/bin/commit/b829785>) Update package.json
- [ _2023-09-06 06:44:04_ ] [47d41be](<https://github.com/dimaslanjaka/bin/commit/47d41be>) Update build.yml
- [ _2023-09-06 06:45:34_ ] [7faa490](<https://github.com/dimaslanjaka/bin/commit/7faa490>) fixed missing user email
- [ _2023-09-06 06:47:33_ ] [f2b7667](<https://github.com/dimaslanjaka/bin/commit/f2b7667>) add cache
- [ _2023-09-06 06:50:28_ ] [fd9f534](<https://github.com/dimaslanjaka/bin/commit/fd9f534>) add token
- [ _2023-09-09 06:08:37_ ] [c908f42](<https://github.com/dimaslanjaka/bin/commit/c908f42>) update headers
- [ _2023-09-09 06:25:32_ ] [c200c12](<https://github.com/dimaslanjaka/bin/commit/c200c12>) pass cli args into function params
- [ _2023-09-09 06:26:15_ ] [4f099f2](<https://github.com/dimaslanjaka/bin/commit/4f099f2>) add subcommand remove
- [ _2023-09-09 06:29:51_ ] [0851bb8](<https://github.com/dimaslanjaka/bin/commit/0851bb8>) install `ts-node typescript dotenv`
- [ _2023-09-09 06:30:36_ ] [6049399](<https://github.com/dimaslanjaka/bin/commit/6049399>) ignore lock files
- [ _2023-09-09 06:37:04_ ] [4f96179](<https://github.com/dimaslanjaka/bin/commit/4f96179>) check parameter is defined or empty
- [ _2023-09-09 06:37:51_ ] [f985260](<https://github.com/dimaslanjaka/bin/commit/f985260>) cache node_modules
- [ _2023-09-09 06:56:22_ ] [78a3525](<https://github.com/dimaslanjaka/bin/commit/78a3525>) add test bin
- [ _2023-09-09 07:03:27_ ] [b325d37](<https://github.com/dimaslanjaka/bin/commit/b325d37>) ignore bash-dummy
- [ _2023-09-09 07:03:51_ ] [1334da4](<https://github.com/dimaslanjaka/bin/commit/1334da4>) update pattern bash-dummy
- [ _2023-09-09 07:13:16_ ] [b56849a](<https://github.com/dimaslanjaka/bin/commit/b56849a>) fix: missing `-r` argument
- [ _2023-09-09 07:15:54_ ] [2d9cae3](<https://github.com/dimaslanjaka/bin/commit/2d9cae3>) update ignores
- [ _2023-09-09 07:17:31_ ] [9a6fa13](<https://github.com/dimaslanjaka/bin/commit/9a6fa13>) force unix separator
- [ _2023-09-09 07:18:00_ ] [3ef4ae1](<https://github.com/dimaslanjaka/bin/commit/3ef4ae1>) validate resolve is file
- [ _2023-09-09 07:19:27_ ] [857e3df](<https://github.com/dimaslanjaka/bin/commit/857e3df>) disable yarn install
- [ _2023-09-09 07:19:40_ ] [7402499](<https://github.com/dimaslanjaka/bin/commit/7402499>) update bin
- [ _2023-09-09 07:34:00_ ] [215aa35](<https://github.com/dimaslanjaka/bin/commit/215aa35>) sort orders
- [ _2023-09-09 07:37:49_ ] [e1acb55](<https://github.com/dimaslanjaka/bin/commit/e1acb55>) replace dots with hypen