@echo off
setlocal enabledelayedexpansion

set "NODE_OPTIONS=--max-old-space-size=6048 --expose-gc --max-semi-space-size=512"
set "NODE_ENV=production"

REM --- Yarn env settings not covered by .yarnrc.yml ---
REM NOTE: never name your own variables YARN_* (Yarn reads them as config)
set "YARN_ENABLE_TELEMETRY=0"
set "YARN_ENABLE_PROGRESS_BARS=false"
set "COREPACK_ENABLE_DOWNLOAD_PROMPT=0"

set "NPM_ROOT=%TEMP%\npm"
set "PKG_DIR=%NPM_ROOT%\node_modules\omniroute"
set "VERSION_FILE=%NPM_ROOT%\omniroute.version"
set "FLAVOR_FILE=%NPM_ROOT%\omniroute-flavor.txt"
set "FLAVOR=prod"

REM --- Parse custom parameters (stripped before forwarding) ---
set "FORCE_REINSTALL=0"
set "PASS_ARGS="

:parse_args
if "%~1"=="" goto args_done
if /i "%~1"=="--reinstall" (
    set "FORCE_REINSTALL=1"
) else (
    set PASS_ARGS=!PASS_ARGS! %1
)
shift
goto parse_args
:args_done

if not exist "%NPM_ROOT%" mkdir "%NPM_ROOT%"

REM --- Fetch latest metadata ---
set "REMOTE_VERSION="
set "REMOTE_URL="

for /f "usebackq tokens=1,2 delims=|" %%a in (`powershell -NoProfile -Command "try { $j = Invoke-RestMethod -Uri 'https://registry.npmjs.org/omniroute/latest' -TimeoutSec 15; Write-Output ($j.version + [char]124 + $j.dist.tarball) } catch { }"`) do (
    set "REMOTE_VERSION=%%a"
    set "REMOTE_URL=%%b"
)

if not defined REMOTE_VERSION (
    echo [yarn] Failed to fetch registry metadata
    exit /b 1
)
if not defined REMOTE_URL (
    echo [yarn] Registry returned no tarball URL
    exit /b 1
)

set "TARBALL_NAME=omniroute-!REMOTE_VERSION!.tgz"
set "TARBALL=%NPM_ROOT%\!TARBALL_NAME!"

echo [yarn] Latest version: !REMOTE_VERSION!

REM --- Check cache ---
set "NEED_SETUP=1"
set "LOCAL_VERSION="
set "STORED_FLAVOR="

if "!FORCE_REINSTALL!"=="1" (
    echo [yarn] --reinstall specified, forcing full reinstall.
) else if exist "!VERSION_FILE!" (
    for /f "usebackq delims=" %%a in ("!VERSION_FILE!") do set "LOCAL_VERSION=%%a"
    if "!LOCAL_VERSION!"=="!REMOTE_VERSION!" (
        if exist "!PKG_DIR!\package.json" (
            echo [yarn] Cached version valid, skipping setup.
            set "NEED_SETUP=0"
        ) else (
            echo [yarn] Cache incomplete, re-setup required.
        )
    ) else (
        echo [yarn] Version changed: !LOCAL_VERSION! to !REMOTE_VERSION!
    )
) else (
    echo [yarn] No version file found
)

REM --- Check flavor ---
if exist "!FLAVOR_FILE!" (
    for /f "usebackq delims=" %%b in ("!FLAVOR_FILE!") do set "STORED_FLAVOR=%%b"
    if not "!STORED_FLAVOR!"=="!FLAVOR!" (
        echo [yarn] Flavor changed from !STORED_FLAVOR! to !FLAVOR!, forcing rebuild.
        set "NEED_SETUP=1"
    )
) else (
    echo [yarn] No flavor file found, forcing rebuild.
    set "NEED_SETUP=1"
)

if "!NEED_SETUP!"=="1" (
    REM --- Remove cached tarball when reinstalling so it is re-downloaded ---
    if "!FORCE_REINSTALL!"=="1" (
        if exist "!TARBALL!" (
            echo [yarn] Removing cached tarball...
            del /f /q "!TARBALL!" 2>nul
        )
    )

    echo [yarn] Downloading tarball...
    curl -fL "!REMOTE_URL!" -o "!TARBALL!.tmp"
    if errorlevel 1 (
        del "!TARBALL!.tmp" 2>nul
        exit /b 1
    )
    move /y "!TARBALL!.tmp" "!TARBALL!" >nul

    pushd "%NPM_ROOT%"

    REM --- Clean leftovers from npm / previous yarn state on reinstall ---
    if "!FORCE_REINSTALL!"=="1" (
        del /f /q "yarn.lock" 2>nul
        del /f /q "package-lock.json" 2>nul
    )

    if not exist "package.json" (
        echo [yarn] Initializing project...
        > "package.json" echo {"name":"omniroute-runner","private":true}
    )

    REM --- Write .yarnrc.yml ---
    echo [yarn] Writing .yarnrc.yml...
    (
        echo checksumBehavior: update
        echo.
        echo compressionLevel: mixed
        echo.
        echo enableGlobalCache: true
        echo.
        echo enableImmutableInstalls: false
        echo.
        echo enableInlineBuilds: true
        echo.
        echo enableScripts: true
        echo.
        echo enableTransparentWorkspaces: true
        echo.
        echo nmHoistingLimits: workspaces
        echo.
        echo nmMode: hardlinks-local
        echo.
        echo nmSelfReferences: true
        echo.
        echo nodeLinker: node-modules
    ) > ".yarnrc.yml"

    REM --- Empty yarn.lock marks this folder as its own Yarn project root ---
    if not exist "yarn.lock" type nul > "yarn.lock"

    REM --- Make sure Yarn Berry (2+) is used for this project ---
    set "BERRY_VERSION="
    for /f "usebackq delims=" %%v in (`yarn --version 2^>nul`) do set "BERRY_VERSION=%%v"

    if not defined BERRY_VERSION (
        popd
        echo [yarn] yarn not found in PATH. Try: corepack enable
        exit /b 1
    )

    set "BERRY_MAJOR=0"
    for /f "tokens=1 delims=." %%a in ("!BERRY_VERSION!") do set "BERRY_MAJOR=%%a"

    if !BERRY_MAJOR! LSS 2 (
        echo [yarn] Found Yarn !BERRY_VERSION!, switching project to Yarn stable...
        call yarn set version stable
        if errorlevel 1 (
            popd
            echo [yarn] yarn set version failed
            exit /b 1
        )
    )

    for /f "usebackq delims=" %%v in (`yarn --version 2^>nul`) do set "BERRY_VERSION=%%v"
    echo [yarn] yarn version: !BERRY_VERSION!

    echo [yarn] Cleaning up old omniroute installation...
    if exist "node_modules\omniroute" rmdir /s /q "node_modules\omniroute" 2>nul
    if exist "node_modules\.bin\omniroute" del /f /q "node_modules\.bin\omniroute" 2>nul
    if exist "node_modules\.bin\omniroute.cmd" del /f /q "node_modules\.bin\omniroute.cmd" 2>nul

    echo [yarn] Installing omniroute...
    call yarn add "omniroute@file:./!TARBALL_NAME!"
    if errorlevel 1 (
        popd
        echo [yarn] Install failed
        exit /b 1
    )

    echo [yarn] Rebuilding native modules...
    call yarn rebuild better-sqlite3
    if errorlevel 1 (
        echo [yarn] Warning: rebuild of better-sqlite3 failed or was not needed, continuing.
    )

    popd

    <nul set /p "=!FLAVOR!" > "!FLAVOR_FILE!"
    echo.>> "!FLAVOR_FILE!"
    <nul set /p "=!REMOTE_VERSION!" > "!VERSION_FILE!"
    echo.>> "!VERSION_FILE!"
    echo [yarn] Setup complete.
)

REM --- Resolve entry point ---
set "ENTRY="
set "ENTRY_REL="

pushd "%PKG_DIR%"
for /f "usebackq tokens=*" %%i in (`node -p "const p=require('./package.json'); typeof p.bin==='string'?p.bin:(p.bin?Object.values(p.bin)[0]:'')"`) do (
    set "ENTRY_REL=%%i"
)
popd

if defined ENTRY_REL (
    set "ENTRY=!PKG_DIR!\!ENTRY_REL!"
)

if not defined ENTRY (
    if exist "!PKG_DIR!\bin\omniroute.mjs" set "ENTRY=!PKG_DIR!\bin\omniroute.mjs"
    if exist "!PKG_DIR!\bin\omniroute.js" set "ENTRY=!PKG_DIR!\bin\omniroute.js"
    if exist "!PKG_DIR!\dist\index.js" set "ENTRY=!PKG_DIR!\dist\index.js"
    if exist "!PKG_DIR!\dist\cli.js" set "ENTRY=!PKG_DIR!\dist\cli.js"
)

if not defined ENTRY (
    echo [yarn] Entry point not found.
    exit /b 1
)

node "!ENTRY!"!PASS_ARGS!