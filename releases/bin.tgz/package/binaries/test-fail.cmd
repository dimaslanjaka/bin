@echo off

npm test -- test/git-diff.test.cjs --detectOpenHandles