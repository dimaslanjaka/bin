/**
 * Get the base temporary directory path
 * Can be overridden via TEMP_DIR environment variable
 * @returns {string} The base temporary directory path
 */
declare function getTempDir(): string;
/**
 * Get a temporary file or directory path
 * @param {...string} segments - Path segments to join with the temp directory
 * @returns {string} The full temporary path
 */
declare function getTempPath(...segments: string[]): string;
/**
 * Legacy aliases for backward compatibility
 */
declare const TEMP_BASE_DIR: string;

export { TEMP_BASE_DIR, getTempDir, getTempPath };
