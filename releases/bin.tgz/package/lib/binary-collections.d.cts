#!/usr/bin/env node
export default module.exports;
declare namespace exports {
    export { exports as default };
}
declare namespace module { }
