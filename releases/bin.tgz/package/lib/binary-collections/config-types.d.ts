export interface KeyData {
    name: string;
    key: string;
}
export interface BinaryCollectionsConfig {
    tempDir?: string;
    githubToken?: string;
    opencode?: {
        keys: KeyData[];
    };
    nvidia?: {
        keys: KeyData[];
    };
}
