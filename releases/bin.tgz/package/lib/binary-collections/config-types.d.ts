export interface OpencodeKey {
    name: string;
    key: string;
}
export interface BinaryCollectionsConfig {
    tempDir?: string;
    githubToken?: string;
    opencode?: {
        keys: OpencodeKey[];
    };
}
