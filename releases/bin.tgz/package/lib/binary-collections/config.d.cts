/**
 * Get a temporary file or directory path
 * @param {...string} segments - Path segments to join with the temp directory
 * @returns {string} The full temporary path
 */
export function getTempPath(...segments: string[]): string;
export const GITHUB_ACCESS_TOKEN: any;
/**
 * Load .env file containing a token variable.
 * Searches for `.env*` files and picks the first one matching the given token key.
 *
 * @param {string|RegExp} [tokenKey=/ACCESS_TOKEN|GITHUB_TOKEN/] - Token name or regex to search for.
 *   Passed as second argument to `findEnvWithToken()`.
 * @returns {import('dotenv').DotenvConfigOutput}
 */
export function loadDotenv(tokenKey?: string | RegExp): import("dotenv").DotenvConfigOutput;
/**
 * Search for project configuration using cosmiconfig.
 *
 * Only these files are supported:
 * - `binary-collections.config.js`
 * - `binary-collections.config.cjs`
 * - `binary-collections.config.mjs`
 *
 * No `.rc`, JSON, YAML, or `package.json` config is supported.
 *
 * @param {object} [options] - Optional configuration overrides.
 * @param {string} [options.searchFrom] - Directory to start searching from.
 * @param {string} [options.stopDir] - Directory to stop searching upwards.
 * @returns {Promise<import('./config-types').BinaryCollectionsConfig|null>}
 */
export function getConfig(options?: {
    searchFrom?: string;
    stopDir?: string;
}): Promise<import("./config-types").BinaryCollectionsConfig | null>;
