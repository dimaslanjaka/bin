/**
 * Get a temporary file or directory path
 * @param {...string} segments - Path segments to join with the temp directory
 * @returns {string} The full temporary path
 */
export function getTempPath(...segments: string[]): string;
export const GITHUB_ACCESS_TOKEN: any;
/**
 * Load .env file containing a token variable.
 * Searches for `.env*` files and picks the first one matching the given token key.
 *
 * @param {string|RegExp} [tokenKey=/ACCESS_TOKEN|GITHUB_TOKEN/] - Token name or regex to search for.
 *   Passed as second argument to `findEnvWithToken()`.
 * @returns {void}
 */
export function loadDotenv(tokenKey?: string | RegExp): void;
/**
 * Search for project configuration using cosmiconfig (async).
 *
 * Only `binary-collections.config.js` / `.cjs` / `.mjs` are supported (no `.rc`, JSON, or YAML).
 *
 * Looks for configuration in:
 * - `binary-collections.config.js` / `.cjs` / `.mjs` (searched from project root upward)
 * - A `binary-collections` property in `package.json`
 *
 * @param {object} [options] - Optional configuration overrides.
 * @param {string} [options.searchFrom] - Directory to start searching from (default: process.cwd()).
 * @param {string} [options.stopDir] - Directory to stop searching upwards (e.g., project root).
 * @returns {Promise<import('./config-types').BinaryCollectionsConfig|null>} The parsed configuration object, or `null` if no config found.
 */
export function getConfig(options?: {
    searchFrom?: string;
    stopDir?: string;
}): Promise<import("./config-types").BinaryCollectionsConfig | null>;
