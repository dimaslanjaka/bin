/**
 * Get the base temporary directory path
 * Can be overridden via TEMP_DIR environment variable
 * @returns {string} The base temporary directory path
 */
export function getTempDir(): string;
/**
 * Get a temporary file or directory path
 * @param {...string} segments - Path segments to join with the temp directory
 * @returns {string} The full temporary path
 */
export function getTempPath(...segments: string[]): string;
/**
 * Legacy aliases for backward compatibility
 */
export const TEMP_BASE_DIR: string;
export const GITHUB_ACCESS_TOKEN: any;
/**
 * Load .env file containing a token variable.
 * Searches for `.env*` files and picks the first one matching the given token key.
 *
 * @param {string|RegExp} [tokenKey=/ACCESS_TOKEN|GITHUB_TOKEN/] - Token name or regex to search for.
 *   Passed as second argument to `findEnvWithToken()`.
 * @returns {void}
 */
export function loadDotenv(tokenKey?: string | RegExp): void;
