export default module.exports;
/**
 * Get a temporary file or directory path under the project's temp directory.
 * Does NOT create the directory — the caller is responsible for that.
 *
 * @param {...string} segments - Path segments to join with the temp root.
 * @returns {string} The full temporary path rooted at `TEMP_DIR` env var or `<cwd>/tmp`.
 */
export function getTempPath(...segments: string[]): string;
/**
 * Get GitHub access token from CLI args, config file, or environment variables.
 * Checks --token CLI argument, then config `githubToken`, then ACCESS_TOKEN, GITHUB_TOKEN, GH_TOKEN env vars.
 * @returns {Promise<string|undefined>}
 */
export function getGithubToken(): Promise<string | undefined>;
/**
 * Load .env file containing a token variable.
 * Searches for `.env*` files and picks the first one matching the given token key.
 *
 * @param {string|RegExp} [tokenKey=/ACCESS_TOKEN|GITHUB_TOKEN/] - Token name or regex to search for.
 *   Passed as second argument to `findEnvWithToken()`.
 * @returns {import('dotenv').DotenvConfigOutput}
 */
export function loadDotenv(tokenKey?: string | RegExp): import("dotenv").DotenvConfigOutput;
/**
 * Search for project configuration using cosmiconfig.
 *
 * By default looks for these files:
 * - `binary-collections.config.js`
 * - `binary-collections.config.cjs`
 * - `binary-collections.config.mjs`
 *
 * No `.rc`, JSON, YAML, or `package.json` config is supported.
 *
 * @param {object} [options] - Optional configuration overrides.
 * @param {string} [options.optionName] - Override the cosmiconfig module name ('binary-collections' by default).
 *   When set, searchPlaces are generated as `{optionName}.config.{js,cjs,mjs}`.
 * @param {string} [options.searchFrom] - Directory to start searching from.
 * @param {string} [options.stopDir] - Directory to stop searching upwards.
 * @returns {Promise<import('./config-types').BinaryCollectionsConfig|null>}
 */
export function getConfig(options?: {
    optionName?: string;
    searchFrom?: string;
    stopDir?: string;
}): Promise<import("./config-types").BinaryCollectionsConfig | null>;
/**
 * Create a unique temporary directory and return its path.
 * Creates the directory immediately via `fs.mkdtempSync`.
 *
 * @param {object} [options] - Optional settings.
 * @param {string} [options.prefix='binary-collections-'] - Prefix for the directory name.
 * @param {boolean} [options.global=false] - Use OS temp dir instead of project temp root.
 * @returns {string} Absolute path to the newly created temp directory.
 */
export function makeTempDir(options?: {
    prefix?: string;
    global?: boolean;
}): string;
declare namespace exports {
    export { getTempPath, getGithubToken, loadDotenv, getConfig, makeTempDir, exports as default };
}
declare namespace module { }
