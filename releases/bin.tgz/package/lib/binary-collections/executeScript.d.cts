export = executeScript;
/**
 * Executes a script file using Node.js with the provided arguments
 * @function executeScript
 * @param {string} scriptPath - The absolute path to the script file to execute
 * @param {string[]} args - Array of arguments to pass to the script
 * @returns {void} Exits the process when the script execution completes
 */
declare function executeScript(scriptPath: string, args: string[]): void;
declare namespace executeScript {
    export { executeScript as default };
}
