export = findScript;
/**
 * Searches for a script file by name in the specified directory
 * @function findScript
 * @param {string} scriptName - The name of the script to find (without extension)
 * @param {string|null} [searchDir=null] - The directory to search in. Defaults to the parent `src` directory when not provided
 * @returns {string|undefined} The absolute path to the found script file, or undefined if not found
 */
declare function findScript(scriptName: string, searchDir?: string | null): string | undefined;
declare namespace findScript {
    export { findScript as default };
}
