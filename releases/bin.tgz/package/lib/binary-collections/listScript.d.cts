export = listScript;
/**
 * Locates binary scripts defined in package.json and verifies their existence on the filesystem.
 *
 * @param {boolean} [verbose=false] - If true, logs the search process and found paths to the console.
 * @returns {Array<{name: string, path: string, absolutePath: string}>}
 *   An array of objects containing:
 *   - `name`: The script name (key from `pkgJson.bin`).
 *   - `path`: The path relative to the current working directory.
 *   - `absolutePath`: The resolved absolute file system path.
 */
declare function listScript(verbose?: boolean): Array<{
    name: string;
    path: string;
    absolutePath: string;
}>;
declare namespace listScript {
    export { listScript as default };
}
