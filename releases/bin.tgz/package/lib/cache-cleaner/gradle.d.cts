export type GradleProject = {
    /**
     * - Absolute path to the build.gradle file
     */
    gradleFile: string;
    /**
     * - Absolute path to the sibling build/ directory
     */
    buildDir: string;
};
/**
 * Finds all Gradle projects under the given directory by locating build.gradle files.
 *
 * @param {Object} [options] - Optional configuration
 * @param {string} [options.cwd] - Working directory (defaults to process.cwd())
 * @param {string[]} [options.ignore] - Glob patterns to ignore (defaults to node_modules and vendor)
 * @returns {Promise<GradleProject[]>} Resolves with an array of Gradle project info
 */
export function findGradleProjects(options?: {
    cwd?: string;
    ignore?: string[];
}): Promise<GradleProject[]>;
/**
 * Removes the build/ directory for each Gradle project found.
 * Logs each deletion unless `silent` is true.
 *
 * @param {Object} [options] - Optional configuration
 * @param {string} [options.cwd] - Working directory (defaults to process.cwd())
 * @param {string[]} [options.ignore] - Glob patterns to ignore
 * @param {boolean} [options.silent] - Suppress console output (defaults to false)
 * @param {import('fs').RmOptions} [options.delOptions] - Extra options passed to the del utility
 * @returns {Promise<string[]>} Resolves with the list of deleted build directories
 */
export function cleanGradleBuildDirs(options?: {
    cwd?: string;
    ignore?: string[];
    silent?: boolean;
    delOptions?: import("fs").RmOptions;
}): Promise<string[]>;
/**
 * Returns known Gradle cache and temp directories.
 *
 * The primary locations are subdirectories of the Gradle user home (`~/.gradle`):
 * - `caches/` — module artifacts, transformed classes, build scans
 * - `wrapper/dists/` — downloaded Gradle wrapper distributions
 * - `daemon/` — daemon registry and output logs
 * - `native/` — native-platform library extraction
 * - `buildOutputCleanup/` — cache for build output cleanup
 *
 * @param {Object} [options] - Optional configuration
 * @param {string} [options.gradleUserHome] - Custom Gradle user home (defaults to os.homedir() + '/.gradle')
 * @param {boolean} [options.onlyExisting] - Only return directories that currently exist (default false)
 * @returns {Promise<string[]>} Resolves with absolute paths to Gradle cache/temp directories
 */
export function getGradleCacheDirs(options?: {
    gradleUserHome?: string;
    onlyExisting?: boolean;
}): Promise<string[]>;
/**
 * Removes known Gradle cache and temp directories.
 * Each deleted path is logged unless `silent` is true.
 *
 * @param {Object} [options] - Optional configuration
 * @param {string} [options.gradleUserHome] - Custom Gradle user home
 * @param {boolean} [options.silent] - Suppress console output (defaults to false)
 * @param {boolean} [options.onlyExisting] - Only attempt deletion on directories that exist (default false)
 * @returns {Promise<string[]>} Resolves with the list of deleted directories
 */
export function cleanGradleCacheDirs(options?: {
    gradleUserHome?: string;
    silent?: boolean;
    onlyExisting?: boolean;
}): Promise<string[]>;
/**
 * Default Gradle cache/temp subdirectory names (relative to the Gradle user home).
 * These cover the main cache artifacts that can be safely cleaned between builds.
 */
export const GRADLE_CACHE_SUBDIRS: string[];
/**
 * @typedef {Object} GradleProject
 * @property {string} gradleFile - Absolute path to the build.gradle file
 * @property {string} buildDir - Absolute path to the sibling build/ directory
 */
/**
 * Default glob patterns to ignore when searching for build.gradle files.
 */
export const DEFAULT_IGNORE: string[];
