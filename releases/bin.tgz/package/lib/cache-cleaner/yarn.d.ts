export declare function yarnVersion(): Promise<string>;
export declare function cleanYarnCache(): Promise<unknown>;
export interface FindProjectYarnCachesOptions {
    /** Working directory to search from (default: process.cwd()) */
    cwd?: string;
    /** Glob patterns to ignore (default: ['**\u002f.git*', '**\u002fvendor\u002f**']) */
    ignore?: string[];
}
/**
 * Find project-level Yarn cache files/directories.
 * Searches for `.yarn/cache*` directories and `.yarn/*.gz` files
 * (Yarn Berry / Yarn 2+ offline mirror cache).
 */
export declare function findProjectYarnCaches(options?: FindProjectYarnCachesOptions): Promise<string[]>;
/**
 * Delete project-level Yarn cache files/directories.
 * Finds `.yarn/cache*` and `.yarn/*.gz` files, then removes them.
 * @returns The list of deleted paths.
 */
export declare function cleanProjectYarnCaches(options?: FindProjectYarnCachesOptions): Promise<string[]>;
