/**
 * Deletes a GitHub Actions cache.
 *
 * @param {string} GH_REPO - The GitHub repository in the format "owner/repo".
 * @param {string|number} cacheId - The ID of the cache to delete.
 * @returns {Promise<any>} Promise resolving with GitHub API response.
 */
export function deleteGitHubActionsCache(GH_REPO: string, cacheId: string | number): Promise<any>;
/**
 * List GitHub Actions caches grouped by cache key prefix.
 *
 * @param {string} GH_REPO GitHub repository in format `owner/repo`.
 * @returns {Promise<Record<string, Record<string, any>[]>>}
 */
export function get_caches(GH_REPO: string): Promise<Record<string, Record<string, any>[]>>;
