/**
 * Check if a file matches any ignore pattern.
 * @param {string} file - absolute path to the file
 * @param {string} srcDir - root src directory
 * @param {Array<RegExp|string>} patterns - list of ignore patterns
 * @returns {boolean}
 */
export function shouldIgnore(file: string, srcDir: string, patterns: Array<RegExp | string>): boolean;
/**
 * Default ignore patterns combining structural skips and project-level ignores.
 *
 * Each pattern can be:
 * - `RegExp` — tested against the src-relative path
 * - `string` ending with `/` — directory prefix check
 * - `string` in `/pattern/` form — converted to regex test
 * - `string` — exact relative path match
 */
export const DEFAULT_IGNORE_PATTERNS: (string | RegExp)[];
