/**
 * Get exported symbols from a source file.
 * Uses AST for ESM, regex for CJS.
 * @param {string} filePath
 * @returns {{ symbols: string[], exports: import('./types').ExportEntry[], defaultExport: string | null }}
 */
export default function getExportsFromFile(filePath: string): {
    symbols: string[];
    exports: import("./types").ExportEntry[];
    defaultExport: string | null;
};
