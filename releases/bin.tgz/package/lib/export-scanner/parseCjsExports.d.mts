/**
 * Parse exported symbols from a CJS file using regex.
 * @param {string} code
 * @returns {{ named: string[], default: string | null }}
 */
export default function parseCjsExports(code: string): {
    named: string[];
    default: string | null;
};
