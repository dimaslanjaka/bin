/**
 * Parse exported symbols from an ESM file using Babel AST.
 * @param {string} code
 * @returns {import('./types').ExportEntry[]}
 */
export default function parseEsmExports(code: string): import("./types").ExportEntry[];
