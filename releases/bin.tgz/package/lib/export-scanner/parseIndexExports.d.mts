/**
 * Parse existing re-exports from the index file.
 * Returns a Map of source -> symbol names.
 * @param {string} indexPath - absolute path to the index file (e.g. src/index.ts)
 * @returns {Map<string, string[]>}
 */
export default function parseIndexExports(indexPath: string): Map<string, string[]>;
