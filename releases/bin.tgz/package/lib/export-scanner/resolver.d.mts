/**
 * Resolve a source path that may use .js extension for .ts files
 * (tsup/bundler convention). Returns first existing path or null.
 * @param {string} rawSrc - path relative to srcDir
 * @param {string} srcDir - root src directory
 * @returns {string | null}
 */
export function resolveSourcePath(rawSrc: string, srcDir: string): string | null;
