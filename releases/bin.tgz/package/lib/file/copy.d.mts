export function copy(src: any, dest: any): Promise<void>;
