export function move(src: any, dest: any): Promise<void>;
