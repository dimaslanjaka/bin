import * as puppeteer from 'puppeteer';

declare function saveCookies(page: any, path?: string): Promise<void>;
/**
 * Navigates to a URL using Puppeteer, loading cookies for the host and injecting a DOM mutation observer.
 *
 * @param {import('puppeteer').Page} page - Puppeteer page instance.
 * @param {string} url - The URL to navigate to.
 * @returns {Promise<{ waitForDomIdle: (idleMs?: number, timeout?: number) => Promise<boolean> }>} An object containing a function to wait for DOM stability.
 */
declare function navigatePage(page: puppeteer.Page, url: string): Promise<{
    waitForDomIdle: (idleMs?: number, timeout?: number) => Promise<boolean>;
}>;
declare function restoreCookies(page: any, cookieFilePath?: string): Promise<void>;
declare function writeQuestion(page: any, question: any): Promise<void>;
declare function clickSubmitButton(page: any): Promise<void>;

export { clickSubmitButton, navigatePage, restoreCookies, saveCookies, writeQuestion };
