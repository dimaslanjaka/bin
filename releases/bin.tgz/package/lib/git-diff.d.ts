#!/usr/bin/env node
export default runGitDiff;
/**
 * Executes a git diff command and saves the output to configured temp files.
 *
 * This function runs the specified git command, captures its output, and saves it to two files:
 * - A standard diff output file for manual inspection
 * - A GPT-formatted prompt file for generating conventional commit messages
 *
 * @param {string} command - The git command to execute (e.g., "git --no-pager diff --staged")
 * @param {string} successMessage - Message to display when the command executes successfully
 * @param {string} errorMessage - Message to display when the command fails
 * @returns {boolean} True when diff content exists, false when no changes were found
 *
 * @throws {Error} Exits the process with code 1 if the git command fails
 *
 * @example
 * // Generate staged diff for all files
 * runGitDiff(
 *   "git --no-pager diff --staged",
 *   "Staged diff saved successfully",
 *   "Failed to generate staged diff"
 * );
 *
 * @example
 * // Generate diff for a specific file
 * runGitDiff(
 *   'git --no-pager diff --cached -- "src/file.js"',
 *   'File diff saved successfully',
 *   'Failed to generate file diff'
 * );
 */
declare function runGitDiff(command: string, successMessage: string, errorMessage: string): boolean;
export const CACHE_DIR: string;
export const DIFF_OUTPUT: string;
export const DIFF_OUTPUT_RELATIVE: string;
export const GPT_DIFF_OUTPUT: string;
export const GPT_DIFF_OUTPUT_RELATIVE: string;
export function mainGitDiff(): Promise<void>;
export { runGitDiff as gitDiff };
