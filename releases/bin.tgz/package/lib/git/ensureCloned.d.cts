export default module.exports;
/**
 * Clone url at branch into dest. When .git already exists, verifies:
 *  1. remote URL normalizes to the same value as url
 *  2. current branch matches branch
 *  3. git root resolves to dest
 * Re-clones (after removing the directory) if any check fails.
 *
 * @param {string} url    Remote repository URL.
 * @param {string} branch Branch to clone / verify.
 * @param {string} dest   Local destination path (absolute).
 */
export function ensureCloned(url: string, branch: string, dest: string): void;
/**
 * Normalize a git remote URL so HTTP and SSH variants compare equal.
 * Strips trailing .git, lowercases, converts git@host:owner/repo to host/owner/repo.
 * @param {string} url
 * @returns {string}
 */
export function normalizeRemoteUrl(url: string): string;
/**
 * Run a git command inside cwd and return trimmed stdout, or null on failure.
 * @param {string[]} args
 * @param {string} cwd
 * @returns {string|null}
 */
export function gitQuery(args: string[], cwd: string): string | null;
declare namespace exports {
    export { ensureCloned, normalizeRemoteUrl, gitQuery, exports as default };
}
declare namespace module { }
