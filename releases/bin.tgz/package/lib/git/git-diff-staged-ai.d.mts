export default runStagedDiff;
/**
 * Executes a git diff command and saves the output to configured temp files.
 *
 * @param {string} command - The git diff command to execute
 * @param {string} successMessage - Message on success
 * @param {string} errorMessage - Message on failure
 * @param {object} [options] - Additional options.
 * @param {import('child_process').ExecSyncOptions} [options.execOptions] - Options forwarded to execSync (e.g. cwd, env, timeout).
 *   Spread after defaults, so these override encoding/maxBuffer if provided.
 * @param {boolean} [options.commit] - If true, after AI generates the commit message, save it to commit.txt and run git commit -F commit.txt.
 * @returns {boolean} True if diff has content, false if empty
 * @throws {Error} When the git command fails
 */
declare function runStagedDiff(command: string, successMessage: string, errorMessage: string, options?: {
    execOptions?: import("child_process").ExecSyncOptions;
    commit?: boolean;
}): boolean;
export const CACHE_DIR: string;
export const DIFF_OUTPUT: string;
export const DIFF_OUTPUT_RELATIVE: string;
export const GPT_DIFF_OUTPUT: string;
export const GPT_DIFF_OUTPUT_RELATIVE: string;
/**
 * Main entry point for the staged-diff + AI workflow.
 *
 * @param {object} [mainArgs] - Optional argument overrides.
 *   When omitted, falls back to module-level args from process.argv.
 *   Expected shape: { _: string[], help?: boolean, h?: boolean }
 */
export function main(mainArgs?: object): Promise<void>;
export { runStagedDiff as gitDiff };
