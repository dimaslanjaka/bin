/**
 * Parse existing .gitattributes file into structured rules
 * @param {string} gitattributesPath - Path to .gitattributes file
 * @returns {Array} Array of parsed rules
 */
declare function parseGitAttributes(gitattributesPath: string): any[];
/**
 * Check if two patterns conflict (same or overlapping file patterns)
 * @param {string} pattern1 - First pattern
 * @param {string} pattern2 - Second pattern
 * @returns {boolean} True if patterns conflict
 */
declare function patternsConflict(pattern1: string, pattern2: string): boolean;
/**
 * Merge existing rules with desired rules, detecting conflicts
 * @param {Array} existingRules - Parsed existing rules
 * @param {Array} desiredRules - Desired rules to add
 * @returns {Object} Result with mergedRules, conflicts, and changes
 */
declare function mergeGitAttributeRules(existingRules: any[], desiredRules: any[]): any;
/**
 * Format merged rules back into .gitattributes content
 * @param {Array} rules - Merged rules array
 * @returns {string} Formatted .gitattributes content
 */
declare function formatGitAttributes(rules: any[]): string;
/**
 * Update .gitattributes file with new rules, handling conflicts intelligently
 * @param {string} gitattributesPath - Path to .gitattributes file
 * @param {Array} desiredRules - Array of desired rules to add/merge
 * @returns {Object} Result with success status, conflicts, and changes
 */
declare function updateGitAttributes(gitattributesPath: string, desiredRules: any[]): any;

export { formatGitAttributes, mergeGitAttributeRules, parseGitAttributes, patternsConflict, updateGitAttributes };
