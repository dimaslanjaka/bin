export default module.exports;
/**
 * Force LF line endings configuration
 * - Sets core.autocrlf = false
 * - Sets core.eol = lf
 * - Creates/updates .gitattributes with proper line ending rules
 */
export function forceLfLineEndings(): void;
declare namespace exports {
    export { forceLfLineEndings, exports as default };
}
declare namespace module { }
