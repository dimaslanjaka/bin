/**
 * Normalize line endings in existing tracked files
 * - Refreshes the git index to detect line ending changes
 * - Applies renormalization to all tracked files
 */
export function normalizeLineEndings(): void;
