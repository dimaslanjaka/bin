export default module.exports;
/**
 * Normalize line endings in existing tracked files
 * - Refreshes the git index to detect line ending changes
 * - Applies renormalization to all tracked files
 */
export function normalizeLineEndings(): void;
declare namespace exports {
    export { normalizeLineEndings, exports as default };
}
declare namespace module { }
