/**
 * Configure git to ignore file permission changes
 * - Sets core.filemode = false
 * - Sets diff.ignoreSubmodules = dirty
 */
export function ignoreFilePermissions(): void;
