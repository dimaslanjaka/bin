export default module.exports;
/**
 * Configure git to ignore file permission changes
 * - Sets core.filemode = false
 * - Sets diff.ignoreSubmodules = dirty
 */
export function ignoreFilePermissions(): void;
declare namespace exports {
    export { ignoreFilePermissions, exports as default };
}
declare namespace module { }
