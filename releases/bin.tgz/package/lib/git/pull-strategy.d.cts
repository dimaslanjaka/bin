export default module.exports;
/**
 * Set git pull strategy to disable automatic rebase
 * - Sets pull.rebase = false
 */
export function setPullStrategy(): void;
declare namespace exports {
    export { setPullStrategy, exports as default };
}
declare namespace module { }
