/**
 * Set git pull strategy to disable automatic rebase
 * - Sets pull.rebase = false
 */
export function setPullStrategy(): void;
