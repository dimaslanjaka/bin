export function undoLastCommit(): void;
