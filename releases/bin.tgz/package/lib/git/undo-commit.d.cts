export default module.exports;
export function undoLastCommit(): void;
declare namespace exports {
    export { undoLastCommit, exports as default };
}
declare namespace module { }
