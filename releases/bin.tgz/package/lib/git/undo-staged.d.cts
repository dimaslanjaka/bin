export function undoStagedChanges(): void;
