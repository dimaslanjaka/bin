export default module.exports;
export function undoStagedChanges(): void;
declare namespace exports {
    export { undoStagedChanges, exports as default };
}
declare namespace module { }
