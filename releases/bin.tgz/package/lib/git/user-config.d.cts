/**
 * Configure Git user from CLI arguments or environment variables
 * @param {string|null} cliUser - Username from CLI arguments
 * @param {string|null} cliEmail - Email from CLI arguments
 * @param {object} [options] - Options object
 * @param {boolean} [options.updateRemote] - If true, update remote URL without prompt
 */
export function configureGitUser(cliUser?: string | null, cliEmail?: string | null, options?: {
    updateRemote?: boolean;
}): void;
