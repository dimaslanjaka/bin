export default module.exports;
/**
 * Execute a git command with proper error handling and logging
 * @param {string[]} args - Git command arguments
 * @param {string} description - Description of the operation for logging
 * @returns {boolean} - True if successful, false otherwise
 */
export function runGitCommand(args: string[], description: string): boolean;
/**
 * Execute a git command and return stdout (or null on error)
 * @param {string[]} args - Git command arguments
 * @param {string} description - Description of the operation for logging
 * @returns {string|null} - stdout string if successful, null otherwise
 */
export function runGitCommandOutput(args: string[], description: string): string | null;
/**
 * Check if the given cwd (or current directory) is a git repository
 * @param {string} [cwd] - Directory to check (defaults to current directory at call time)
 * @returns {boolean} - True if in a git repository, false otherwise
 */
export function isGitRepository(cwd?: string): boolean;
declare namespace exports {
    export { runGitCommand, runGitCommandOutput, isGitRepository, exports as default };
}
declare namespace module { }
