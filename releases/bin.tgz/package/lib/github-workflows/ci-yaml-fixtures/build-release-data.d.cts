export let name: string;
export namespace on {
    let push: {
        'paths-ignore': string[];
    };
    let workflow_dispatch: {};
}
export let concurrency: {
    group: string;
    'cancel-in-progress': boolean;
};
export let jobs: {
    'build-release': {
        name: string;
        env: {
            PUPPETEER_SKIP_DOWNLOAD: string;
            PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD: string;
            NODE_OPTIONS: string;
            YARN_ENABLE_IMMUTABLE_INSTALLS: boolean;
            YARN_ENABLE_GLOBAL_CACHE: boolean;
            YARN_CHECKSUM_BEHAVIOR: string;
            YARN_CACHE_FOLDER: string;
            CI_NODE_VERSION: string;
            PIP_LOCAL_CACHE_DIR: string;
            NUITKA_CACHE_DIR: string;
            ACCESS_TOKEN: string;
            GH_TOKEN: string;
        };
        'runs-on': string;
        steps: ({
            name: string;
            uses: string;
            with: {
                'fetch-depth': number;
                'node-version'?: undefined;
                'python-version'?: undefined;
                token?: undefined;
                'prefix-cache-key'?: undefined;
                name?: undefined;
                path?: undefined;
                'if-no-files-found'?: undefined;
            };
            id?: undefined;
            shell?: undefined;
            run?: undefined;
            if?: undefined;
            'continue-on-error'?: undefined;
        } | {
            name: string;
            id: string;
            uses: string;
            with: {
                'node-version': string;
                'python-version': string;
                token: string;
                'prefix-cache-key': string;
                'fetch-depth'?: undefined;
                name?: undefined;
                path?: undefined;
                'if-no-files-found'?: undefined;
            };
            shell?: undefined;
            run?: undefined;
            if?: undefined;
            'continue-on-error'?: undefined;
        } | {
            name: string;
            shell: string;
            run: string;
            uses?: undefined;
            with?: undefined;
            id?: undefined;
            if?: undefined;
            'continue-on-error'?: undefined;
        } | {
            name: string;
            if: string;
            shell: string;
            'continue-on-error': boolean;
            run: string;
            uses?: undefined;
            with?: undefined;
            id?: undefined;
        } | {
            name: string;
            uses: string;
            with: {
                name: string;
                path: string;
                'if-no-files-found': string;
                'fetch-depth'?: undefined;
                'node-version'?: undefined;
                'python-version'?: undefined;
                token?: undefined;
                'prefix-cache-key'?: undefined;
            };
            id?: undefined;
            shell?: undefined;
            run?: undefined;
            if?: undefined;
            'continue-on-error'?: undefined;
        } | {
            name: string;
            id: string;
            shell: string;
            run: string;
            uses?: undefined;
            with?: undefined;
            if?: undefined;
            'continue-on-error'?: undefined;
        } | {
            name: string;
            if: string;
            'continue-on-error': boolean;
            run: string;
            uses?: undefined;
            with?: undefined;
            id?: undefined;
            shell?: undefined;
        } | {
            name: string;
            run: string;
            if: string;
            uses?: undefined;
            with?: undefined;
            id?: undefined;
            shell?: undefined;
            'continue-on-error'?: undefined;
        } | {
            name: string;
            if: string;
            shell: string;
            run: string;
            uses?: undefined;
            with?: undefined;
            id?: undefined;
            'continue-on-error'?: undefined;
        } | {
            name: string;
            'continue-on-error': boolean;
            run: string;
            uses?: undefined;
            with?: undefined;
            id?: undefined;
            shell?: undefined;
            if?: undefined;
        })[];
    };
};
