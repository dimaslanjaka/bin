/**
 * Parse a GitHub remote URL to owner/repo slug.
 * Handles both SSH (git@github.com:owner/repo.git) and HTTPS formats.
 * @param {string} url
 * @returns {string|null}
 */
export function parseRepoSlug(url: string): string | null;
/**
 * Collect a set of identifiers for the current git repo by probing multiple signals:
 * 1. Remote origin URL parsed as owner/repo
 * 2. Git toplevel directory basename (e.g. "binary-collections" from /path/to/binary-collections)
 * 3. Root package.json name field
 * Handles cases where the remote URL doesn't match the repo's canonical name.
 * @returns {Set<string>}
 */
export function getCurrentRepoIdentifiers(): Set<string>;
/**
 * Get the set of repo slugs (owner/repo) from .gitmodules submodules.
 * These repos are populated by `git submodule update --init --recursive`,
 * so separate checkout steps are redundant.
 * @returns {Set<string>}
 */
export function getSubmoduleRepos(): Set<string>;
/**
 * Determine if a given RepoInfo entry should be skipped.
 * @param {{ repo: string, path: string }} entry
 * @param {Set<string>} currentRepoIds
 * @param {Set<string>} submoduleRepos
 * @returns {string|false} Reason string if should skip, false if should keep
 */
export function shouldSkipEntry(entry: {
    repo: string;
    path: string;
}, currentRepoIds: Set<string>, submoduleRepos: Set<string>): string | false;
/**
 * Filter a RepoInfo array to remove entries for the current repo and submodule-managed repos.
 * @param {Array<{repo: string, path: string, ref: string}>} repoInfo
 * @param {object} [options]
 * @param {string} [options.logPrefix] - Prefix for log messages (default: '[repo-verifier]')
 * @returns {Array<{repo: string, path: string, ref: string}>}
 */
export function filterRepoInfo(repoInfo: Array<{
    repo: string;
    path: string;
    ref: string;
}>, options?: {
    logPrefix?: string;
}): Array<{
    repo: string;
    path: string;
    ref: string;
}>;
