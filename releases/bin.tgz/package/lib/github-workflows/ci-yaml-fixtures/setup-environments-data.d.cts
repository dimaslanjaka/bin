export let name: string;
export let description: string;
export let inputs: {
    'node-version': {
        description: string;
        required: boolean;
    };
    'python-version': {
        description: string;
        required: boolean;
        default: string;
    };
    'prefix-cache-key': {
        description: string;
        required: boolean;
        default: string;
    };
    token: {
        description: string;
        required: boolean;
        default: string;
    };
};
export namespace outputs {
    namespace CACHE_YARN {
        let description_1: string;
        export { description_1 as description };
        export let value: string;
    }
    namespace CACHE_NPM {
        let description_2: string;
        export { description_2 as description };
        let value_1: string;
        export { value_1 as value };
    }
    namespace CACHE_NPM_USER_GLOBAL {
        let description_3: string;
        export { description_3 as description };
        let value_2: string;
        export { value_2 as value };
    }
    namespace PIP_CACHE_DIR {
        let description_4: string;
        export { description_4 as description };
        let value_3: string;
        export { value_3 as value };
    }
    namespace CURRENT_YARN_VERSION {
        let description_5: string;
        export { description_5 as description };
        let value_4: string;
        export { value_4 as value };
    }
    namespace GITHUB_BRANCH {
        let description_6: string;
        export { description_6 as description };
        let value_5: string;
        export { value_5 as value };
    }
    namespace GITHUB_SHA_SHORT {
        let description_7: string;
        export { description_7 as description };
        let value_6: string;
        export { value_6 as value };
    }
    namespace GITHUB_COMMIT_URL {
        let description_8: string;
        export { description_8 as description };
        let value_7: string;
        export { value_7 as value };
    }
    namespace GITHUB_RUNNER_URL {
        let description_9: string;
        export { description_9 as description };
        let value_8: string;
        export { value_8 as value };
    }
    namespace PACKAGE_MANAGER {
        let description_10: string;
        export { description_10 as description };
        let value_9: string;
        export { value_9 as value };
    }
    namespace MACHINE {
        let description_11: string;
        export { description_11 as description };
        let value_10: string;
        export { value_10 as value };
    }
    namespace CACHE_HIT {
        let description_12: string;
        export { description_12 as description };
        let value_11: string;
        export { value_11 as value };
    }
}
export namespace runs {
    let using: string;
    let steps: ({
        name: string;
        uses: string;
        with: {
            repository: string;
            path: string;
            token: string;
            ref: string;
            'node-version'?: undefined;
            'python-version'?: undefined;
            'bun-version'?: undefined;
            registries?: undefined;
            key?: undefined;
            'restore-keys'?: undefined;
        };
        'continue-on-error'?: undefined;
        shell?: undefined;
        run?: undefined;
        if?: undefined;
        id?: undefined;
    } | {
        name: string;
        'continue-on-error': boolean;
        shell: string;
        run: string;
        uses?: undefined;
        with?: undefined;
        if?: undefined;
        id?: undefined;
    } | {
        name: string;
        uses: string;
        with: {
            'node-version': string;
            repository?: undefined;
            path?: undefined;
            token?: undefined;
            ref?: undefined;
            'python-version'?: undefined;
            'bun-version'?: undefined;
            registries?: undefined;
            key?: undefined;
            'restore-keys'?: undefined;
        };
        'continue-on-error'?: undefined;
        shell?: undefined;
        run?: undefined;
        if?: undefined;
        id?: undefined;
    } | {
        name: string;
        if: string;
        uses: string;
        with: {
            'python-version': string;
            repository?: undefined;
            path?: undefined;
            token?: undefined;
            ref?: undefined;
            'node-version'?: undefined;
            'bun-version'?: undefined;
            registries?: undefined;
            key?: undefined;
            'restore-keys'?: undefined;
        };
        'continue-on-error'?: undefined;
        shell?: undefined;
        run?: undefined;
        id?: undefined;
    } | {
        name: string;
        uses: string;
        with: {
            'bun-version': string;
            registries: string;
            repository?: undefined;
            path?: undefined;
            token?: undefined;
            ref?: undefined;
            'node-version'?: undefined;
            'python-version'?: undefined;
            key?: undefined;
            'restore-keys'?: undefined;
        };
        'continue-on-error'?: undefined;
        shell?: undefined;
        run?: undefined;
        if?: undefined;
        id?: undefined;
    } | {
        name: string;
        shell: string;
        run: string;
        uses?: undefined;
        with?: undefined;
        'continue-on-error'?: undefined;
        if?: undefined;
        id?: undefined;
    } | {
        name: string;
        id: string;
        shell: string;
        run: string;
        uses?: undefined;
        with?: undefined;
        'continue-on-error'?: undefined;
        if?: undefined;
    } | {
        name: string;
        id: string;
        uses: string;
        with: {
            path: string;
            key: string;
            'restore-keys': string;
            repository?: undefined;
            token?: undefined;
            ref?: undefined;
            'node-version'?: undefined;
            'python-version'?: undefined;
            'bun-version'?: undefined;
            registries?: undefined;
        };
        'continue-on-error'?: undefined;
        shell?: undefined;
        run?: undefined;
        if?: undefined;
    } | {
        name: string;
        if: string;
        shell: string;
        run: string;
        uses?: undefined;
        with?: undefined;
        'continue-on-error'?: undefined;
        id?: undefined;
    } | {
        name: string;
        'continue-on-error': boolean;
        if: string;
        shell: string;
        run: string;
        uses?: undefined;
        with?: undefined;
        id?: undefined;
    })[];
}
