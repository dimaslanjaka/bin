export default module.exports;
/**
 * Deletes a GitHub Actions cache.
 *
 * @param {string} GH_REPO - The GitHub repository in the format "owner/repo".
 * @param {string|number} cacheId - The ID of the cache to delete.
 * @returns {Promise<any>} Promise resolving with GitHub API response.
 */
export function deleteGitHubActionsCache(GH_REPO: string, cacheId: string | number): Promise<any>;
/**
 * Extract the grouping prefix from a cache key.
 *
 * @param {string} key
 * @param {number} [prefixDepth=3]
 * @returns {string}
 */
export function getCachePrefix(key: string, prefixDepth?: number): string;
/**
 * Remove checksum-like segments from a cache key.
 *
 * @param {string} key
 * @returns {string[]}
 */
export function getMeaningfulCacheKeyParts(key: string): string[];
/**
 * List GitHub Actions caches grouped by cache key prefix.
 *
 * @param {string} GH_REPO GitHub repository in format `owner/repo`.
 * @param {number} [prefixDepth=3]
 * @returns {Promise<Record<string, Record<string, any>[]>>}
 */
export function get_caches(GH_REPO: string, prefixDepth?: number): Promise<Record<string, Record<string, any>[]>>;
/**
 * Group GitHub Actions caches by their derived prefix.
 *
 * @param {Record<string, any>[]} caches
 * @param {number} [prefixDepth=3]
 * @returns {Record<string, Record<string, any>[]>}
 */
export function groupCachesByPrefix(caches: Record<string, any>[], prefixDepth?: number): Record<string, Record<string, any>[]>;
/**
 * Detect cache-key segments that look like checksum hashes.
 *
 * @param {string} segment
 * @returns {boolean}
 */
export function isChecksumSegment(segment: string): boolean;
/**
 * Normalize the number of cache key segments to use for grouping.
 *
 * @param {unknown} prefixDepth
 * @returns {number}
 */
export function normalizePrefixDepth(prefixDepth: unknown): number;
declare namespace exports {
    export { deleteGitHubActionsCache, getCachePrefix, getMeaningfulCacheKeyParts, get_caches, groupCachesByPrefix, isChecksumSegment, normalizePrefixDepth, exports as default };
}
declare namespace module { }
