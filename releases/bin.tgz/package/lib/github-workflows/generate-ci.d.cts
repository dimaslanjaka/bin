export = generateCI;
declare function generateCI(cwd?: any): void;
