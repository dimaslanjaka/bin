export = generateCI;
declare function generateCI(cwd?: any): void;
declare namespace generateCI {
    export { exports as default };
}
declare namespace exports {
    export { exports as default };
}
