export function printReport(run: any, jobs: any): void;
