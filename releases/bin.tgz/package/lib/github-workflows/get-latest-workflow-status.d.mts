export function request(url: any): Promise<any>;
export function getLatestRun(owner: any, repo: any, workflowId: any): Promise<any>;
export function getJobs(owner: any, repo: any, runId: any): Promise<any>;
export function getCurrentOwner(): Promise<any>;
export function getCurrentRepo(): Promise<any>;
export function getOwnerFromRemoteUrl(remoteUrl: any): any;
export function getRepoFromRemoteUrl(remoteUrl: any): any;
export function printReport(run: any, jobs: any): void;
