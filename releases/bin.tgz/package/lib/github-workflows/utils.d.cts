export default module.exports;
export const BASE: "https://api.github.com";
/**
 * Build authorization headers with a lazily-resolved token.
 * @returns {Promise<object>}
 */
export function getHeaders(): Promise<object>;
/**
 * Lazily resolve and cache the GitHub token.
 * @returns {Promise<string>}
 */
export function getToken(): Promise<string>;
/**
 * Make a GET request to the GitHub REST API.
 * @param {string} url - Full URL to fetch
 * @returns {Promise<object>} Response JSON body
 */
export function request(url: string): Promise<object>;
/**
 * Run a git command and return stdout.
 * @param {string[]} args - Arguments to pass to git
 * @returns {Promise<string>} Trimmed stdout
 */
export function runGit(args: string[]): Promise<string>;
/**
 * Parse owner and repo from a GitHub remote URL.
 * @param {string} remoteUrl - e.g. "git@github.com:owner/repo.git"
 * @returns {{owner: string, repo: string}|null} Parsed groups or null
 */
export function parseOwnerFromUrl(remoteUrl: string): {
    owner: string;
    repo: string;
} | null;
/**
 * Extract the owner from a GitHub remote URL.
 * @param {string} remoteUrl
 * @returns {string|null}
 */
export function getOwnerFromRemoteUrl(remoteUrl: string): string | null;
/**
 * Extract the repo name from a GitHub remote URL.
 * @param {string} remoteUrl
 * @returns {string|null}
 */
export function getRepoFromRemoteUrl(remoteUrl: string): string | null;
/**
 * Determine the repository owner from the local git remote.
 * Tries multiple git command variants.
 * @returns {Promise<string>}
 */
export function getCurrentOwner(): Promise<string>;
/**
 * Determine the repository name from the local git remote.
 * Tries multiple git command variants.
 * @returns {Promise<string>}
 */
export function getCurrentRepo(): Promise<string>;
/**
 * Get both owner and repo from the local git remote.
 * @returns {Promise<{owner: string, repo: string}>}
 */
export function getOwnerRepo(): Promise<{
    owner: string;
    repo: string;
}>;
/**
 * Get the latest workflow run for a repository.
 * When workflowId is provided, filters by that specific workflow (filename or ID).
 * @param {string} owner - GitHub repository owner
 * @param {string} repo - GitHub repository name
 * @param {string} [workflowId] - Workflow filename (e.g. "test.yml") or numeric ID
 * @returns {Promise<object|undefined>} The latest workflow run object
 */
export function getLatestRun(owner: string, repo: string, workflowId?: string): Promise<object | undefined>;
/**
 * Get all jobs for a specific workflow run.
 * @param {string} owner - GitHub repository owner
 * @param {string} repo - GitHub repository name
 * @param {number|string} runId - Workflow run ID
 * @returns {Promise<object[]>} Array of job objects
 */
export function getJobs(owner: string, repo: string, runId: number | string): Promise<object[]>;
/**
 * Serialize a JS object to YAML and write it to a file.
 * Creates parent directories if needed. Formats with prettier if available.
 * @param {string} filePath - Output file path (relative or absolute)
 * @param {object} obj - JS object to serialize
 * @returns {string} Resolved absolute path to the written file
 */
export function writeYamlFile(filePath: string, obj: object): string;
declare namespace exports {
    export { BASE, getHeaders, getToken, request, runGit, parseOwnerFromUrl, getOwnerFromRemoteUrl, getRepoFromRemoteUrl, getCurrentOwner, getCurrentRepo, getOwnerRepo, getLatestRun, getJobs, writeYamlFile, exports as default };
}
declare namespace module { }
