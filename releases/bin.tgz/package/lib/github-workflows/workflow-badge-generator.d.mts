/**
 * Generate a detailed SVG badge for a GitHub Actions workflow run.
 *
 * @param {object}   run           - Workflow run object from the GitHub API
 * @param {object[]} jobs          - Array of job objects from the GitHub API
 * @param {object}   [options]
 * @param {number}   [options.width=520] - SVG width in pixels
 * @param {number}   [options.maxSteps]  - Max steps to show per job (rest summarized)
 * @returns {string} SVG markup
 */
export function generateBadge(run: object, jobs: object[], options?: {
    width?: number;
    maxSteps?: number;
}): string;
