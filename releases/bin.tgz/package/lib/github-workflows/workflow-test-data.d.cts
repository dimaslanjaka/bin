export let name: string;
export let concurrency: {
    group: string;
    'cancel-in-progress': boolean;
};
export namespace on {
    namespace workflow_run {
        let workflows: string[];
        let types: string[];
    }
    let workflow_dispatch: {};
    namespace push {
        let paths: string[];
    }
}
export namespace env {
    let CI_NODE_VERSION: string;
    let CI_PYTHON_VERSION: string;
    let ACCESS_TOKEN: string;
    let GH_TOKEN: string;
}
export namespace jobs {
    let ci: {
        name: string;
        if: string;
        'runs-on': string;
        steps: ({
            name: string;
            uses: string;
            with?: undefined;
            run?: undefined;
            'continue-on-error'?: undefined;
            env?: undefined;
            shell?: undefined;
        } | {
            name: string;
            uses: string;
            with: {
                'node-version': string;
                'python-version': string;
                token: string;
                'prefix-cache-key': string;
            };
            run?: undefined;
            'continue-on-error'?: undefined;
            env?: undefined;
            shell?: undefined;
        } | {
            name: string;
            run: string;
            uses?: undefined;
            with?: undefined;
            'continue-on-error'?: undefined;
            env?: undefined;
            shell?: undefined;
        } | {
            name: string;
            'continue-on-error': boolean;
            env: {
                GH_TOKEN: string;
            };
            shell: string;
            run: string;
            uses?: undefined;
            with?: undefined;
        })[];
    };
}
