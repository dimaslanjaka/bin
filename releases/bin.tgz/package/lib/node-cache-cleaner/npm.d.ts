export declare function npmVersion(): Promise<string>;
export declare function cleanNpmCache(): Promise<unknown>;
