/**
 * Main cleaner
 */
export declare function cleanNpxCache(): Promise<void>;
