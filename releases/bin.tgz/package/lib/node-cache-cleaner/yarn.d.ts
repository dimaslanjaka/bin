export declare function yarnVersion(): Promise<string>;
export declare function cleanYarnCache(): Promise<unknown>;
