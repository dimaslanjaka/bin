/**
 * Build release readme for a node package
 * @param {string} dirname - repository root directory (equivalent to __dirname in CJS)
 * @param {object} packagejson - parsed package.json
 * @param {string} releaseDir - path to release directory
 * @param {object} argv - parsed CLI args (minimist)
 * @param {boolean} isCI - whether running in CI
 */
export function buildReadme(dirname: string, packagejson: object, releaseDir: string, argv: object, isCI: boolean): Promise<void>;
export default buildReadme;
