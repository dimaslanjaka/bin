export function getPackageHashes(dirname: any, releaseDir: any): Promise<{}>;
/**
 * Build release tarballs using the Yarn pack output.
 * @param {string} dirname Repository root directory.
 * @param {object} packagejson Parsed package.json content.
 * @param {string} releaseDir Release output directory.
 * @param {object} argv Parsed CLI arguments.
 * @param {boolean} withFilename Whether to keep the requested filename variant.
 * @param {boolean} isCI Whether the process is running in CI.
 * @returns {Promise<void>}
 */
export function bundleWithYarn(dirname: string, packagejson: object, releaseDir: string, argv: object, withFilename: boolean, isCI: boolean): Promise<void>;
/**
 * Build release tarballs using the npm pack output.
 * @param {string} dirname Repository root directory.
 * @param {object} packagejson Parsed package.json content.
 * @param {string} releaseDir Release output directory.
 * @param {object} argv Parsed CLI arguments.
 * @param {boolean} isCI Whether the process is running in CI.
 * @returns {Promise<void>}
 */
export function bundleWithNpm(dirname: string, packagejson: object, releaseDir: string, argv: object, isCI: boolean): Promise<void>;
/**
 * Resolve CLI context and run the pack workflow.
 * @returns {Promise<void>}
 */
export function bundle(): Promise<void>;
declare namespace _default {
    export { bundleWithYarn };
    export { bundleWithNpm };
    export { getPackageHashes };
}
export default _default;
