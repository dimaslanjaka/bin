export function getPackageHashes(dirname: any, releaseDir: any): Promise<{}>;
/**
 * Build release tarballs using the Yarn pack output.
 * @param {string} dirname Repository root directory.
 * @param {object} packagejson Parsed package.json content.
 * @param {string} releaseDir Release output directory.
 * @param {object} argv Parsed CLI arguments.
 * @param {boolean} withFilename Whether to keep the requested filename variant.
 * @param {boolean} isCI Whether the process is running in CI.
 * @returns {Promise<void>}
 */
export function bundleWithYarn(dirname: string, packagejson: object, releaseDir: string, argv: object, withFilename: boolean, isCI: boolean): Promise<void>;
/**
 * Build release tarballs using the npm pack output.
 * @param {string} dirname Repository root directory.
 * @param {object} packagejson Parsed package.json content.
 * @param {string} releaseDir Release output directory.
 * @param {object} argv Parsed CLI arguments.
 * @param {boolean} isCI Whether the process is running in CI.
 * @returns {Promise<void>}
 */
export function bundleWithNpm(dirname: string, packagejson: object, releaseDir: string, argv: object, isCI: boolean): Promise<void>;
/**
 * Resolve CLI context and run the pack workflow.
 * @returns {Promise<void>}
 */
export function bundle(customArgs?: {}): Promise<void>;
declare namespace _default {
    export { bundleWithYarn };
    export { bundleWithNpm };
    export { getPackageHashes };
    export { slugifyPkgName };
    export { resolveWorkspaceVersions };
    export { transformWorkspaceProtocols };
    export { resolveNewestTarball };
}
export default _default;
export function slugifyPkgName(str: any): any;
/**
 * Build a map of workspace package name → version from the monorepo workspaces.
 * @param {string} dirname Repository root directory.
 * @returns {Record<string, string>}
 */
export function resolveWorkspaceVersions(dirname: string): Record<string, string>;
/**
 * Transform workspace protocol references in package.json dependency fields.
 * Yarn uses `workspace:*`, `workspace:^`, `workspace:~` to reference sibling
 * workspace packages. These must be replaced with real version ranges before
 * running `npm pack` or `yarn pack` to avoid "Workspace not found" errors.
 *
 * Creates a backup at `.package.json.bak` and writes the transformed file.
 * Returns a restore function to undo the changes.
 *
 * @param {string} dirname Repository root directory.
 * @returns {Promise<() => void>} Restore function to revert package.json.
 */
export function transformWorkspaceProtocols(dirname: string): Promise<() => void>;
export function resolveNewestTarball(dirname: any, candidateNames: any): any;
