export function getPackageHashes(dirname: any, releaseDir: any): Promise<{}>;
/**
 * Pack the current project into a tarball and prepare release metadata.
 *
 * Determines which package manager to use (bun → yarn → npm) based on
 * lockfile presence and CLI flags (`--yarn`, `--bun`). Before packing,
 * transforms `workspace:*` / `workspace:^` / `workspace:~` protocol
 * references in `package.json` to resolved version ranges, then restores
 * the original after packing completes (even on failure).
 *
 * Tarballs are emitted into `releases/` (or `release/` as fallback).
 * After packing, delegates to the tool-specific bundler
 * (`bundleWithBun`, `bundleWithYarn`, or `bundleWithNpm`) for post-processing.
 *
 * @param {import("minimist").ParsedArgs} [customArgs={}] - Override CLI argument parsing.
 *   Properties are merged with parsed `process.argv` via `getArgs()`.
 *   Supported keys include `yarn` (boolean), `bun` (boolean),
 *   `fn`/`filename` (boolean) to force a named tarball, and any other
 *   args consumed by downstream bundlers.
 * @param {string} [cwd] - Working directory for packing. Defaults to
 *   `customArgs.cwd` if set, otherwise `process.cwd()`.
 * @returns {Promise<void>}
 */
export function bundle(customArgs?: import("minimist").ParsedArgs, cwd?: string): Promise<void>;
declare namespace _default {
    export { bundleWithYarn };
    export { bundleWithNpm };
    export { bundleWithBun };
    export { getPackageHashes };
    export { resolveWorkspaceVersions };
    export { transformWorkspaceProtocols };
    export { resolveNewestTarball };
}
export default _default;
import { resolveWorkspaceVersions } from './transform-workspace-protocols.mjs';
import { transformWorkspaceProtocols } from './transform-workspace-protocols.mjs';
export function resolveNewestTarball(dirname: any, candidateNames: any): any;
import { bundleWithYarn } from './pack-with-yarn.mjs';
import { bundleWithNpm } from './pack-with-npm.mjs';
import { bundleWithBun } from './pack-with-bun.mjs';
export { resolveWorkspaceVersions, transformWorkspaceProtocols };
