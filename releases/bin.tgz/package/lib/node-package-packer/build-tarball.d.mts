export function getPackageHashes(dirname: any, releaseDir: any): Promise<{}>;
/**
 * Pack the current project into a tarball and prepare release metadata.
 *
 * Before packing, transforms `workspace:*` / `workspace:^` / `workspace:~`
 * protocol references in `package.json` to resolved version ranges, then
 * restores the original after packing completes (even on failure).
 *
 * Tarballs are emitted into `releases/` (or `release/` as fallback).
 * After packing, delegates to the tool-specific bundler
 * (`bundleWithBun`, `bundleWithYarn`, or `bundleWithNpm`) for post-processing.
 *
 * @param {object} [options] - Bundle options.
 * @param {string} [options.cwd] - Working directory for packing (default: process.cwd()).
 * @param {'yarn'|'bun'|'npm'} [options.pm] - Package manager to use (default: 'npm').
 * @param {string} [options.filename] - Custom output filename (without .tgz extension).
 * @param {boolean} [options.commit] - Auto-commit tarballs via git (default: false).
 * @returns {Promise<void>}
 */
export function bundle(options?: {
    cwd?: string;
    pm?: "yarn" | "bun" | "npm";
    filename?: string;
    commit?: boolean;
}): Promise<void>;
declare namespace _default {
    export { bundleWithYarn };
    export { bundleWithNpm };
    export { bundleWithBun };
    export { getPackageHashes };
    export { resolveWorkspaceVersions };
    export { transformWorkspaceProtocols };
    export { resolveNewestTarball };
}
export default _default;
import { resolveWorkspaceVersions } from './transform-workspace-protocols.mjs';
import { transformWorkspaceProtocols } from './transform-workspace-protocols.mjs';
export function resolveNewestTarball(dirname: any, candidateNames: any): any;
import { bundleWithYarn } from './pack-with-yarn.mjs';
import { bundleWithNpm } from './pack-with-npm.mjs';
import { bundleWithBun } from './pack-with-bun.mjs';
export { resolveWorkspaceVersions, transformWorkspaceProtocols };
