/**
 * Post-process a pack tarball: remove workspace artifact entries (submodule
 * release tarballs, yarn releases) that bloat the output. Works by extracting
 * to a temp directory with a filter, then repacking.
 *
 * @param {string} tarballPath - Path to the .tgz file to clean.
 * @param {object} [callbacks] - Optional callbacks from project config.
 * @param {Function} [callbacks.onFilter] - Filter tarball entries during
 *   cleanup. Return false to exclude. Configured via `packer.onFilter`.
 * @param {Function} [callbacks.onFinish] - Callback invoked after cleanup.
 *   Configured via `packer.onFinish`.
 * @returns {Promise<void>}
 */
export function cleanTarball(tarballPath: string, callbacks?: {
    onFilter?: Function;
    onFinish?: Function;
}): Promise<void>;
