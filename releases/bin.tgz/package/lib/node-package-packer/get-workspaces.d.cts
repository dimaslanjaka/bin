/**
 * Get all npm/yarn workspace package information (with caching).
 *
 * When `useCache` is enabled (default), the result is cached keyed by a checksum
 * of root `package.json`, `.gitmodules`, and the project lock file.
 *
 * @param {string} [rootDir]
 * @param {import('./get-workspaces-types').GetWorkspacesInfoOptions} [options]
 * @returns {Promise<import('./get-workspaces-types').WorkspacesInfo>}
 */
export function getWorkspacesInfo(rootDir?: string, options?: import("./get-workspaces-types").GetWorkspacesInfoOptions): Promise<import("./get-workspaces-types").WorkspacesInfo>;
/**
 * Compute a cache key from the relevant configuration files.
 * The content of each file is hashed and combined into a single SHA-256 hex digest.
 *
 * Checksummed files:
 * - Root `package.json` (always)
 * - `.gitmodules` (if exists)
 * - Lock file: `yarn.lock`, `package-lock.json`, or `pnpm-lock.yaml` (first found)
 *
 * @param {string} rootDir
 * @returns {Promise<string>}
 */
export function computeCacheKey(rootDir: string): Promise<string>;
/**
 * Clear the workspaces cache (in-memory and disk).
 */
export function clearWorkspacesCache(): Promise<void>;
/**
 * Normalize npm/yarn workspaces format.
 *
 * Supports:
 * - `"workspaces": ["packages/*"]`
 * - `"workspaces": { "packages": ["packages/*"] }`
 *
 * @param {import('./get-workspaces-types').WorkspacesConfig | undefined} workspaces
 * @returns {string[]}
 */
export function normalizeWorkspaces(workspaces: import("./get-workspaces-types").WorkspacesConfig | undefined): string[];
/**
 * Detect package manager from lock files.
 *
 * @param {string} rootDir
 * @returns {Promise<"npm" | "yarn" | "pnpm" | "unknown">}
 */
export function detectPackageManager(rootDir: string): Promise<"npm" | "yarn" | "pnpm" | "unknown">;
/**
 * Resolve workspace package.json files using glob.
 *
 * @param {string} rootDir
 * @param {string[]} workspacePatterns
 * @returns {Promise<string[]>}
 */
export function resolveWorkspacePackageJsonFiles(rootDir: string, workspacePatterns: string[]): Promise<string[]>;
