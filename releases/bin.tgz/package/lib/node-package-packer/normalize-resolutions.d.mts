/**
 * Restore the original package.json from the backup file.
 * Backup is stored under getTempPath('normalize-resolutions/').
 * Removes the backup file after successful restore.
 * @param {string} rootDir - Project root directory containing package.json
 */
export function restoreResolutions(rootDir: string): void;
/**
 * Normalize pinned commit hashes in package.json resolutions to
 * branch/tag names. Loads normalization mappings from config
 * (binary-collections.config.js) or falls back to defaults.
 * Backup is stored under getTempPath('normalize-resolutions/').
 * @param {string} rootDir - Project root directory containing package.json
 * @returns {Promise<boolean>} `true` if changes were made (backup saved), `false` if no-op.
 */
export function normalizeResolutions(rootDir: string): Promise<boolean>;
