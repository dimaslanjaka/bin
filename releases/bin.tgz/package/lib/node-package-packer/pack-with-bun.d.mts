/**
 * Build release tarballs using the bun pm pack output.
 *
 * Bun's `bun pm pack` supports `--destination <dir>` to write the tarball
 * directly to the release directory, and `--quiet` for automation-friendly
 * output. The resulting `.tgz` uses the same `<name>-<version>.tgz` naming
 * as npm's `npm pack`.
 *
 * @param {string} dirname Repository root directory.
 * @param {object} packagejson Parsed package.json content.
 * @param {string} releaseDir Release output directory.
 * @param {object} argv Parsed CLI arguments.
 * @param {boolean} isCI Whether the process is running in CI.
 * @returns {Promise<void>}
 */
export function bundleWithBun(dirname: string, packagejson: object, releaseDir: string, argv: object, isCI: boolean): Promise<void>;
