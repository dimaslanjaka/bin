/**
 * Transform workspace protocol references in package.json dependency fields.
 * Yarn uses `workspace:*`, `workspace:^`, `workspace:~` to reference sibling
 * workspace packages. These must be replaced with real version ranges before
 * running `npm pack` or `yarn pack` to avoid "Workspace not found" errors.
 *
 * Creates a backup at `.package.json.bak` and writes the transformed file.
 * Returns a restore function to undo the changes.
 *
 * @param {string} dirname Repository root directory.
 * @returns {Promise<() => void>} Restore function to revert package.json.
 */
export function transformWorkspaceProtocols(dirname: string): Promise<() => void>;
/**
 * Build a map of workspace package name → version from the monorepo workspaces.
 * @param {string} dirname Repository root directory.
 * @returns {Record<string, string>}
 */
export function resolveWorkspaceVersions(dirname: string): Record<string, string>;
