export declare function handleAuthRotate(): Promise<void>;
