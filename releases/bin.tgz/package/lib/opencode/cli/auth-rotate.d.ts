import { OpencodeKey } from '../../binary-collections/config-types.js';
export interface FindWorkingKeyOptions {
    /** Optional HTTP proxy URL for the API call. */
    proxy?: string;
    /** Disable cache lookup and force checking candidates again. */
    noCache?: boolean;
}
/**
 * Shuffle candidates and test each one against the OpenCode API.
 * Returns the first key that responds successfully.
 *
 * Successful results are cached for 5 minutes per proxy value unless
 * `noCache` is enabled.
 *
 * @param candidates - Key entries to test.
 * @param options    - Optional proxy and cache controls.
 * @returns The first working key entry, or `null` if none respond.
 */
export declare function findWorkingKey(candidates: OpencodeKey[], options?: FindWorkingKeyOptions): Promise<OpencodeKey | null>;
export declare function handleAuthRotate(options?: {
    proxy?: string;
    noCache?: boolean;
}): Promise<void>;
