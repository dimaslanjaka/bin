import { KeyData } from '../../binary-collections/config-types.js';
export interface FindWorkingKeyOptions {
    /** Optional HTTP proxy URL for the API call. */
    proxy?: string;
    /** Disable cache lookup and force checking candidates again. */
    noCache?: boolean;
}
/**
 * Shuffle candidates and test each one against the OpenCode API.
 * Returns the first key that responds successfully.
 *
 * Successful results are cached for 5 minutes per proxy value unless
 * `noCache` is enabled.
 *
 * @param candidates - Key entries to test.
 * @param options    - Optional proxy and cache controls.
 * @returns The first working key entry, or `null` if none respond.
 */
export declare function findWorkingKey(candidates: KeyData[], options?: FindWorkingKeyOptions): Promise<KeyData | null>;
/**
 * Rotates the active OpenCode API key by selecting and testing a working key.
 *
 * @remarks
 * This function performs the following steps:
 * 1. Loads keys from options, or falls back to the project configuration
 * 2. Filters out the currently active key
 * 3. Tests remaining keys against the OpenCode API to find a working one
 * 4. Updates the auth file with the selected working key
 *
 * @param options - Optional configuration for rotation behavior
 * @param options.proxy - HTTP proxy URL to use for API validation
 * @param options.noCache - Bypass cache and force fresh API checks
 * @param options.keys - Custom array of key candidates to test. If provided, overrides config keys.
 *
 * @returns A promise that resolves when rotation completes successfully
 *
 * @throws Will call `process.exit(1)` if:
 * - No keys are found in either options or project config
 * - No auth file exists
 * - No alternative keys are available
 * - No working key can be found among candidates
 *
 * @example
 * ```typescript
 * await handleAuthRotate({
 *   keys: [{ name: 'custom-key', key: 'sk-...' }],
 *   proxy: 'http://proxy.example.com'
 * });
 * ```
 */
export declare function handleAuthRotate(options?: {
    proxy?: string;
    noCache?: boolean;
    keys?: KeyData[];
}): Promise<void>;
