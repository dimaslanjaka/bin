export declare function handleAuthRotate(options?: {
    proxy?: string;
}): Promise<void>;
