export declare function handleListProjects(): Promise<void>;
