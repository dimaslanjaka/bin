export declare function handleListSessions(): Promise<void>;
