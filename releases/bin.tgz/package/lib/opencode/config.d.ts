export interface SessionRenamerConfig {
    model: string;
    titleMaxLength: number;
    dateFormat: string;
    minMessageLength: number;
    debug: boolean;
}
export declare const DEFAULT_CONFIG: SessionRenamerConfig;
export declare function loadConfig(directory: string): SessionRenamerConfig;
