import { SQLite } from '../utils/sqlite/index.js';
export declare function checkDatabase(): Promise<boolean>;
export interface MessageRow {
    id: string;
    session_id: string;
    data: string;
}
export interface PartRow {
    id: string;
    message_id: string;
    session_id: string;
    data: string;
}
export interface Project {
    id: string;
    worktree: string;
    vcs: string | null;
    name: string | null;
    sandboxes: unknown[];
    time: {
        created: number;
        updated: number;
    };
}
export interface Session {
    id: string;
    slug: string;
    version: string;
    projectID: string;
    directory: string;
    parentID?: string;
    title: string;
    time: {
        created: number;
        updated: number;
        compacting?: number;
        archived?: number;
    };
    summary?: {
        additions: number;
        deletions: number;
        files: number;
    };
    share?: {
        url: string;
    };
}
export interface Message {
    id: string;
    sessionID: string;
    role: 'user' | 'assistant';
    time: {
        created: number;
        completed?: number;
    };
    parentID?: string;
    modelID?: string;
    providerID?: string;
    agent?: string;
    mode?: string;
    cost?: number;
    tokens?: {
        input: number;
        output: number;
        reasoning: number;
        cache: {
            read: number;
            write: number;
        };
    };
    finish?: string;
}
export interface ToolState {
    status?: string;
    input?: Record<string, unknown>;
    output?: string;
}
export interface Part {
    id: string;
    sessionID: string;
    messageID: string;
    type: string;
    text?: string;
    tool?: string;
    state?: ToolState;
}
export declare function loadProjects(): Promise<Project[]>;
export declare function loadSessions(): Promise<Session[]>;
/** Load all messages for a session, ordered chronologically (sync, reuse DB connection). */
export declare function loadMessages(sessionId: string): MessageRow[];
export declare function loadMessages(db: SQLite, sessionId: string): MessageRow[];
/** Load all parts for a set of message IDs (sync, reuse DB connection). */
export declare function loadPartsForMessages(messageIds: string[]): PartRow[];
export declare function loadPartsForMessages(db: SQLite, messageIds: string[]): PartRow[];
export declare function loadParts(messageID: string): Promise<Part[]>;
export interface TranscriptEntry {
    message: Message;
    parts: Part[];
}
export interface SessionWithProject {
    session: Session;
    project: Project | undefined;
}
export declare function loadTranscript(sessionID: string): Promise<TranscriptEntry[]>;
export declare function deleteSession(session: Session): Promise<void>;
export declare function deleteSessionById(id: string): Promise<void>;
export declare function deleteAllSessions(): Promise<void>;
export declare function deleteAllProjectSessions(projectID: string): Promise<void>;
