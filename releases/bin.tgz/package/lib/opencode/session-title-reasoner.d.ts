/**
 * session-title-reasoner.ts
 *
 * Reads all OpenCode sessions whose title starts with "New session",
 * extracts the conversation transcript, asks an LLM to reason about
 * what the session was about, and proposes (or writes) a better title.
 *
 * Usage:
 *   # Dry-run – print proposed titles only
 *   npx ts-node src/opencode/session-title-reasoner.ts
 *
 *   # Write titles back to the database
 *   npx ts-node src/opencode/session-title-reasoner.ts --write
 *
 *   # Limit to N sessions
 *   npx ts-node src/opencode/session-title-reasoner.ts --limit 5
 *
 *   # Filter by working directory substring
 *   npx ts-node src/opencode/session-title-reasoner.ts --dir php-proxy-hunter
 *
 *   # Use a specific AI model
 *   npx ts-node src/opencode/session-title-reasoner.ts --model deepseek-v3-free
 */
import OpenAI from 'openai';
import { SQLite } from '../utils/sqlite/index.js';
import { MessageRow, PartRow } from './database.js';
export interface SessionRow {
    id: string;
    project_id: string;
    parent_id: string | null;
    directory: string;
    title: string;
    time_created: number;
    time_updated: number;
}
interface PartData {
    type?: string;
    text?: string;
    tool?: string;
    state?: {
        output?: string;
    };
    [key: string]: unknown;
}
export interface ConversationTurn {
    role: string;
    content: string;
}
export interface SessionSummary {
    id: string;
    directory: string;
    title: string;
    createdAt: Date;
    turns: ConversationTurn[];
}
export interface TitleResult {
    sessionId: string;
    directory: string;
    oldTitle: string;
    newTitle: string;
    reasoning: string;
}
export declare function openDb(): SQLite;
export declare function escapeSql(v: string): string;
/** Load all sessions whose title starts with "New session" (case-insensitive). */
export declare function loadNewSessions(db: SQLite, dir?: string, limit?: number): SessionRow[];
/**
 * Extract readable text from a part's JSON data.
 * Skips tool invocations unless they produced short output.
 */
export declare function extractPartText(data: PartData): string;
/**
 * Build a list of conversation turns from a session's messages and parts.
 * Limits total context to ~6 000 characters to stay within token budgets.
 */
export declare function buildTranscript(messages: MessageRow[], parts: PartRow[], maxChars?: number): ConversationTurn[];
/** Convert turns into a compact markdown-style string for the LLM prompt. */
export declare function formatTranscript(turns: ConversationTurn[]): string;
/**
 * Call the LLM and ask it to reason about the session title.
 * Returns the proposed title and the reasoning.
 */
export declare function proposeTitle(client: OpenAI, model: string, session: SessionSummary): Promise<{
    title: string;
    reasoning: string;
}>;
/** Write the new title back to the session row. */
export declare function updateSessionTitle(db: SQLite, sessionId: string, newTitle: string): void;
export {};
