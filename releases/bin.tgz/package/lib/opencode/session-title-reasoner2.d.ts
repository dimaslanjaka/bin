interface PluginContext {
    directory: string;
    client: OpenCodeClient;
}
interface OpenCodeClient {
    session: SessionClient;
    config: ConfigClient;
}
interface SessionClient {
    create: (args: {
        body: unknown;
    }) => Promise<{
        data?: {
            id: string;
        };
    }>;
    delete: (args: {
        path: {
            id: string;
        };
    }) => Promise<void>;
    update: (args: {
        path: {
            id: string;
        };
        body: {
            title: string;
        };
    }) => Promise<void>;
    prompt: (args: {
        path: {
            id: string;
        };
        body: {
            system: string;
            parts: Array<{
                type: string;
                text: string;
            }>;
            model?: ModelRef;
        };
    }) => Promise<{
        data?: {
            parts?: Array<{
                type: string;
                text: string;
            }>;
        };
    }>;
    get?: (args: {
        path: {
            id: string;
        };
    }) => Promise<{
        data?: {
            title?: string;
        };
    }>;
}
interface ConfigClient {
    providers: (args: {
        query: {
            directory: string;
        };
    }) => Promise<{
        data?: ProvidersConfigPayload;
    }>;
}
interface PluginHooks {
    'chat.message': (input: {
        sessionID: string;
    }, output: {
        message: Message;
        parts: Array<{
            type: string;
        }>;
    }) => Promise<void>;
}
interface Message {
    summary?: {
        title?: string;
        body?: string;
    };
}
export declare const SYSTEM_PROMPT = "You are a session title generator. Generate a concise, descriptive title for a coding session based on the user's first message.\n\nRules:\n- Title must be in the same language as the user's message\n- Title should capture the main task/topic\n- Keep it short and descriptive (max {maxLength} characters)\n- No quotes, no punctuation at the end\n- Just output the title, nothing else\n\nExamples:\n- User: \"Help me fix the login bug in auth.ts\" -> \"Fix login bug\"\n- User: \"I want to refactor the database module\" -> \"Refactor database module\"\n- User: \"Please optimize this React component's performance\" -> \"Optimize React component performance\"";
type ModelRef = {
    providerID: string;
    modelID: string;
};
type ProvidersConfigPayload = {
    providers: Array<{
        id: string;
        models: Record<string, unknown>;
    }>;
    default: Record<string, string>;
};
export declare function formatDate(format: string): string;
export declare function sessionRenamerPlugin(ctx: PluginContext): Promise<PluginHooks>;
export {};
