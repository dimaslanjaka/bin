import type { Plugin } from '@opencode-ai/plugin';
export declare const SYSTEM_PROMPT = "You are a session title generator. Generate a concise, descriptive title for a coding session based on the user's first message.\n\nRules:\n- Title must be in the same language as the user's message\n- Title should capture the main task/topic\n- Keep it short and descriptive (max {maxLength} characters)\n- No quotes, no punctuation at the end\n- Just output the title, nothing else\n\nExamples:\n- User: \"Help me fix the login bug in auth.ts\" -> \"Fix login bug\"\n- User: \"I want to refactor the database module\" -> \"Refactor database module\"\n- User: \"Please optimize this React component's performance\" -> \"Optimize React component performance\"";
export declare function formatDate(format: string): string;
declare function sessionRenamerPlugin(ctx: Parameters<Plugin>[0]): ReturnType<Plugin>;
export declare const sessionRenamer: typeof sessionRenamerPlugin;
export default sessionRenamerPlugin;
