/** Root data directory (`~/.local/share/opencode`). */
export declare const OPCODE_DIR: string;
/** Config directory (`~/.config/opencode`). */
export declare const CONFIG_DIR: string;
/** Cache directory (`~/.cache/opencode`). */
export declare const CACHE_DIR: string;
/** Logs directory. */
export declare const LOG_DIR: string;
/** Path to the auth JSON file. */
export declare const AUTH_PATH: string;
/** Project storage directory (sessions, messages). */
export declare const PROJECT_DIR: string;
/** @deprecated Legacy storage sub-path. Use `OPCODE_DIR` or `PROJECT_DIR` instead. */
export declare const STORAGE_PATH: string;
/** @deprecated Legacy session sub-path. Use `PROJECT_DIR` instead. */
export declare const SESSION_PATH: string;
/** Session diff directory. */
export declare const SESSION_DIFF_DIR: string;
/** Path to the OpenCode database. */
export declare const DATABASE_PATH: string;
export declare function scanJson<T>(dir: string): Promise<T[]>;
export declare function scanDirs(dir: string): Promise<string[]>;
export declare function readJson<T>(filePath: string): Promise<T | null>;
export declare function exists(filePath: string): Promise<boolean>;
