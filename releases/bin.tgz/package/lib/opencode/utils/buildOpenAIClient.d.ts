import OpenAI from 'openai';
import { ProxyAgent } from 'undici';
import { OpenCodeAuthData } from '../types.js';
import { BinaryCollectionsConfig } from '../../binary-collections/config-types.js';
export interface BuildOpenAIClientOptions {
    /** The model name to use. Default varies by provider. */
    model?: string;
    /**
     * HTTP/HTTPS proxy URL for all API requests.
     *
     * Supported formats:
     *   - `http://proxy:8080`
     *   - `https://proxy:8443`
     *   - `http://user:pass@proxy:8080`
     *
     * SOCKS5 is **not** directly supported by the underlying undici `ProxyAgent`.
     * For SOCKS5, use an HTTP-to-SOCKS bridge such as `hpts` or set the
     * `HTTP_PROXY` / `HTTPS_PROXY` environment variables at the process level.
     */
    proxy?: string;
    /**
     * Pre-resolved auth data.
     *
     * Accepts either:
     *   - `OpenCodeAuthData` — auth shape from `getOpenCodeAuth()` with
     *     `{ opencode: { key } }`, `{ google: { key } }`, etc.
     *   - `BinaryCollectionsConfig` — config file shape with
     *     `{ opencode: { keys: [{ name, key }] } }`. The first key in the
     *     array is extracted automatically.
     *
     * When provided, `buildOpenAIClient` skips `getOpenCodeAuth()` and uses
     * these keys directly (useful when auth is already loaded by the caller).
     */
    apiKeys?: OpenCodeAuthData | BinaryCollectionsConfig;
}
/**
 * Build an OpenAI-compatible client and resolve the model name from the
 * available credentials.
 *
 * Credential resolution:
 *   1. Use `apiKeys` from options when provided.
 *   2. Otherwise, read the saved OpenCode auth data.
 *   3. If no compatible saved credentials are available, fall back to
 *      `OPENAI_API_KEY`.
 *
 * Provider priority:
 *   1. OpenCode via `https://opencode.ai/zen/v1`
 *   2. Google Gemini via OpenAI-compatible endpoint
 *   3. NVIDIA via `https://integrate.api.nvidia.com/v1` (auth key > env var)
 *   4. Standard OpenAI using `OPENAI_API_KEY`
 *
 * Default models:
 *   - OpenCode: `deepseek-v4-flash-free`
 *   - Google Gemini: `gemini-2.0-flash`
 *   - NVIDIA: `nvidia/nemotron-3-ultra-550b-a55b`
 *   - OpenAI: `gpt-4o-mini`
 *
 * @param modelOrOptions - A model name string for backward compatibility, or a
 * `BuildOpenAIClientOptions` object containing an optional `model`, `proxy`,
 * and/or `apiKeys`.
 *
 * @returns An object containing the configured OpenAI client, the resolved model
 * name, and the optional undici `ProxyAgent` dispatcher created from `proxy`.
 *
 * @throws If no OpenCode, Google, NVIDIA, or `OPENAI_API_KEY` credential is available.
 */
export declare function buildOpenAIClient(modelOrOptions?: string | BuildOpenAIClientOptions): Promise<{
    client: OpenAI;
    model: string;
    dispatcher?: ProxyAgent;
    proxy?: string;
}>;
