/**
 * Runner — samples demonstrating buildOpenAIClient usage.
 *
 * Run with: npx tsx src/opencode/utils/buildOpenAIClient.runner.ts
 *
 * NOTE: Requires valid API keys in .opencode.keys.jsonc or OPENAI_API_KEY env var.
 * Proxy examples will fail unless you actually have a proxy listening.
 */
export {};
