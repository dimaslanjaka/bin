/**
 * Checks whether the OpenCode API returns a non-empty response for a given prompt.
 *
 * Sends a chat completion request and returns `true` when the model produces
 * meaningful output (non-empty `content` or `reasoning_content`).
 *
 * @param prompt - The user message to send to the model.
 * @param apiKey - Bearer token for API authentication.
 * @param model  - Model identifier (defaults to `'deepseek-v4-flash-free'`).
 * @param proxyUrl - Optional proxy URL. e.g: `http://127.0.0.1:8080, https://127.0.0.1:8443, socks4://127.0.0.1:1080, socks5://127.0.0.1:1080, socks5://user:pass@127.0.0.1:1080`
 * @returns `true` if the response contains non-empty content, `false` otherwise.
 *
 * @example
 * await checkOpenCodeApi('Hello', apiKey, 'deepseek-v4-flash-free', 'socks5://127.0.0.1:1080');
 */
export declare function checkOpenCodeApi(prompt: string, apiKey: string, model?: string, proxyUrl?: string): Promise<boolean>;
