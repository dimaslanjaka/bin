/**
 * Checks whether the OpenCode API returns a non-empty response for a given prompt.
 *
 * Sends a chat completion request and returns `true` when the model produces
 * meaningful output (non-empty `content` or `reasoning_content`).
 *
 * @param prompt - The user message to send to the model.
 * @param apiKey - Bearer token for API authentication.
 * @param model  - Model identifier (defaults to `'deepseek-v4-flash-free'`).
 * @returns `true` if the response contains non-empty content, `false` otherwise.
 */
export declare function checkOpenCodeApi(prompt: string, apiKey: string, model?: string): Promise<boolean>;
