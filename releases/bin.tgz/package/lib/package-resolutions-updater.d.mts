/**
 * Fetch JSON from a URL with GitHub headers.
 * @param {string} url
 * @returns {Promise<any>}
 */
export function fetchJson(url: string): Promise<any>;
/**
 * Get latest commit SHA from a specific branch.
 */
export function getLatestCommit(owner: any, repo: any, branch?: string): Promise<{
    owner: any;
    repo: any;
    branch: string;
    sha: any;
    date: string;
}>;
/**
 * Get latest commit SHA from all branches and pick the latest.
 */
export function getLatestCommitAcrossBranches(owner: any, repo: any): Promise<{
    owner: any;
    repo: any;
    branch: any;
    sha: any;
    date: any;
}>;
/**
 * Replace the branch or commit in a GitHub raw URL with the latest hash.
 */
export function replaceRawWithLatestHash(url: any, latestHash: any): string;
export { parseGitHubUrl };
import { parseGitHubUrl } from "git-command-helper";
