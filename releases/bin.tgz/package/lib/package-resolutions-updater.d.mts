/**
 * Fetch JSON from a URL with GitHub headers.
 * @param {string} url
 * @returns {Promise<any>}
 */
export function fetchJson(url: string): Promise<any>;
/**
 * Get latest commit SHA from a specific branch.
 */
export function getLatestCommit(owner: any, repo: any, branch?: string): Promise<{
    owner: any;
    repo: any;
    branch: string;
    sha: any;
    date: string;
}>;
/**
 * Get latest commit SHA from all branches and pick the latest.
 */
export function getLatestCommitAcrossBranches(owner: any, repo: any): Promise<{
    owner: any;
    repo: any;
    branch: any;
    sha: any;
    date: any;
}>;
/**
 * Replace the branch or commit in a GitHub raw URL with the latest hash.
 */
export function replaceRawWithLatestHash(url: any, latestHash: any): string;
/**
 * Resolve all package resolution updates.
 * Pure logic function for Jest testing.
 */
export function resolvePackageResolutionUpdates(resolutions: any, specialPackageOverrides?: any[]): Promise<({
    skipped: boolean;
    currentPkgName: string;
    url: any;
    error: unknown;
    failed?: undefined;
    repo?: undefined;
} | {
    failed: boolean;
    currentPkgName: string;
    url: any;
    repo: import("git-command-helper").ParsedGitHubUrl;
    error: unknown;
    skipped?: undefined;
})[]>;
export { parseGitHubUrl };
import { parseGitHubUrl } from "git-command-helper";
