export default module.exports;
export function run(): Promise<any>;
export function getStagedPhpFiles(): Promise<string[]>;
declare namespace exports {
    export { run, getStagedPhpFiles, exports as default };
}
declare namespace module { }
