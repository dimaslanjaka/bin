export function run(): Promise<any>;
export function getStagedPhpFiles(): Promise<string[]>;
