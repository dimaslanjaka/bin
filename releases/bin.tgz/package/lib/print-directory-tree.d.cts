export default module.exports;
/**
 * Main function that generates a directory tree with file hashes.
 * @param {object} argv - Parsed CLI arguments.
 */
export function mainPrintDirectoryTree(argv: object): Promise<void>;
declare namespace exports {
    export { mainPrintDirectoryTree, exports as default };
}
declare namespace module { }
