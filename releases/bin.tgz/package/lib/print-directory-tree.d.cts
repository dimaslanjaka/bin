/**
 * Main function that generates a directory tree with file hashes.
 * @param {object} argv - Parsed CLI arguments.
 */
export function mainPrintDirectoryTree(argv: object): Promise<void>;
/**
 * Generates a directory/file tree string from a hash array of file paths and hashes.
 *
 * @param {string[]} hashArray - Array of strings in the format 'relative/path/to/file hash'.
 * @returns {string} The directory/file tree as a string, with file hashes.
 */
export function getFileTreeString(hashArray: string[]): string;
