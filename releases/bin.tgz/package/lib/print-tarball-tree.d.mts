/**
 * Adds path parts to a nested tree object.
 * Creates intermediate nodes as needed and returns the same (mutated) tree.
 * @param {Record<string, object>} tree - The tree object to mutate.
 * @param {string[]} parts - Path segments to insert (e.g. ['package', 'index.js']).
 * @returns {Record<string, object>} The mutated tree with the path parts inserted.
 */
export function addToTree(tree: Record<string, object>, parts: string[]): Record<string, object>;
/**
 * Recursively formats a tree node into an array of tree-drawing lines.
 * Uses Unicode box-drawing characters (└──, ├──, │, ────).
 * @param {Record<string, object>} node - The tree node to format.
 * @param {string} [prefix=''] - Prefix string for the current depth level.
 * @returns {string[]} Array of formatted lines representing the tree.
 */
export function formatTree(node: Record<string, object>, prefix?: string): string[];
/**
 * Prints a formatted tree to the given logger (defaults to console.log).
 * @param {Record<string, object>} node - The tree node to print.
 * @param {string} [prefix=''] - Prefix string for the current depth level.
 * @param {Console['log']} [logger=console.log] - Logging function to output lines.
 */
export function printTgzTree(node: Record<string, object>, prefix?: string, logger?: Console["log"]): void;
/**
 * Main entry point: reads a .tgz archive and prints its directory tree.
 * @param {string} filePath - Path to the .tgz file.
 * @param {{ logger?: Console['log'] }} [options] - Optional overrides (e.g. a custom logger).
 * @returns {Promise<Record<string, object>>} The parsed directory tree.
 */
export function mainPrintTgzTree(filePath: string, options?: {
    logger?: Console["log"];
}): Promise<Record<string, object>>;
