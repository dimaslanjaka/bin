export function addToTree(tree: any, parts: any): any;
export function formatTree(node: any, prefix?: string): any[];
export function printTree(node: any, prefix?: string, logger?: (...data: any[]) => void): void;
export function printTgzTree(filePath: any, options?: {}): Promise<{}>;
