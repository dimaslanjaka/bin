export function printTree(...paths: any[]): Promise<void>;
