export default isWin;
declare const isWin: boolean;
