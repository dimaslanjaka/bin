/**
 * The output sting of cmd to parse
 * @param output
 * @returns {Array}
 */
export function parse(output: any): any[];
