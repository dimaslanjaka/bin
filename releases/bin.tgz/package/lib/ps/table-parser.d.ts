/**
 * @param {string} output
 * @returns {Array<Object>}
 */
export function parse(output: string): Array<Object>;
