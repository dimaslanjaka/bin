export const bashScript: string;
