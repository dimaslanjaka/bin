/**
 * Generate bash script for node_modules cleanup
 * @param {Object} options
 * @param {boolean} options.dryRun - If true, only print what would be deleted
 * @returns {string} - The bash script
 */
export function generateBashScript(options?: {
    dryRun: boolean;
}): string;
/**
 * Create and run a temporary bash script to remove `node_modules` contents.
 *
 * The script is written into `rootDir` and executed via `runBash`. A list of
 * created temporary scripts is stored in a cache file under the OS temp
 * directory so they can be removed after execution. When running with
 * `spawnOptions.stdio === 'inherit'`, the child process uses the parent's
 * stdio and the returned `stdout`/`stderr` may be empty; prefer `'pipe'` in
 * tests when you need to assert against output.
 *
 * @async
 * @param {string} rootDir - Directory where the cleanup script will be created and executed.
 * @param {Object} [options]
 * @param {boolean} [options.dryRun=true] - If true, the generated script will only print what would be deleted.
 * @param {import('child_process').SpawnOptions} [options.spawnOptions] - Options forwarded to the underlying `spawn` call (via `runBash`).
 * @returns {Promise<{code: number, stdout: string, stderr: string}>} Resolves with the result object returned by `runBash`.
 * @throws {Error|Object} Throws for internal failures or rejects with the `runBash` result when the process exits non-zero.
 */
export function cleanUp(rootDir: string, options?: {
    dryRun?: boolean;
    spawnOptions?: import("child_process").SpawnOptions;
}): Promise<{
    code: number;
    stdout: string;
    stderr: string;
}>;
