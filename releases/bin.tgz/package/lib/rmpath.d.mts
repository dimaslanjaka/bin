export function resolveDeletePatterns(targetPath: any): void;
export function deleteMatchingFiles(baseDir: any): Promise<void>;
export function deleteMainScript(targetPath: any): Promise<void>;
