/**
 * @param {{ patterns: string[], ignore: string[], cwd?: string }} options
 * @returns {string}
 */
export function getCacheFile({ patterns, ignore, cwd }: {
    patterns: string[];
    ignore: string[];
    cwd?: string;
}): string;
/**
 * @param {string} file
 * @returns {object|null}
 */
export function loadCache(file: string): object | null;
/**
 * @param {string} file
 * @param {object} data
 */
export function saveCache(file: string, data: object): void;
