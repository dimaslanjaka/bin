export default module.exports;
/**
 * Get all files matching the given glob patterns, ignoring specified paths.
 * @param {{ patterns: string[], ignore: string[], cwd?: string }} options
 * @returns {string[]}
 */
export function getAllFiles({ patterns, ignore, cwd }?: {
    patterns: string[];
    ignore: string[];
    cwd?: string;
}): string[];
/**
 * Build a combined SHA-256 checksum from an ordered list of files.
 * For each file, both its path and content hash are fed into the digest.
 * @param {string[]} files - Ordered list of absolute file paths
 * @returns {string}
 */
export function buildChecksum(files?: string[]): string;
/**
 * Compute a SHA-256 hash of the given data, optionally trimming the output to a specified length.
 * @param {string} data
 * @param {number} trim
 * @returns {string}
 */
export function sha256(data: string, trim?: number): string;
/**
 * Check if a file is binary by scanning for null bytes in the first N bytes.
 * @param {string} filePath - Absolute path to the file
 * @param {number} [bytesToCheck=8000] - Number of bytes to scan from the start
 * @returns {boolean}
 */
export function isBinaryFile(filePath: string, bytesToCheck?: number): boolean;
declare namespace exports {
    export { getAllFiles, buildChecksum, sha256, isBinaryFile, exports as default };
}
declare namespace module { }
