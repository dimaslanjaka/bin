/**
 * @param {{ patterns: string[], ignore: string[], cwd?: string }} options
 * @returns {string[]}
 */
export function getAllFiles({ patterns, ignore, cwd }: {
    patterns: string[];
    ignore: string[];
    cwd?: string;
}): string[];
/**
 * @param {string[]} files
 * @returns {string}
 */
export function buildChecksum(files: string[]): string;
