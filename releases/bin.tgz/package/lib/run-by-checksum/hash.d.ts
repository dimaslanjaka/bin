/**
 * Get all files matching the given glob patterns, ignoring specified paths.
 * @param {{ patterns: string[], ignore: string[], cwd?: string }} options
 * @returns {string[]}
 */
export function getAllFiles({ patterns, ignore, cwd }: {
    patterns: string[];
    ignore: string[];
    cwd?: string;
}): string[];
/**
 * Build a combined SHA-256 checksum from an ordered list of files.
 * For each file, both its path and content hash are fed into the digest.
 * @param {string[]} files - Ordered list of absolute file paths
 * @returns {string}
 */
export function buildChecksum(files: string[]): string;
