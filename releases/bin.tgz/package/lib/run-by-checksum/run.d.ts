/**
 * @param {{
 *   patterns: string[],
 *   ignore?: string[],
 *   exec: string,
 *   cwd?: string,
 *   dryRun?: boolean
 * }} options
 * @returns {Promise<{ changed: boolean, cacheFile: string, files: string[], skipped?: boolean }>}
 */
export function runChecksum({ patterns, ignore, exec, cwd, dryRun }: {
    patterns: string[];
    ignore?: string[];
    exec: string;
    cwd?: string;
    dryRun?: boolean;
}): Promise<{
    changed: boolean;
    cacheFile: string;
    files: string[];
    skipped?: boolean;
}>;
