/**
 * Runner for session-title-reasoner2.
 *
 * Picks a random "New Session" from the OpenCode database, extracts the
 * first user message, and generates a title using the same prompt template
 * as the plugin.
 */
export {};
