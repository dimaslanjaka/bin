export function isRunningInJest(): boolean;
