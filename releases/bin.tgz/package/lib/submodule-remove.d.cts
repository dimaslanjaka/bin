export = removeSubmodule;
declare function removeSubmodule(submodulePath: any): Promise<void>;
