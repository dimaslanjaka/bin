export = removeSubmodule;
declare function removeSubmodule(submodulePath: any): Promise<void>;
declare namespace removeSubmodule {
    export { removeSubmodule as default };
}
