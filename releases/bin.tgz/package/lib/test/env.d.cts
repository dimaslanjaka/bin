export const originalCwd: string;
export const repoDir: string;
export const nonGitDir: string;
/**
 * Get the repo directory path used as a working directory for tests.
 * Does NOT modify the global process.cwd.
 *
 * @returns {string} The absolute path to the test repo directory.
 */
export function getCwd(): string;
/**
 * Ensure the test repository exists at `repoDir`, cloning it if absent.
 * Uses the `test` branch of the dimaslanjaka/test-repo GitHub repository.
 */
export function ensureRepoExists(): void;
/**
 * Ensure the test repo is set up as a yarn project with known dependencies.
 * Initialises a package.json, adds `jquery`/`lodash` as dependencies and
 * `binary-collections` as a devDependency, and creates or renames the lockfile.
 */
export function ensureYarnProject(): void;
/**
 * Install the local `binary-collections` tarball into the test repo.
 * Supports yarn and npm package managers.
 *
 * @param {'yarn'|'npm'} [packageManager='yarn'] - The package manager to use for installation.
 * @returns {import('child_process').SpawnSyncReturns} The result from the install command.
 * @throws {Error} If the tarball is missing at the expected path or an unsupported package manager is given.
 */
export function installTarball(packageManager?: "yarn" | "npm"): import("node:child_process").SpawnSyncReturns<any>;
