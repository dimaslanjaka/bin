/**
 * Test for findNodeModules function
 */
import './env.cjs';
