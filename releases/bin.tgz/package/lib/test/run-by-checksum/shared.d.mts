/**
 * Ensure a directory exists (creates intermediate dirs if needed).
 * @param {string} dirPath - Absolute or relative directory path
 * @returns {string} The same path
 */
export function ensureTestDir(dirPath: string): string;
/**
 * Create a test file with the given content.
 * @param {string} baseDir - Base directory (e.g. TEST_ROOT or a sandbox subdir)
 * @param {string} relPath - Relative file path from baseDir
 * @param {string} content - File content
 * @returns {string} Absolute path to the created file
 */
export function createTestFile(baseDir: string, relPath: string, content: string): string;
/**
 * Read a test file's content.
 * @param {string} baseDir - Base directory
 * @param {string} relPath - Relative file path from baseDir
 * @returns {string} File content as UTF-8 string
 */
export function readTestFile(baseDir: string, relPath: string): string;
/**
 * Delete a file or directory.
 * @param {string} targetPath - Absolute path to the file/dir to remove
 */
export function deleteTestFile(targetPath: string): void;
/**
 * Update (overwrite) a test file's content. Same as createTestFile
 * but kept as a separate semantic alias for CRUD completeness.
 * @param {string} baseDir - Base directory
 * @param {string} relPath - Relative file path from baseDir
 * @param {string} content - New file content
 * @returns {string} Absolute path to the updated file
 */
export function updateTestFile(baseDir: string, relPath: string, content: string): string;
/** Helper to clean up the test root directory */
export function cleanTestRoot(): void;
/** Shared test root directory for run-by-checksum tests */
export const TEST_ROOT: string;
