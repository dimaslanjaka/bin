/**
 * Test helper functions for git-fix testing
 */
/**
 * Create a temporary git repository for testing
 * @param {string} tempDir - Temporary directory path
 */
export function createTempGitRepo(tempDir: string): void;
/**
 * Clean up temporary directory
 * @param {string} tempDir - Temporary directory path
 */
export function cleanupTempDir(tempDir: string): void;
/**
 * Get git config value
 * @param {string} key - Git config key
 * @param {string} cwd - Working directory
 * @param {boolean} localOnly - If true, only check local repository config
 * @returns {string|null} Config value or null if not set
 */
export function getGitConfig(key: string, cwd?: string, localOnly?: boolean): string | null;
/**
 * Mock process.argv for testing
 * @param {string[]} args - Arguments to set
 */
export function mockProcessArgv(args: string[]): string[];
/**
 * Restore process.argv
 * @param {string[]} originalArgv - Original argv to restore
 */
export function restoreProcessArgv(originalArgv: string[]): void;
