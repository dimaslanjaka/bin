export function createMockProject(projectPath: any, options: any): {
    pkgJson: string;
    content: any;
}[];
export function initPackageJson(projectPath: any, options?: {}): {
    pkgJson: string;
    content: any;
};
export function initWorkspace(projectPath: any, options?: {}): {
    pkgJson: string;
    content: any;
}[];
