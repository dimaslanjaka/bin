/**
 * Cross-platform force removal of a file or directory.
 *
 * On Linux, Yarn Berry's node-modules linker may create files with read-only
 * permissions inside `node_modules/`.  `fs.removeSync()` then fails with
 * EACCES because it cannot unlink read-only files.  This function fixes
 * permissions before removal, using `rm -rf` on non-Windows as a fast path
 * (it handles read-only files natively) and falling back to a recursive
 * chmod + remove on Windows.
 *
 * @param {string} dir - path to remove
 */
export function forceRemoveSync(dir: string): void;
/**
 * Prepare the installation environment for a given package manager.
 * Mirrors the original implementation from validate-tarball.test.cjs.
 *
 * @param {string} type - "npm" or "yarn"
 */
export function prepareInstallation(type: string): void;
export const npmLockFile: string;
export const yarnLockFile: string;
export const npmLockFileBackup: string;
export const yarnLockFileBackup: string;
export const nodeModules: string;
/**
 * Verify that all expected bin links exist after installation.
 * Mirrors the original implementation from validate-tarball.test.cjs.
 *
 * @param {string} id - Identifier used for naming the log file.
 * @param {string} tarball - Path to the tarball being tested.
 */
export function checkBinLinks(id: string, tarball: string): void;
export const binEntries: any[];
/**
 * Run `yarn build` and `yarn run pack` in the workspace directory.
 * Keeps output quiet but throws on failure.
 *
 * Skips both steps when a cached checksum shows nothing has changed
 * (same git hash, same tarballs, same source files).
 *
 * @param {string} workspaceDir
 */
export function buildAndPack(workspaceDir: string): void;
/**
 * Validate that installed package exposes the expected `bin` entries and
 * that running both the direct script and the `binary-collections` proxy
 * works for each named command.
 *
 * @param {string} packageManager - human friendly name like "npm" or "yarn"
 */
export function validateBinaries(packageManager: string): void;
