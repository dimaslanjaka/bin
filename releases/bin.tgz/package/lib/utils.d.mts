import * as minimist from 'minimist';

declare function parseGitRemotes(): Promise<{}>;
/**
 * Joins all given path segments together and normalizes the resulting path.
 * Preserves the case of the drive letter on Windows.
 *
 * @param {...string} segments Path segments to join.
 * @returns {string} Normalized path with drive letter case preserved.
 */
declare function joinPathPreserveDriveLetter(...segments: string[]): string;
/**
 * Returns parsed command line arguments using minimist.
 * @returns {import('minimist').ParsedArgs} Parsed command line arguments
 */
declare function getArgs(): minimist.ParsedArgs;
/**
 * Recursively deletes a file or directory at the given path.
 * @param {string} fullPath Absolute path to the file or directory to delete.
 */
declare function del(fullPath: string): void;
/**
 * Handles a glob stream to delete matched files and directories recursively.
 * @param {glob.Glob} globStream Glob stream object.
 */
declare function delStream(globStream: glob.Glob): void;
/**
 * Creates a directory/file tree string from an array of file paths and hashes.
 * @param {string[]} hashArray Array of strings in the format 'relative/path/to/file hash'.
 * @returns {string} Directory/file tree as a string, with file hashes.
 */
declare function getFileTreeString(hashArray: string[]): string;
/**
 * Creates an async delay for the specified number of milliseconds.
 * @param {number} ms Number of milliseconds to delay.
 * @returns {Promise<void>} Promise that resolves after the specified delay.
 */
declare function delay(ms: number): Promise<void>;

export { del, delStream, delay, getArgs, getFileTreeString, joinPathPreserveDriveLetter, parseGitRemotes };
