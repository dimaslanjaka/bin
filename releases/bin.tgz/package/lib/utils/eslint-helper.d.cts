/**
 * Run ESLint --fix on a file with the project's flat config.
 * @param {string} file - absolute path to the file to fix
 * @param {string} [cwd] - project root directory for relative path display (defaults to process.cwd())
 */
export function eslintFix(file: string, cwd?: string): void;
