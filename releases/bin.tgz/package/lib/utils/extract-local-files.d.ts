/**
 * Resolve a relative import path to an absolute file path.
 * Checks the path as-is first, then tries appending known extensions.
 * @param {string} importPath - Relative import path (e.g. './foo' or './foo.cjs')
 * @param {string} baseDir - Absolute directory to resolve against
 * @returns {string|null} Resolved absolute file path, or null if not found
 */
export function resolveLocalFile(importPath: string, baseDir: string): string | null;
/**
 * Recursively collect all local file dependencies from a source file.
 * Handles import declarations, require() calls, and re-exports (export ... from).
 * @param {string} filePath - Absolute path to the entry source file
 * @param {Set<string>} [collected] - Internal set used during recursion
 * @returns {Set<string>} Set of absolute paths to local files
 */
export function extractLocalFiles(filePath: string, collected?: Set<string>): Set<string>;
