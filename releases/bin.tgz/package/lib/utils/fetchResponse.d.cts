export = fetchResponse;
/**
 * Fetch a URL with axios and return response metadata.
 * @param {string} url The URL to request.
 * @param {import('axios').AxiosRequestConfig} [options] Axios request options.
 * @returns {Promise<{
 *   finalUrl: string,
 *   status: number,
 *   statusText: string,
 *   contentType: string | undefined,
 *   contentLength: string | undefined,
 *   dataLength: number | undefined
 * }>}
 */
declare function fetchResponse(url: string, options?: import("axios").AxiosRequestConfig): Promise<{
    finalUrl: string;
    status: number;
    statusText: string;
    contentType: string | undefined;
    contentLength: string | undefined;
    dataLength: number | undefined;
}>;
declare namespace fetchResponse {
    export { fetchResponse, fetchResponse as default };
}
