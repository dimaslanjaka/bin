export const DEFAULT_IGNORES: string[];
/**
 * Find all `.env*` files from the current directory tree
 * and parent directories.
 *
 * @param {string} [startDir=process.cwd()] Starting directory.
 * @param {(file: string) => boolean} [filter] Optional filter callback.
 * @returns {string[]} Normalized absolute file paths.
 */
export function findEnvFiles(startDir?: string, filter?: (file: string) => boolean): string[];
/**
 * Find the first `.env*` file containing a token variable.
 *
 * @param {string} [startDir=process.cwd()] Starting directory.
 * @param {string} [tokenName="GITHUB_TOKEN"] Environment variable name.
 * @returns {string | undefined} Matching file path.
 */
export function findEnvWithToken(startDir?: string, tokenName?: string): string | undefined;
export { findEnvFiles as default };
