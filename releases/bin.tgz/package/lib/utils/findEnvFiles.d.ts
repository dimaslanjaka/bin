/**
 * Find .env files.
 *
 * @param {string} startDir
 * @param {(file:string)=>boolean} [filter]
 * @returns {string[]}
 */
export function findEnvFiles(startDir?: string, filter?: (file: string) => boolean): string[];
