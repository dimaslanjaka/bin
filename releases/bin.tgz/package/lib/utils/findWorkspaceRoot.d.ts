export function findWorkspaceRootYC(cwd?: string): Promise<import("@yarnpkg/fslib").PortablePath>;
/**
 * Find Yarn workspace root directory.
 *
 * @param {string} cwd
 * @returns {string|null}
 */
export function findYarnWorkspaceRootFS(cwd?: string): string | null;
export { findYarnWorkspaceRootFS as findWorkspaceRoot };
