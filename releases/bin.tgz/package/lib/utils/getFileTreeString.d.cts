export = getFileTreeString;
/**
 * Creates a directory/file tree string from an array of file paths and hashes.
 * @param {string[]} hashArray Array of strings in the format 'relative/path/to/file hash'.
 * @returns {string} Directory/file tree as a string, with file hashes.
 */
declare function getFileTreeString(hashArray: string[]): string;
declare namespace getFileTreeString {
    export { exports as default };
}
declare namespace exports {
    export { exports as default };
}
