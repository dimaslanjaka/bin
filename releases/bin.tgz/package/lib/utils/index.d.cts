export default module.exports;
export function parseGitRemotes(): Promise<{}>;
/**
 * Returns parsed command line arguments using minimist.
 * @param {import('minimist').Opts} [opts] Optional minimist options for custom parsing.
 * @returns {import('minimist').ParsedArgs} Parsed command line arguments
 */
export function getArgs(opts?: import("minimist").Opts): import("minimist").ParsedArgs;
/**
 * Recursively deletes a file or directory at the given path.
 * @param {string} fullPath Absolute path to the file or directory to delete.
 */
export function del(fullPath: string): void;
/**
 * Handles a glob stream to delete matched files and directories recursively.
 * @param {glob.Glob} globStream Glob stream object.
 */
export function delStream(globStream: glob.Glob): void;
import getFileTreeString = require("./getFileTreeString.cjs");
/**
 * Creates an async delay for the specified number of milliseconds.
 * @param {number} ms Number of milliseconds to delay.
 * @returns {Promise<void>} Promise that resolves after the specified delay.
 */
export function delay(ms: number): Promise<void>;
declare namespace exports {
    export { parseGitRemotes, getArgs, del, delStream, getFileTreeString, delay, exports as default };
}
declare namespace module { }
export { getFileTreeString };
