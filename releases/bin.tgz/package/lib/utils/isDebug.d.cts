export = isDebug;
/**
 * @description Check if the application is running in debug mode.
 * @returns {boolean}
 */
declare function isDebug(): boolean;
declare namespace isDebug {
    export { isDebug as default, isDebug };
}
