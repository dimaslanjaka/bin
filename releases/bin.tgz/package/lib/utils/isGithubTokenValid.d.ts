/**
 * Check whether a GitHub token is valid.
 *
 * @param {string} token GitHub personal access token
 * @returns {Promise<boolean>}
 */
export function isGitHubTokenValid(token: string): Promise<boolean>;
