/**
 * Determines if the current platform is Windows
 * @returns {boolean} true if running on Windows, false otherwise
 */
export function isWindows(): boolean;
