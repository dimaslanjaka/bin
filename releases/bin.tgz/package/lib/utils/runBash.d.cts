export default runBash;
/**
 * Run a bash script using spawn
 * @param {string} file - path to bash file
 * @param {import("child_process").SpawnOptions} options
 * @returns {Promise<{code: number, stdout: string, stderr: string}>}
 */
export function runBash(file: string, options?: import("child_process").SpawnOptions): Promise<{
    code: number;
    stdout: string;
    stderr: string;
}>;
