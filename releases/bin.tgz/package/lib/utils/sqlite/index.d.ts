import Database from 'better-sqlite3';
export type QueryParams = Record<string, any>;
export type SQLiteDatabase = InstanceType<typeof Database>;
export declare const DEFAULT_DB_PATH: string;
export declare class SQLite {
    private db;
    constructor(dbPath?: string);
    migrate(schemaFilePath: string): void;
    prepare<T = any>(sql: string): T;
    get<T = any>(sql: string, params?: QueryParams): T | undefined;
    all<T = any>(sql: string, params?: QueryParams): T[];
    run(sql: string, params?: QueryParams): Database.RunResult;
    transaction<T>(fn: () => T): T;
    upsert(sql: string, params?: QueryParams): Database.RunResult;
    insertMany(sql: string, rows: QueryParams[]): void;
    close(): void;
    raw(): SQLiteDatabase;
}
