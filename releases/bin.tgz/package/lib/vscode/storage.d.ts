/** VS Code app data root directory (platform-specific). */
export declare const APP_DATA_DIR: string;
/** User configuration directory (`<APP_DATA_DIR>/User`). */
export declare const USER_DIR: string;
/** User settings file (`<USER_DIR>/settings.json`). */
export declare const SETTINGS_PATH: string;
/** User keybindings file (`<USER_DIR>/keybindings.json`). */
export declare const KEYBINDINGS_PATH: string;
/** User snippets directory (`<USER_DIR>/snippets`). */
export declare const SNIPPETS_DIR: string;
/** Workspace storage directory (`<USER_DIR>/workspaceStorage`). */
export declare const WORKSPACE_STORAGE_DIR: string;
/** Global storage directory (`<USER_DIR>/globalStorage`). */
export declare const GLOBAL_STORAGE_DIR: string;
/** History directory (`<USER_DIR>/History`). */
export declare const HISTORY_DIR: string;
/** Sync data directory (`<USER_DIR>/sync`). */
export declare const SYNC_DIR: string;
/** Global extensions directory (`~/.vscode/extensions`). */
export declare const EXTENSIONS_DIR: string;
/** VS Code cache root directory (platform-specific). */
export declare const CACHE_DIR: string;
/** Cached data directory (`<CACHE_DIR>/CachedData`). */
export declare const CACHED_DATA_DIR: string;
/** Cached extensions directory (`<CACHE_DIR>/CachedExtensions`). */
export declare const CACHED_EXTENSIONS_DIR: string;
/** Cached VSIX directory (`<CACHE_DIR>/CachedExtensionVSIXs`). */
export declare const CACHED_VSIXS_DIR: string;
/** Logs directory (`<APP_DATA_DIR>/logs`). */
export declare const LOGS_DIR: string;
/** Main VS Code state database (`<APP_DATA_DIR>/state.vscdb`). */
export declare const DATABASE_PATH: string;
/** Machine identifier file (`<APP_DATA_DIR>/machineid`). */
export declare const MACHINE_ID_PATH: string;
export interface WorkspaceEntry {
    /** Absolute filesystem path to the workspace folder (decoded from the `file://` URI). */
    folder: string;
    /** The storage folder name (hash). */
    storageId: string;
    /** Full path to the storage directory (e.g. `.../workspaceStorage/<storageId>`). */
    storagePath: string;
    /** Full path to the Copilot memory tool directory, if it exists. */
    copilotMemoryDir?: string;
}
/**
 * Scan all subdirectories under `WORKSPACE_STORAGE_DIR` and read each
 * `workspace.json` to collect workspace folder URIs.
 *
 * Subdirectories without a valid `workspace.json` are silently skipped.
 */
export declare function listWorkspaceProjects(): Promise<WorkspaceEntry[]>;
